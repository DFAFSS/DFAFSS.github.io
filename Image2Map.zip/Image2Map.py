import tkinter as tk,os,zipfile,json,shutil,time,math
from tkinter import filedialog
from PIL import Image

def help_1():
    print("导入的图片颜色只能含有以下16种颜色(RGB颜色数值已给出):")
    print("黑色:0,0,0\n淡灰色:169,169,169\n灰色:105,105,105\n白色:255,255,255\n棕色:139,69,19\n红色:255,0,0\n橙色:255,140,0\n黄色:255,255,0\n黄绿色:173,255,47\n绿色:0,255,0\n青色:0,255,255\n浅蓝色:0,191,255\n蓝色:0,0,255\n紫色:148,0,211\n品红色:255,0,255\n粉色:255,192,203")
    pass
def zipDir(dirpath, outFullName):
    """
    压缩指定文件夹
    :param dirpath: 目标文件夹路径
    :param outFullName: 压缩文件保存路径+xxxx.zip
    :return: 无
    """
    zip = zipfile.ZipFile(outFullName, "w", zipfile.ZIP_DEFLATED)
    for path, dirnames, filenames in os.walk(dirpath):
        # 去掉目标跟路径，只对目标文件夹下边的文件及文件夹进行压缩
        fpath = path.replace(dirpath, '')
 
        for filename in filenames:
            zip.write(os.path.join(path, filename), os.path.join(fpath, filename))
    
colors = {
    "red_wool": (255, 0, 0, 255),
    "green_wool": (0, 255, 0, 255),
    "blue_wool": (0, 0, 255, 255),
    "yellow_wool": (255, 255, 0, 255),
    "purple_wool": (128, 0, 128, 255),
    "pink_wool": (255, 192, 203, 255),
    "orange_wool": (255, 165, 0, 255),
    "brown_wool": (165, 42, 42, 255),
    "gray_wool": (128, 128, 128, 255),
    "black_wool": (0, 0, 0, 255),
    "white_wool": (255, 255, 255, 255),
    "cyan_wool": (0, 255, 255, 255),
    "red_concrete": (139, 0, 0, 255),
    "green_concrete": (0, 100, 0, 255),
    "blue_concrete": (0, 0, 139, 255),
    "yellow_concrete": (184, 134, 11, 255),
    "purple_concrete": (139, 0, 139, 255),
    "pink_concrete": (255, 20, 147, 255),
    "oange_concrete": (255, 140, 0, 255),
    "brown_concrete": (101, 67, 33, 255),
    "gray_concrete": (169, 169, 169, 255),
    "light_gray_concrete": (211, 211, 211, 255),
    "red_terracotta": (255, 192, 203, 255),
    "green_terracotta": (144, 238, 144, 255),
    "light_blue_terracotta": (173, 216, 230, 255),
    "yellow_terracotta": (255, 255, 224, 255),
    "purple_terracotta": (221, 160, 221, 255),
    "pink_terracotta": (255, 182, 193, 255),
    "orange_terracotta": (255, 228, 181, 255),
    "brown_terracotta": (210, 180, 140, 255),
    "gold_block": (255, 215, 0, 255),
    "stone": (192, 192, 192, 255),
    "stripped_acacia_wood": (205, 127, 50, 255),
    "copper_block": (184, 115, 51, 255),
    "soul_soil": (134, 70, 39, 255),
    "melon": (191, 255, 0, 255),
    "smooth_sandstone": (238, 232, 170, 255),
    "enerald_block": (124, 252, 0, 255),
    "prismarine_bricks": (0, 255, 255, 255),
    "dried_kelp_block": (128, 128, 0, 255),
    "dark_prismarine": (85, 107, 47, 255),
    "diamond_block": (189, 252, 201, 255),
    "lapis_block": (51, 161, 201, 255),
    "redstone_block": (255, 0, 127, 255),
    "light_blue_glazed_terracotta": (0, 127, 255, 255),
    "purple_glazed_terracotta": (128, 0, 128, 255)
}

def get_color_name(rgb):
    min_dist = float('inf')
    closest_color = None
    for name, value in colors.items():
        dist = math.sqrt((rgb[0] - value[0]) ** 2 + (rgb[1] - value[1]) ** 2 + (rgb[2] - value[2]) ** 2)
        if dist < min_dist:
            min_dist = dist
            closest_color = name
    return closest_color

while True:
    b = False
    select = input("<1>16色模式 <2>普通模式:")
    if select == "1":
        functionText = []
        T_File = filedialog.askopenfilename(filetypes=[('Png Files','*.png'),('Jpeg Files','*.jpeg'),('Jpg Files','*.jpg')])
        ImageFile = Image.open(T_File)
        Width = ImageFile.width
        Height = ImageFile.height
        for W in range(Width):
            for H in range(Height):
                RGB = ImageFile.getpixel((W,H))
                RGB_List = {
                    (255,0,0,255) : "red_wool",
                    (0,255,0,255) : "green_wool",
                    (0,0,255,255) : "blue_wool",
                    (0,0,0,255) : "black_wool",
                    (169,169,169,255) : "light_gray_wool",
                    (105,105,105,255) : "gray_wool",
                    (255,255,255,255) : "white_wool",
                    (139,69,19,255) : "brown_wool",
                    (255,140,0,255) : "orange_wool",
                    (255,255,0,255) : "yellow_wool",
                    (173,255,47,255) : "lime_wool",
                    (0,255,255,255) : "cyan_wool",
                    (0,191,255,255) : "light_blue_wool",
                    (148,0,221,255) : "purple_wool",
                    (225,0,225,255) : "magenta_wool",
                    (225,192,203,255) : "pink_wool"
                }
                try:
                    Com = f'setblock ~{W} ~ ~{H} {RGB_List[RGB]}\n'
                    pass
                except KeyError:
                    print(f"你选中的图片未包含该十六个颜色\n位置:{W}-{H}")
                    b = True
                    break
                functionText.append(Com)
                pass
            if b:
                break
            pass
        pass
        DataPack_Name = input('请输入名称(只能含有小写字母"a-z"和下划线"_"):')
        DataPack_JSON = {
            'pack':{
                'pack_format':15,
                'description':'Image2Map'
            }
        }
        os.makedirs(f"Image2Map\\data\\{DataPack_Name}\\functions")
        with open(f"Image2Map\\pack.mcmeta",'w') as File:
            File.write(json.dumps(DataPack_JSON))
            pass
        F = open(f"Image2Map\\data\\{DataPack_Name}\\functions\\map_to_image.mcfunction",'w')
        F.writelines(functionText)
        F.close()
        F = open(f"Image2Map\\data\\{DataPack_Name}\\functions\\load.mcfunction",'w',encoding='utf-8')
        Text = []
        Text.append(f"say 使用/function {DataPack_Name}:map_to_image 来加载生成的照片\n")
        Text.append(f"say 该图片宽高为{Width}×{Height}\n")
        Text.append('say 图片较大，生成可能会需要一点时间') if Width >= 500 and Height >= 500 else ''
        F.writelines(Text)
        F.close()
        zipDir('Image2Map',filedialog.asksaveasfilename(filetypes=[('数据包','.zip')],initialfile=f'{DataPack_Name}.zip'))
        time.sleep(0.5)
        shutil.rmtree("Image2Map")
        pass
    elif select == "2":
        functionText = []
        T_File = filedialog.askopenfilename(filetypes=[('Png Files','*.png'),('Jpeg Files','*.jpeg'),('Jpg Files','*.jpg')])
        ImageFile = Image.open(T_File)
        Width = ImageFile.width
        Height = ImageFile.height
        for W in range(Width):
            for H in range(Height):
                RGB = ImageFile.getpixel((W,H))
                Com = f'setblock ~{W} ~ ~{H} {get_color_name(RGB)}\n'
                functionText.append(Com)
                pass
            pass
        pass
        DataPack_Name = input('请输入名称(只能含有小写字母"a-z"和下划线"_"):')
        DataPack_JSON = {
            'pack':{
                'pack_format':15,
                'description':'Image2Map'
            }
        }
        os.makedirs(f"Image2Map\\data\\{DataPack_Name}\\functions")
        with open(f"Image2Map\\pack.mcmeta",'w') as File:
            File.write(json.dumps(DataPack_JSON))
            pass
        F = open(f"Image2Map\\data\\{DataPack_Name}\\functions\\map_to_image.mcfunction",'w')
        F.writelines(functionText)
        F.close()
        F = open(f"Image2Map\\data\\{DataPack_Name}\\functions\\load.mcfunction",'w',encoding='utf-8')
        Text = []
        Text.append(f"say 使用/function {DataPack_Name}:map_to_image 来加载生成的照片\n")
        Text.append(f"say 该图片宽高为{Width}×{Height}\n")
        Text.append('say 图片较大，生成可能会需要一点时间') if Width >= 500 and Height >= 500 else ''
        F.writelines(Text)
        F.close()
        zipDir('Image2Map',filedialog.asksaveasfilename(filetypes=[('数据包','.zip')],initialfile=f'{DataPack_Name}.zip'))
        time.sleep(0.5)
        shutil.rmtree("Image2Map")
        pass
    elif select == "1?":
        help_1()
        pass
    else:
        print("请正确选择")
        pass
    pass