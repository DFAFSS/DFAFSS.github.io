from translate import Translator
from tqdm import tqdm
import zipfile,os,shutil,json,re,time,zipapp,zipfile
#print(Translator(from_lang="English",to_lang="Chinese").translate(jz))
#函数

import json
def is_json(myjson):
    try:
        json_object = json.loads(myjson)
    except ValueError as e:
        return False
    return True
def zipDir(dirpath, outFullName):
    """
    压缩指定文件夹
    :param dirpath: 目标文件夹路径
    :param outFullName: 压缩文件保存路径+xxxx.zip
    :return: 无
    """
    zip = zipfile.ZipFile(outFullName, "w", zipfile.ZIP_DEFLATED)
    for path, dirnames, filenames in os.walk(dirpath):
        # 去掉目标跟路径，只对目标文件夹下边的文件及文件夹进行压缩
        fpath = path.replace(dirpath, '')
 
        for filename in filenames:
            zip.write(os.path.join(path, filename), os.path.join(fpath, filename))
def Unzip(File):
    with zipfile.ZipFile(File) as zfile:
        File_Name = os.path.basename(File)
        zfile.extractall(f"Cache/{File_Name[0:len(File_Name)-4]}")
    pass
def dirlist(path):  
    allfile = []
    filelist =  os.listdir(path)  
  
    for filename in filelist:  
        filepath = os.path.join(path, filename)  
        if os.path.isdir(filepath):  
            dirlist(filepath, allfile)  
        else:  
            allfile.append(filepath)  
    return allfile
def allDir(path):
    f=[]
    for root,dirs,files in os.walk(path):
        for filespath in files:
            f.append(os.path.join(root,filespath))
    return(f)



while True:
    pick = input('<1>开始汉化')
    if int(pick) == 1:
        print('--------------------正在读取Mods文件夹内所有文件--------------------')
        Mods_List = dirlist('Mods')
        os.mkdir('Resourcepacks\\assets')
        Str_Json = {
            'pack':{
                'description':'A I18N Resourcepacks',
                'pack_format':6
                }
            }
        file = open('Resourcepacks\\pack.mcmeta','w')
        file.write(json.dumps(Str_Json))
        file.close
        print('------------------正在解压,读取lang文件夹内语言文件-----------------')
        for i in tqdm(range(len(Mods_List))):
            Unzip(Mods_List[i])
            pass
        LangJson = allDir('Cache')
        print('--------------------正在读取lang文件夹内语言文件--------------------')
        LangList = []
        for i in tqdm(range(len(LangJson)),leave=0):
#            file = open('text.txt','w')
#            file.write(str(LangJson))
#            file.close()
            if (LangJson[i][len(LangJson[i])-16:len(LangJson[i])-10] == '\\\\en_us.json' or
                LangJson[i][len(LangJson[i])-9:len(LangJson[i])] == 'n_us.json' or
                LangJson[i][len(LangJson[i])-10:len(LangJson[i])] == 'en_us.json'):
                LangList.append(LangJson[i])
                pass
            pass
        
        print('--------------------------正在移动语言文件--------------------------')
        os.mkdir('Cache\\translation')
        for i in tqdm(range(len(LangList))):
            try:
                LangName = str(LangList[i]).split('\\')
                os.makedirs('Cache\\translation\\'+LangName[3])
                shutil.copy(LangList[i],'Cache\\translation\\'+LangName[3]+'\\zh_cn.json')
                pass
            except:
                ###
                pass
            pass
        pass
        print('--------------------------正在翻译语言文件--------------------------')
        for i in range(len(LangList)):
            Dicts = {}
            Tr = ''
            LangName = str(LangList[i]).split('\\')
            file = open('Cache\\translation\\'+LangName[3]+'\\zh_cn.json')
            Json_Str = json.load(file)
            file.close()
            Keys = list(dict(Json_Str).keys())
            Vaule = list(dict(Json_Str).values())
            print("正在翻译"+LangName[3])
            for ii in tqdm(range(len(Json_Str))):
                Tr = Translator(from_lang='en',to_lang='zh').translate(Vaule[ii])
                Dicts[Keys[ii]] = Tr
                pass
            os.makedirs('Resourcepacks\\assets\\'+LangName[3]+'\\lang')
            file = open('Resourcepacks\\assets\\'+LangName[3]+'\\lang\\zh_cn.json','w')
            file.write(json.dumps(Dicts))
            file.close()
            pass
        
        print('--------------------------正在打包语言材质包--------------------------')
        zipDir('Resourcepacks','OutPut\\I18N Resourcepacks.zip')
        print('------------------------汉化完成(OusPut文件夹)------------------------------')
        shutil.rmtree("Cache")
        shutil.rmtree("Resourcepacks")
        os.mkdir('Resourcepacks')
        os.mkdir('Cache')
    else:
        print('未知选项')
        pass
    pass
