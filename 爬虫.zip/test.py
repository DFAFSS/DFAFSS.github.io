import requests
import os
import io
import sys
import re
import time

sys.stdout = io.TextIOWrapper(sys.stdout.buffer,encoding='utf8')
url = 'https://search.bilibili.com/upuser?keyword=$&from_source=webt'
str_Str = ""
str_Str = input("请输入关键词：")
num = 1

url = url.replace("$", str_Str)
headers = {'User-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0'}
response = requests.get(url,headers=headers)
html_Str = response.text
print(html_Str)
file = open("html.txt",'wb')
file.write(html_Str.encode("utf-8"))
file.close
pattern = re.compile('<a.*?text1 p_relative.*?title="(.*?)"',re.S)
items = re.findall(pattern,html_Str)
print(items)

