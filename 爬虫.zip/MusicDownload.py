import requests,PySimpleGUI as psg,re,json,hashlib,time
from lxml import etree
List = []
Lists = []
ListGui = psg.Listbox(List,key='-MusicList-',expand_x=True,expand_y=True)
layout = [
    [psg.Input(default_text='Name',key='-MusicName-'),psg.Button(button_text='搜索'),psg.Button(button_text='下载')],
    [ListGui]
]

headers = {
    'User-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.0',
    'Referer':'https://www.kugou.com/',
    'Cookie':'kg_mid=40acb29e3e5acbb7783347db7d480c13; kg_dfid=4FHivo2aNrFK0PmE2J0pcsX6; kg_dfid_collect=d41d8cd98f00b204e9800998ecf8427e; Hm_lvt_aedee6983d4cfc62f509129360d6bb3d=1700398164,1700488056,1701957813,1702032715; kg_mid_temp=40acb29e3e5acbb7783347db7d480c13; Hm_lpvt_aedee6983d4cfc62f509129360d6bb3d=1702035265'
    }

def save(music_id):
    data = {
        'r':'play/getdata',
        #'callback':'jQuery19104381911389285846_1693915941407',
        'dfid':'2UHYNz3g5BlC1P5mfH2586l5',
        'appid':'1014',
        'mid':'6cff5eec372eb97a1152cedd1d7c9fd5',
        'platid':'4',
        'encode_album_audio_id':music_id,
        '_':'1693915941408',
    }
    url = "https://wwwapi.kugou.com/yy/index.php"
    respinse = requests.get(url=url,params=data,headers=headers)
    audio_name = respinse.json()['data']['audio_name']
    audio_url = respinse.json()['data']['play_url']
    music_content = requests.get(url=audio_url,headers=headers).content
    with open('music/'+ audio_name + '.mp3',mode='wb') as file:
        file.write(music_content)
        pass
def md5_hash(date,word):
    text = [
        "NVPh5oo715z5DIWAeQlhMDsWXXQV4hwt"
        "appid=1014" 
        "bitrate=0"
        "callback=callback123"
        f"clienttime={date}" 
        "clientver=1000" 
        "dfid=4FHivo2aNrFK0PmE2J0pcsX6" 
        "filter=10" 
        "inputtype=0"
        "iscorrection=1"
        "isfuzzy=0"
        f"keyword={word}"
        "mid=40acb29e3e5acbb7783347db7d480c13"
        "page=1"
        "pagesize=30"
        "platform=WebFilter"
        "privilege_filter=0"
        "srcappid=2919"
        "token="
        "userid=0"
        "uuid=40acb29e3e5acbb7783347db7d480c13"
        "NVPh5oo715z5DIWAeQlhMDsWXXQV4hwt"
    ]
    string = ''.join(text)
    md5 = hashlib.md5()
    md5.update(string.encode('utf-8'))
    signatrue = md5.hexdigest()
    return signatrue

Window = psg.Window('MusicDownload',layout,size=(700,500))

while True:
    Event,Vaule = Window.read()
    if Event == psg.WINDOW_CLOSED:
        break
    if Event == '搜索':
        num = 0
        List = []
        Lists = []
        link = 'https://complexsearch.kugou.com/v2/search/song'
        date = int(time.time() * 1000)
        signatrue = md5_hash(date=date,word=str(Vaule['-MusicName-']))
        link_data = {
            'callback': 'callback123',
            'srcappid': '2919',
            'clientver': '1000',
            'clienttime': date,
            'mid': '40acb29e3e5acbb7783347db7d480c13',
            'uuid': '40acb29e3e5acbb7783347db7d480c13',
            'dfid': '4FHivo2aNrFK0PmE2J0pcsX6',
            'keyword': str(Vaule['-MusicName-']),
            'page': '1',
            'pagesize': '30',
            'bitrate': '0',
            'isfuzzy': '0',
            'inputtype': '0',
            'platform': 'WebFilter',
            'userid': '0',
            'iscorrection': '1',
            'privilege_filter': '0',
            'filter': '10',
            'token': '',
            'appid': '1014',
            'signature': signatrue,
        }
        respinse_data = requests.get(url=link,params=link_data,headers=headers)
        html_data = re.findall('callback123\((.*)', " ".join(line.strip() for line in respinse_data.text.splitlines()))[0].replace(')','')
        json_data = json.loads(html_data)
        for index in json_data['data']['lists']:
            num += 1
            List.append(str(num)+"|"+index['SingerName']+'|'+index['SongName']+'|'+index['AlbumName'])
            Lists.append(index['EMixSongID'])
            dit = {
                '歌名': index['SingerName'],
                '歌手': index['SongName'],
                '专辑': index['AlbumName'],
                'ID': index['EMixSongID'],
            }
            pass
        Window['-MusicList-'].update(List)
        pass
    if Event == '下载':
        try:
            val = ListGui.get()[0]
            Str = str(val).split('|')
            Number = Str[0]
            Id = Lists[int(Number)-1]
            save(Id)
            psg.popup_ok("下载成功！")
            pass
        except IndexError:
            psg.popup_error("请选择要下载的歌曲")
            pass
        pass
    pass
Window.close()
