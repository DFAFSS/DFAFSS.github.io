/// <reference path="./globals.d.ts" />
const PonderInput: typeof PonderInputWindowElement
const Direction: typeof Facing
const Text: typeof Component
