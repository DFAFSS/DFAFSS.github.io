/// <reference path="./internal_*.d.ts" />
declare namespace Internal {
    interface EntityInLevelCallback {
        abstract onMove(): void;
        abstract onRemove(arg0: Internal.Entity$RemovalReason_): void;
        readonly NULL: Internal.EntityInLevelCallback;
    }
    type EntityInLevelCallback_ = EntityInLevelCallback;
    interface Packet <T extends Internal.PacketListener> {
        abstract write(arg0: Internal.FriendlyByteBuf_): void;
        isSkippable(): boolean;
        abstract handle(arg0: T): void;
        get skippable(): boolean
    }
    type Packet_<T extends Internal.PacketListener> = Packet<T>;
    abstract class BaseCommandBlock implements Internal.CommandSource {
        constructor()
        isTrackOutput(): boolean;
        getCommand(): string;
        abstract isValid(): boolean;
        abstract getPosition(): Vec3d;
        getName(): net.minecraft.network.chat.Component;
        abstract getLevel(): Internal.ServerLevel;
        usedBy(arg0: Internal.Player_): Internal.InteractionResult;
        abstract createCommandSourceStack(): Internal.CommandSourceStack;
        save(arg0: Internal.CompoundTag_): Internal.CompoundTag;
        getLastOutput(): net.minecraft.network.chat.Component;
        shouldInformAdmins(): boolean;
        acceptsFailure(): boolean;
        load(arg0: Internal.CompoundTag_): void;
        alwaysAccepts(): boolean;
        setCommand(arg0: string): void;
        setName(arg0: net.minecraft.network.chat.Component_): void;
        setSuccessCount(arg0: number): void;
        setLastOutput(arg0: net.minecraft.network.chat.Component_): void;
        setTrackOutput(arg0: boolean): void;
        sendSystemMessage(arg0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        abstract onUpdated(): void;
        getSuccessCount(): number;
        performCommand(arg0: Internal.Level_): boolean;
        get trackOutput(): boolean
        get command(): string
        get valid(): boolean
        get position(): Vec3d
        get name(): net.minecraft.network.chat.Component
        get level(): Internal.ServerLevel
        get lastOutput(): net.minecraft.network.chat.Component
        set command(arg0: string)
        set name(arg0: net.minecraft.network.chat.Component_)
        set successCount(arg0: number)
        set lastOutput(arg0: net.minecraft.network.chat.Component_)
        set trackOutput(arg0: boolean)
        get successCount(): number
    }
    type BaseCommandBlock_ = BaseCommandBlock;
    class ModConfigEvent$Reloading extends Internal.ModConfigEvent {
        constructor()
        constructor(arg0: Internal.ModConfig_)
        static unloading(arg0: Internal.ModConfig_): Internal.IConfigEvent;
        self<T extends net.minecraftforge.eventbus.api.Event & Internal.IConfigEvent>(): T;
        static loading(arg0: Internal.ModConfig_): Internal.IConfigEvent;
        static reloading(arg0: Internal.ModConfig_): Internal.IConfigEvent;
    }
    type ModConfigEvent$Reloading_ = ModConfigEvent$Reloading;
    class ClientboundLevelChunkWithLightPacket implements Internal.Packet<Internal.ClientGamePacketListener> {
        constructor(arg0: Internal.FriendlyByteBuf_)
        constructor(arg0: Internal.LevelChunk_, arg1: Internal.LevelLightEngine_, arg2: Internal.BitSet_, arg3: Internal.BitSet_)
        handle(arg0: Internal.PacketListener_): void;
        write(arg0: Internal.FriendlyByteBuf_): void;
        getX(): number;
        handle(arg0: Internal.ClientGamePacketListener_): void;
        getChunkData(): Internal.ClientboundLevelChunkPacketData;
        getZ(): number;
        getLightData(): Internal.ClientboundLightUpdatePacketData;
        isSkippable(): boolean;
        get x(): number
        get chunkData(): Internal.ClientboundLevelChunkPacketData
        get z(): number
        get lightData(): Internal.ClientboundLightUpdatePacketData
        get skippable(): boolean
    }
    type ClientboundLevelChunkWithLightPacket_ = ClientboundLevelChunkWithLightPacket;
    interface Byte2IntFunction extends it.unimi.dsi.fastutil.Function<number, number>, Internal.IntUnaryOperator {
        getOrDefault(arg0: number, arg1: number): number;
        /**
         * @deprecated
        */
        compose<T>(arg0: Internal.Function_<T, number>): Internal.Function<T, number>;
        composeByte(arg0: Internal.Byte2ByteFunction_): this;
        andThenInt(arg0: Internal.Int2IntFunction_): this;
        abstract get(arg0: number): number;
        defaultReturnValue(): number;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: any): any;
        apply(arg0: number): number;
        composeFloat(arg0: Internal.Float2ByteFunction_): Internal.Float2IntFunction;
        composeLong(arg0: Internal.Long2ByteFunction_): Internal.Long2IntFunction;
        andThen(arg0: Internal.IntUnaryOperator_): Internal.IntUnaryOperator;
        composeObject<T>(arg0: Internal.Object2ByteFunction_<T>): Internal.Object2IntFunction<T>;
        composeChar(arg0: Internal.Char2ByteFunction_): Internal.Char2IntFunction;
        andThenShort(arg0: Internal.Int2ShortFunction_): Internal.Byte2ShortFunction;
        /**
         * @deprecated
        */
        containsKey(arg0: any): boolean;
        andThenDouble(arg0: Internal.Int2DoubleFunction_): Internal.Byte2DoubleFunction;
        andThenLong(arg0: Internal.Int2LongFunction_): Internal.Byte2LongFunction;
        compose(arg0: Internal.IntUnaryOperator_): Internal.IntUnaryOperator;
        /**
         * @deprecated
        */
        applyAsInt(arg0: number): number;
        identity(): Internal.IntUnaryOperator;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        /**
         * @deprecated
        */
        put(arg0: number, arg1: number): number;
        containsKey(arg0: number): boolean;
        andThenFloat(arg0: Internal.Int2FloatFunction_): Internal.Byte2FloatFunction;
        /**
         * @deprecated
        */
        remove(arg0: any): number;
        remove(arg0: number): number;
        andThenObject<T>(arg0: Internal.Int2ObjectFunction_<T>): Internal.Byte2ObjectFunction<T>;
        put(arg0: number, arg1: number): number;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: number): number;
        size(): number;
        composeReference<T>(arg0: Internal.Reference2ByteFunction_<T>): Internal.Reference2IntFunction<T>;
        defaultReturnValue(arg0: number): void;
        composeInt(arg0: Internal.Int2ByteFunction_): Internal.Int2IntFunction;
        andThenByte(arg0: Internal.Int2ByteFunction_): Internal.Byte2ByteFunction;
        clear(): void;
        composeDouble(arg0: Internal.Double2ByteFunction_): Internal.Double2IntFunction;
        /**
         * @deprecated
        */
        andThen<T>(arg0: Internal.Function_<number, T>): Internal.Function<number, T>;
        andThenChar(arg0: Internal.Int2CharFunction_): Internal.Byte2CharFunction;
        andThenReference<T>(arg0: Internal.Int2ReferenceFunction_<T>): Internal.Byte2ReferenceFunction<T>;
        composeShort(arg0: Internal.Short2ByteFunction_): Internal.Short2IntFunction;
        /**
         * @deprecated
        */
        get(arg0: any): any;
        (arg0: number): number;
    }
    type Byte2IntFunction_ = Byte2IntFunction;
    class WarpPlateRecipe implements Internal.Recipe<net.minecraft.world.Container> {
        constructor(arg0: ResourceLocation_, arg1: Internal.ItemStack_, arg2: Internal.Ingredient_, arg3: Internal.NonNullList_<Internal.Ingredient>)
        getIngredients(): Internal.NonNullList<Internal.Ingredient>;
        isSpecial(): boolean;
        getGroup(): string;
        getToastSymbol(): Internal.ItemStack;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        getResultItem(arg0: Internal.RegistryAccess_): Internal.ItemStack;
        getSchema(): Internal.RecipeSchema;
        canCraftInDimensions(arg0: number, arg1: number): boolean;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        getType(): ResourceLocation;
        setGroup(group: string): void;
        assemble(arg0: net.minecraft.world.Container_, arg1: Internal.RegistryAccess_): Internal.ItemStack;
        getSerializer(): Internal.RecipeSerializer<any>;
        getId(): ResourceLocation;
        getOrCreateId(): ResourceLocation;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        isIncomplete(): boolean;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        matches(arg0: net.minecraft.world.Container_, arg1: Internal.Level_): boolean;
        getMod(): string;
        getRemainingItems(arg0: net.minecraft.world.Container_): Internal.NonNullList<Internal.ItemStack>;
        get ingredients(): Internal.NonNullList<Internal.Ingredient>
        get special(): boolean
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get schema(): Internal.RecipeSchema
        get type(): ResourceLocation
        set group(group: string)
        get serializer(): Internal.RecipeSerializer<any>
        get id(): ResourceLocation
        get orCreateId(): ResourceLocation
        get incomplete(): boolean
        get mod(): string
    }
    type WarpPlateRecipe_ = WarpPlateRecipe;
    class FodderBlock extends Internal.WaterBlock {
        constructor(properties: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static readonly LAYERS: Internal.IntegerProperty;
    }
    type FodderBlock_ = FodderBlock;
    interface StreamTagVisitor {
        abstract visitEntry(arg0: Internal.TagType_<any>, arg1: string): Internal.StreamTagVisitor$EntryResult;
        abstract visit(arg0: number): Internal.StreamTagVisitor$ValueResult;
        abstract visit(arg0: string): Internal.StreamTagVisitor$ValueResult;
        abstract visit(arg0: number): Internal.StreamTagVisitor$ValueResult;
        abstract visitContainerEnd(): Internal.StreamTagVisitor$ValueResult;
        abstract visit(arg0: number): Internal.StreamTagVisitor$ValueResult;
        abstract visitElement(arg0: Internal.TagType_<any>, arg1: number): Internal.StreamTagVisitor$EntryResult;
        abstract visit(arg0: number): Internal.StreamTagVisitor$ValueResult;
        abstract visit(arg0: number): Internal.StreamTagVisitor$ValueResult;
        abstract visit(arg0: number[]): Internal.StreamTagVisitor$ValueResult;
        abstract visitEnd(): Internal.StreamTagVisitor$ValueResult;
        abstract visitRootEntry(arg0: Internal.TagType_<any>): Internal.StreamTagVisitor$ValueResult;
        abstract visit(arg0: number): Internal.StreamTagVisitor$ValueResult;
        abstract visit(arg0: number[]): Internal.StreamTagVisitor$ValueResult;
        abstract visit(arg0: number[]): Internal.StreamTagVisitor$ValueResult;
        abstract visitList(arg0: Internal.TagType_<any>, arg1: number): Internal.StreamTagVisitor$ValueResult;
        abstract visitEntry(arg0: Internal.TagType_<any>): Internal.StreamTagVisitor$EntryResult;
    }
    type StreamTagVisitor_ = StreamTagVisitor;
    class ServerboundSetCarriedItemPacket implements Internal.Packet<Internal.ServerGamePacketListener> {
        constructor(arg0: Internal.FriendlyByteBuf_)
        constructor(arg0: number)
        handle(arg0: Internal.PacketListener_): void;
        write(arg0: Internal.FriendlyByteBuf_): void;
        handle(arg0: Internal.ServerGamePacketListener_): void;
        getSlot(): number;
        isSkippable(): boolean;
        get slot(): number
        get skippable(): boolean
    }
    type ServerboundSetCarriedItemPacket_ = ServerboundSetCarriedItemPacket;
    interface TextureVisitor {
        abstract visit(arg0: Internal.TextureProxy_, arg1: number): void;
        (arg0: Internal.TextureProxy, arg1: number): void;
    }
    type TextureVisitor_ = TextureVisitor;
    class ItemJetpack extends Internal.ItemGasArmor implements Internal.IJetpackItem, Internal.IModeItem, Internal.IItemHUDProvider {
        constructor(material: Internal.ArmorMaterial_, properties: Internal.Item$Properties_)
        constructor(properties: Internal.Item$Properties_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        supportsSlotType(stack: Internal.ItemStack_, slotType: Internal.EquipmentSlot_): boolean;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        getScrollTextComponent(stack: Internal.ItemStack_): net.minecraft.network.chat.Component;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        static getPrimaryJetpack(entity: Internal.LivingEntity_): Internal.ItemStack;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        addHUDStrings(list: Internal.List_<net.minecraft.network.chat.Component>, player: Internal.Player_, stack: Internal.ItemStack_, slotType: Internal.EquipmentSlot_): void;
        useJetpackFuel(stack: Internal.ItemStack_): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        getCreativeTab(): string;
        static isModeItem(player: Internal.Player_, slotType: Internal.EquipmentSlot_, allowRadial: boolean): boolean;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        static isModeItem(stack: Internal.ItemStack_, slotType: Internal.EquipmentSlot_, allowRadial: boolean): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        setMode(stack: Internal.ItemStack_, mode: Internal.IJetpackItem$JetpackMode_): void;
        static isModeItem(player: Internal.Player_, slotType: Internal.EquipmentSlot_): boolean;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        canUseJetpack(stack: Internal.ItemStack_): boolean;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        useGas(stack: Internal.ItemStack_, amount: number): Internal.GasStack;
        addDefault(): boolean;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getJetpackMode(stack: Internal.ItemStack_): Internal.IJetpackItem$JetpackMode;
        static get(arg0: Internal.ItemStack_): Internal.Equipable;
        getDamage(arg0: Internal.ItemStack_): number;
        kjs$getMutableAttributeMap(): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        changeMode(player: Internal.Player_, stack: Internal.ItemStack_, shift: number, displayChange: Internal.IModeItem$DisplayChange_): void;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        hasGas(stack: Internal.ItemStack_): boolean;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        static getActiveJetpack(entity: Internal.LivingEntity_): Internal.ItemStack;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        static displayModeChange(player: Internal.Player_): void;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        static handleJetpackMotion(player: Internal.Player_, mode: Internal.IJetpackItem$JetpackMode_, ascendingSupplier: Internal.BooleanSupplier_): boolean;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        addCurioHUDStrings(list: Internal.List_<net.minecraft.network.chat.Component>, player: Internal.Player_, stack: Internal.ItemStack_): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        swapWithEquipmentSlot(arg0: Internal.Item_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        static getPlayerJetpackMode(player: Internal.Player_, mode: Internal.IJetpackItem$JetpackMode_, ascendingSupplier: Internal.BooleanSupplier_): Internal.IJetpackItem$JetpackMode;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        static isModeItem(stack: Internal.ItemStack_, slotType: Internal.EquipmentSlot_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type ItemJetpack_ = ItemJetpack;
    abstract class CombiningPredicate implements net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate {
        static hasSturdyFace(arg0: Internal.Direction_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static noFluid(arg0: Vec3i_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        and(arg0: Internal.BiPredicate_<Internal.WorldGenLevel, BlockPos>): Internal.BiPredicate<Internal.WorldGenLevel, BlockPos>;
        static matchesTag(arg0: Vec3i_, arg1: Internal.TagKey_<Internal.Block>): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static anyOf(arg0: Internal.List_<net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate>): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static noFluid(): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static anyOf(arg0: net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate_, arg1: net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        negate(): Internal.BiPredicate<Internal.WorldGenLevel, BlockPos>;
        abstract test(arg0: Internal.WorldGenLevel_, arg1: BlockPos_): boolean;
        static solid(arg0: Vec3i_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static insideWorld(arg0: Vec3i_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        or(arg0: Internal.BiPredicate_<Internal.WorldGenLevel, BlockPos>): Internal.BiPredicate<Internal.WorldGenLevel, BlockPos>;
        static matchesTag(arg0: Internal.TagKey_<Internal.Block>): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static solid(): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static alwaysTrue(): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static matchesBlocks(arg0: Vec3i_, ...arg1: Internal.Block_[]): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        abstract type(): Internal.BlockPredicateType<any>;
        static matchesBlocks(arg0: Vec3i_, arg1: Internal.List_<Internal.Block>): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static allOf(...arg0: net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate_[]): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static replaceable(): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static wouldSurvive(arg0: Internal.BlockState_, arg1: Vec3i_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static matchesFluids(arg0: Vec3i_, arg1: Internal.List_<Internal.Fluid>): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static codec<T extends Internal.CombiningPredicate>(arg0: Internal.Function_<Internal.List<net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate>, T>): Internal.Codec<T>;
        static not(arg0: net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static matchesFluids(arg0: Vec3i_, ...arg1: Internal.Fluid_[]): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static allOf(arg0: Internal.List_<net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate>): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static allOf(arg0: net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate_, arg1: net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static anyOf(...arg0: net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate_[]): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static hasSturdyFace(arg0: Vec3i_, arg1: Internal.Direction_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static replaceable(arg0: Vec3i_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static matchesBlocks(...arg0: Internal.Block_[]): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static matchesBlocks(arg0: Internal.List_<Internal.Block>): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static matchesFluids(...arg0: Internal.Fluid_[]): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
    }
    type CombiningPredicate_ = CombiningPredicate;
    class ChuteBlock extends Internal.AbstractChuteBlock implements Internal.ProperWaterloggedBlock {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        getBlockEntity(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.ChuteBlockEntity;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        fluidState(arg0: Internal.BlockState_): Internal.FluidState;
        onBlockEntityUse(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Function_<Internal.ChuteBlockEntity, Internal.InteractionResult>): Internal.InteractionResult;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        withBlockEntityDo(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Consumer_<Internal.ChuteBlockEntity>): void;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        playRemoveSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        getBlockEntityOptional(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.Optional<Internal.ChuteBlockEntity>;
        getTicker<S extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<S>): Internal.BlockEntityTicker<S>;
        playRotateSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        newBlockEntity(arg0: BlockPos_, arg1: Internal.BlockState_): Internal.BlockEntity;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        updateWater(arg0: Internal.LevelAccessor_, arg1: Internal.BlockState_, arg2: BlockPos_): void;
        static onRemove(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.BlockState_): void;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        static withWater(arg0: Internal.LevelAccessor_, arg1: Internal.BlockState_, arg2: BlockPos_): Internal.BlockState;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        onSneakWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        withWater(arg0: Internal.BlockState_, arg1: Internal.BlockPlaceContext_): Internal.BlockState;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        updateAfterWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.BlockState;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getRotatedBlockState(arg0: Internal.BlockState_, arg1: Internal.Direction_): Internal.BlockState;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getBlockEntityType(): Internal.BlockEntityType<Internal.ChuteBlockEntity>;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        get blockEntityType(): Internal.BlockEntityType<Internal.ChuteBlockEntity>
        static readonly SHAPE: Internal.Property<Internal.ChuteBlock$Shape>;
        static readonly FACING: Internal.DirectionProperty;
    }
    type ChuteBlock_ = ChuteBlock;
    class SimpleMapCodec <K, V> extends Internal.MapCodec<Internal.Map<K, V>> implements Internal.BaseMapCodec<K, V> {
        constructor(arg0: Internal.Codec_<K>, arg1: Internal.Codec_<V>, arg2: Internal.Keyable_)
        keyCodec(): Internal.Codec<K>;
        map<B>(arg0: Internal.Function_<Internal.Map<K, V>, B>): Internal.MapDecoder<B>;
        keys<T>(arg0: Internal.DynamicOps_<T>): Internal.Stream<T>;
        encode(arg0: any, arg1: Internal.DynamicOps_<any>, arg2: Internal.RecordBuilder_<any>): Internal.RecordBuilder<any>;
        decode<T>(arg0: Internal.DynamicOps_<T>, arg1: Internal.MapLike_<T>): Internal.DataResult<Internal.Map<K, V>>;
        comap<B>(arg0: Internal.Function_<B, Internal.Map<K, V>>): Internal.MapEncoder<B>;
        static forStrings(arg0: Internal.Supplier_<Internal.Stream<string>>): Internal.Keyable;
        flatMap<B>(arg0: Internal.Function_<Internal.Map<K, V>, Internal.DataResult<B>>): Internal.MapDecoder<B>;
        abstract compressor<T>(arg0: Internal.DynamicOps_<T>): Internal.KeyCompressor<T>;
        flatComap<B>(arg0: Internal.Function_<B, Internal.DataResult<Internal.Map<K, V>>>): Internal.MapEncoder<B>;
        elementCodec(): Internal.Codec<V>;
        encode<T>(arg0: Internal.Map_<K, V>, arg1: Internal.DynamicOps_<T>, arg2: Internal.RecordBuilder_<T>): Internal.RecordBuilder<T>;
        decoder(): Internal.Decoder<Internal.Map<K, V>>;
        compressedBuilder<T>(arg0: Internal.DynamicOps_<T>): Internal.RecordBuilder<T>;
        ap<E>(arg0: Internal.MapDecoder_<Internal.Function<Internal.Map<K, V>, E>>): Internal.MapDecoder<E>;
        encoder(): Internal.Encoder<Internal.Map<K, V>>;
        static makeCompressedBuilder<T>(arg0: Internal.DynamicOps_<T>, arg1: Internal.KeyCompressor_<T>): Internal.RecordBuilder<T>;
        compressedDecode<T>(arg0: Internal.DynamicOps_<T>, arg1: T): Internal.DataResult<Internal.Map<K, V>>;
    }
    type SimpleMapCodec_<K, V> = SimpleMapCodec<K, V>;
    class CompassItem extends Internal.Item implements Internal.Vanishable {
        constructor(arg0: Internal.Item$Properties_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        static getLodestonePosition(arg0: Internal.CompoundTag_): Internal.GlobalPos;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        static getSpawnPosition(arg0: Internal.Level_): Internal.GlobalPos;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        static isLodestoneCompass(arg0: Internal.ItemStack_): boolean;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        static readonly TAG_LODESTONE_TRACKED: "LodestoneTracked";
        static readonly TAG_LODESTONE_POS: "LodestonePos";
        static readonly TAG_LODESTONE_DIMENSION: "LodestoneDimension";
    }
    type CompassItem_ = CompassItem;
    interface Blender$DistanceGetter {
        abstract getDistance(arg0: number, arg1: number, arg2: number): number;
        (arg0: number, arg1: number, arg2: number): number;
    }
    type Blender$DistanceGetter_ = Blender$DistanceGetter;
    class ItemHohlraum extends Internal.CapabilityItem implements Internal.CreativeTabDeferredRegister$ICustomCreativeTabContents {
        constructor(properties: Internal.Item$Properties_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        addItems(tabOutput: Internal.CreativeModeTab$Output_): void;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        addDefault(): boolean;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type ItemHohlraum_ = ItemHohlraum;
    class RecursiveTypeFamily implements Internal.TypeFamily {
        constructor(arg0: string, arg1: Internal.TypeTemplate_)
        name(): string;
        fold(arg0: Internal.Algebra_, arg1: Internal.RecursiveTypeFamily_): Internal.IntFunction<Internal.RewriteResult<any, any>>;
        size(): number;
        everywhere(arg0: number, arg1: Internal.TypeRewriteRule_, arg2: Internal.PointFreeRule_): Internal.Optional<Internal.RewriteResult<any, any>>;
        findType<A, B>(arg0: number, arg1: com.mojang.datafixers.types.Type_<A>, arg2: com.mojang.datafixers.types.Type_<B>, arg3: Internal.Type$TypeMatcher_<A, B>, arg4: boolean): Internal.Either<Internal.TypedOptic<any, any, A, B>, Internal.Type$FieldNotFoundException>;
        buildMuType<A>(arg0: com.mojang.datafixers.types.Type_<A>, arg1: Internal.RecursiveTypeFamily_): Internal.RecursivePoint$RecursivePointType<A>;
        static familyOptic<A, B>(arg0: Internal.IntFunction_<Internal.TypedOptic<any, any, A, B>>): Internal.FamilyOptic<A, B>;
        apply(arg0: number): com.mojang.datafixers.types.Type<any>;
        template(): Internal.TypeTemplate;
    }
    type RecursiveTypeFamily_ = RecursiveTypeFamily;
    class ConnectedGlassBlock extends Internal.GlassBlock {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type ConnectedGlassBlock_ = ConnectedGlassBlock;
    class GenericMachineBlock extends Internal.GenericEntityBlockWaterloggable {
        constructor(arg0: Internal.BlockEntityType$BlockEntitySupplier_<Internal.BlockEntity>)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isIPlayerStorable(): boolean;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get IPlayerStorable(): boolean
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static IPLAYERSTORABLE_MAP: {};
    }
    type GenericMachineBlock_ = GenericMachineBlock;
    interface DirectMethodHandleDesc extends Internal.MethodHandleDesc {
        abstract isOwnerInterface(): boolean;
        of(arg0: Internal.DirectMethodHandleDesc$Kind_, arg1: Internal.ClassDesc_, arg2: string, arg3: string): this;
        abstract invocationType(): Internal.MethodTypeDesc;
        abstract methodName(): string;
        resolveConstantDesc(arg0: Internal.MethodHandles$Lookup_): any;
        abstract kind(): Internal.DirectMethodHandleDesc$Kind;
        abstract owner(): Internal.ClassDesc;
        ofField(arg0: Internal.DirectMethodHandleDesc$Kind_, arg1: Internal.ClassDesc_, arg2: string, arg3: Internal.ClassDesc_): this;
        ofMethod(arg0: Internal.DirectMethodHandleDesc$Kind_, arg1: Internal.ClassDesc_, arg2: string, arg3: Internal.MethodTypeDesc_): this;
        asType(arg0: Internal.MethodTypeDesc_): Internal.MethodHandleDesc;
        abstract lookupDescriptor(): string;
        abstract refKind(): number;
        ofConstructor(arg0: Internal.ClassDesc_, ...arg1: Internal.ClassDesc_[]): this;
        abstract equals(arg0: any): boolean;
        get ownerInterface(): boolean
    }
    type DirectMethodHandleDesc_ = DirectMethodHandleDesc;
    class BambooSpikesTippedItem extends Internal.WoodBasedBlockItem implements Internal.SimpleWaterloggedBlock {
        constructor(blockIn: Internal.Block_, builder: Internal.Item$Properties_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        static isPotionValid(potion: Internal.Potion_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        static makeSpikeItem(potion: Internal.Potion_): Internal.ItemStack;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type BambooSpikesTippedItem_ = BambooSpikesTippedItem;
    class IExtensionPoint$DisplayTest extends Internal.Record implements Internal.IExtensionPoint<Internal.IExtensionPoint$DisplayTest> {
        constructor(arg0: string, arg1: Internal.BiPredicate_<string, boolean>)
        constructor(suppliedVersion: Internal.Supplier_<string>, remoteVersionTest: Internal.BiPredicate_<string, boolean>)
        remoteVersionTest(): Internal.BiPredicate<string, boolean>;
        suppliedVersion(): Internal.Supplier<string>;
        static readonly IGNORE_ALL_VERSION: Internal.Supplier<Internal.IExtensionPoint$DisplayTest>;
        static readonly IGNORESERVERONLY: "OHNOES😱😱😱😱😱😱😱😱😱😱😱😱😱😱😱😱😱";
        static readonly IGNORE_SERVER_VERSION: Internal.Supplier<Internal.IExtensionPoint$DisplayTest>;
    }
    type IExtensionPoint$DisplayTest_ = IExtensionPoint$DisplayTest;
    class UnmodifiableCommentedConfig$CommentNode {
        constructor(arg0: string, arg1: Internal.Map_<string, Internal.UnmodifiableCommentedConfig$CommentNode>)
        getComment(): string;
        getChildren(): Internal.Map<string, Internal.UnmodifiableCommentedConfig$CommentNode>;
        get comment(): string
        get children(): Internal.Map<string, Internal.UnmodifiableCommentedConfig$CommentNode>
    }
    type UnmodifiableCommentedConfig$CommentNode_ = UnmodifiableCommentedConfig$CommentNode;
    class Transformation implements Internal.IForgeTransformation {
        constructor(arg0: Matrix4f_)
        constructor(arg0: Vec3f_, arg1: Quaternionf_, arg2: Vec3f_, arg3: Quaternionf_)
        inverse(): this;
        getScale(): Vec3f;
        compose(arg0: Internal.Transformation_): this;
        getTranslation(): Vec3f;
        getMatrix(): Matrix4f;
        blockCenterToCorner(): this;
        static identity(): Internal.Transformation;
        transformNormal(arg0: Vec3f_): void;
        rotateTransform(arg0: Internal.Direction_): Internal.Direction;
        getRightRotation(): Quaternionf;
        slerp(arg0: Internal.Transformation_, arg1: number): this;
        blockCornerToCenter(): this;
        transformPosition(arg0: Vec4f_): void;
        getLeftRotation(): Quaternionf;
        applyOrigin(arg0: Vec3f_): this;
        isIdentity(): boolean;
        getNormalMatrix(): Matrix3f;
        get scale(): Vec3f
        get translation(): Vec3f
        get matrix(): Matrix4f
        get rightRotation(): Quaternionf
        get leftRotation(): Quaternionf
        get identity(): boolean
        get normalMatrix(): Matrix3f
        static readonly EXTENDED_CODEC: Internal.Codec<Internal.Transformation>;
        static readonly CODEC: Internal.Codec<Internal.Transformation>;
    }
    type Transformation_ = Transformation;
    interface AccessibleTable {
        abstract setAccessibleRowHeader(arg0: Internal.AccessibleTable_): void;
        abstract getAccessibleSummary(): Internal.Accessible;
        abstract getAccessibleColumnCount(): number;
        abstract getAccessibleColumnExtentAt(arg0: number, arg1: number): number;
        abstract getAccessibleAt(arg0: number, arg1: number): Internal.Accessible;
        abstract getAccessibleRowCount(): number;
        abstract setAccessibleCaption(arg0: Internal.Accessible_): void;
        abstract getSelectedAccessibleColumns(): number[];
        abstract getAccessibleRowExtentAt(arg0: number, arg1: number): number;
        abstract getAccessibleRowHeader(): this;
        abstract getAccessibleRowDescription(arg0: number): Internal.Accessible;
        abstract isAccessibleSelected(arg0: number, arg1: number): boolean;
        abstract getAccessibleColumnHeader(): this;
        abstract getAccessibleCaption(): Internal.Accessible;
        abstract isAccessibleColumnSelected(arg0: number): boolean;
        abstract isAccessibleRowSelected(arg0: number): boolean;
        abstract setAccessibleColumnDescription(arg0: number, arg1: Internal.Accessible_): void;
        abstract setAccessibleColumnHeader(arg0: Internal.AccessibleTable_): void;
        abstract setAccessibleRowDescription(arg0: number, arg1: Internal.Accessible_): void;
        abstract getSelectedAccessibleRows(): number[];
        abstract setAccessibleSummary(arg0: Internal.Accessible_): void;
        abstract getAccessibleColumnDescription(arg0: number): Internal.Accessible;
        set accessibleRowHeader(arg0: Internal.AccessibleTable_)
        get accessibleSummary(): Internal.Accessible
        get accessibleColumnCount(): number
        get accessibleRowCount(): number
        set accessibleCaption(arg0: Internal.Accessible_)
        get selectedAccessibleColumns(): number[]
        get accessibleRowHeader(): Internal.AccessibleTable
        get accessibleColumnHeader(): Internal.AccessibleTable
        get accessibleCaption(): Internal.Accessible
        set accessibleColumnHeader(arg0: Internal.AccessibleTable_)
        get selectedAccessibleRows(): number[]
        set accessibleSummary(arg0: Internal.Accessible_)
    }
    type AccessibleTable_ = AccessibleTable;
    abstract class WorldCarver <C extends Internal.CarverConfiguration> {
        constructor(arg0: Internal.Codec_<C>)
        configured(arg0: C): Internal.ConfiguredWorldCarver<C>;
        configuredCodec(): Internal.Codec<Internal.ConfiguredWorldCarver<C>>;
        abstract isStartChunk(arg0: C, arg1: Internal.RandomSource_): boolean;
        getRange(): number;
        abstract carve(arg0: Internal.CarvingContext_, arg1: C, arg2: Internal.ChunkAccess_, arg3: Internal.Function_<BlockPos, Internal.Holder<Internal.Biome>>, arg4: Internal.RandomSource_, arg5: Internal.Aquifer_, arg6: Internal.ChunkPos_, arg7: Internal.CarvingMask_): boolean;
        get range(): number
        static readonly CANYON: Internal.CanyonWorldCarver;
        static readonly NETHER_CAVE: Internal.NetherWorldCarver;
        static readonly CAVE: Internal.CaveWorldCarver;
    }
    type WorldCarver_<C extends Internal.CarverConfiguration> = WorldCarver<C> | Special.Carver;
    class TransformRecipeSerializer implements Internal.RecipeSerializer<Internal.TransformRecipe> {
        static register<S extends Internal.RecipeSerializer<T>, T extends Internal.Recipe<any>>(arg0: string, arg1: S): S;
        fromJson(arg0: ResourceLocation_, arg1: Internal.JsonObject_): Internal.Recipe<any>;
        toNetwork(arg0: Internal.FriendlyByteBuf_, arg1: Internal.TransformRecipe_): void;
        fromJson(arg0: ResourceLocation_, arg1: Internal.JsonObject_): Internal.TransformRecipe;
        fromNetwork(arg0: ResourceLocation_, arg1: Internal.FriendlyByteBuf_): Internal.TransformRecipe;
        toNetwork(arg0: Internal.FriendlyByteBuf_, arg1: Internal.Recipe_<any>): void;
        fromJson(arg0: ResourceLocation_, arg1: Internal.JsonObject_, arg2: Internal.ICondition$IContext_): Internal.TransformRecipe;
        fromNetwork(arg0: ResourceLocation_, arg1: Internal.FriendlyByteBuf_): Internal.Recipe<any>;
        static readonly INSTANCE: Internal.TransformRecipeSerializer;
    }
    type TransformRecipeSerializer_ = TransformRecipeSerializer;
    abstract class Sensor <E extends Internal.LivingEntity> {
        constructor()
        constructor(arg0: number)
        static isEntityTargetable(arg0: Internal.LivingEntity_, arg1: Internal.LivingEntity_): boolean;
        static isEntityAttackable(arg0: Internal.LivingEntity_, arg1: Internal.LivingEntity_): boolean;
        static isEntityAttackableIgnoringLineOfSight(arg0: Internal.LivingEntity_, arg1: Internal.LivingEntity_): boolean;
        abstract requires(): Internal.Set<Internal.MemoryModuleType<any>>;
        tick(arg0: Internal.ServerLevel_, arg1: E): void;
    }
    type Sensor_<E extends Internal.LivingEntity> = Sensor<E>;
    class ServerboundPongPacket implements Internal.Packet<Internal.ServerGamePacketListener> {
        constructor(arg0: Internal.FriendlyByteBuf_)
        constructor(arg0: number)
        handle(arg0: Internal.PacketListener_): void;
        write(arg0: Internal.FriendlyByteBuf_): void;
        handle(arg0: Internal.ServerGamePacketListener_): void;
        isSkippable(): boolean;
        getId(): number;
        get skippable(): boolean
        get id(): number
    }
    type ServerboundPongPacket_ = ServerboundPongPacket;
    class Options implements Internal.AccessOptions, Internal.IMixinOptions {
        constructor(arg0: Internal.Minecraft_, arg1: Internal.File_)
        panoramaSpeed(): Internal.OptionInstance<number>;
        backgroundForChatOnly(): Internal.OptionInstance<boolean>;
        entityShadows(): Internal.OptionInstance<boolean>;
        damageTiltStrength(): Internal.OptionInstance<number>;
        touchscreen(): Internal.OptionInstance<boolean>;
        mouseWheelSensitivity(): Internal.OptionInstance<number>;
        biomeBlendRadius(): Internal.OptionInstance<number>;
        setGuiScale(arg0: Internal.OptionInstance_<any>): void;
        cloudStatus(): Internal.OptionInstance<Internal.CloudStatus>;
        guiScale(): Internal.OptionInstance<number>;
        telemetryOptInExtra(): Internal.OptionInstance<boolean>;
        chatOpacity(): Internal.OptionInstance<number>;
        hideLightningFlash(): Internal.OptionInstance<boolean>;
        attackIndicator(): Internal.OptionInstance<Internal.AttackIndicatorStatus>;
        framerateLimit(): Internal.OptionInstance<number>;
        chatColors(): Internal.OptionInstance<boolean>;
        notificationDisplayTime(): Internal.OptionInstance<number>;
        chatScale(): Internal.OptionInstance<number>;
        glintSpeed(): Internal.OptionInstance<number>;
        getModelPartsFancyMenu(): Internal.Set<any>;
        darknessEffectScale(): Internal.OptionInstance<number>;
        setServerRenderDistance(arg0: number): void;
        highContrast(): Internal.OptionInstance<boolean>;
        ambientOcclusion(): Internal.OptionInstance<boolean>;
        broadcastOptions(): void;
        mainHand(): Internal.OptionInstance<Internal.HumanoidArm>;
        chatWidth(): Internal.OptionInstance<number>;
        simulationDistance(): Internal.OptionInstance<number>;
        chatDelay(): Internal.OptionInstance<number>;
        particles(): Internal.OptionInstance<Internal.ParticleStatus>;
        invokeProcessOptionsFancyMenu(arg0: Internal.Options$FieldAccess_): void;
        static genericValueLabel(arg0: net.minecraft.network.chat.Component_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        chatLinks(): Internal.OptionInstance<boolean>;
        onlyShowSecureChat(): Internal.OptionInstance<boolean>;
        soundDevice(): Internal.OptionInstance<string>;
        realmsNotifications(): Internal.OptionInstance<boolean>;
        getSoundSourceVolume(arg0: Internal.SoundSource_): number;
        getCloudsType(): Internal.CloudStatus;
        getFile(): Internal.File;
        prioritizeChunkUpdates(): Internal.OptionInstance<Internal.PrioritizeChunkUpdates>;
        getBackgroundColor(arg0: number): number;
        loadSelectedResourcePacks(arg0: Internal.PackRepository_): void;
        autoSuggestions(): Internal.OptionInstance<boolean>;
        entityDistanceScaling(): Internal.OptionInstance<number>;
        gamma(): Internal.OptionInstance<number>;
        textBackgroundOpacity(): Internal.OptionInstance<number>;
        toggleSprint(): Internal.OptionInstance<boolean>;
        screenEffectScale(): Internal.OptionInstance<number>;
        enableVsync(): Internal.OptionInstance<boolean>;
        fullscreen(): Internal.OptionInstance<boolean>;
        setCameraType(arg0: Internal.CameraType_): void;
        showAutosaveIndicator(): Internal.OptionInstance<boolean>;
        autoJump(): Internal.OptionInstance<boolean>;
        showSubtitles(): Internal.OptionInstance<boolean>;
        discreteMouseScroll(): Internal.OptionInstance<boolean>;
        reducedDebugInfo(): Internal.OptionInstance<boolean>;
        isModelPartEnabled(arg0: Internal.PlayerModelPart_): boolean;
        load(arg0: boolean): void;
        narrator(): Internal.OptionInstance<Internal.NarratorStatus>;
        useNativeTransport(): boolean;
        static genericValueLabel(arg0: net.minecraft.network.chat.Component_, arg1: number): net.minecraft.network.chat.Component;
        bobView(): Internal.OptionInstance<boolean>;
        chatLineSpacing(): Internal.OptionInstance<number>;
        forceUnicodeFont(): Internal.OptionInstance<boolean>;
        renderDistance(): Internal.OptionInstance<number>;
        allowServerListing(): Internal.OptionInstance<boolean>;
        getEffectiveRenderDistance(): number;
        directionalAudio(): Internal.OptionInstance<boolean>;
        operatorItemsTab(): Internal.OptionInstance<boolean>;
        chatHeightFocused(): Internal.OptionInstance<number>;
        load(): void;
        glintStrength(): Internal.OptionInstance<number>;
        toggleCrouch(): Internal.OptionInstance<boolean>;
        setKey(arg0: Internal.KeyMapping_, arg1: Internal.InputConstants$Key_): void;
        hideMatchedNames(): Internal.OptionInstance<boolean>;
        getBackgroundOpacity(arg0: number): number;
        fov(): Internal.OptionInstance<number>;
        toggleModelPart(arg0: Internal.PlayerModelPart_, arg1: boolean): void;
        getSoundSourceOptionInstance(arg0: Internal.SoundSource_): Internal.OptionInstance<number>;
        mipmapLevels(): Internal.OptionInstance<number>;
        chatHeightUnfocused(): Internal.OptionInstance<number>;
        updateResourcePacks(arg0: Internal.PackRepository_): void;
        getCameraType(): Internal.CameraType;
        save(): void;
        chatVisibility(): Internal.OptionInstance<Internal.ChatVisiblity>;
        sensitivity(): Internal.OptionInstance<number>;
        rawMouseInput(): Internal.OptionInstance<boolean>;
        graphicsMode(): Internal.OptionInstance<Internal.GraphicsStatus>;
        fovEffectScale(): Internal.OptionInstance<number>;
        invertYMouse(): Internal.OptionInstance<boolean>;
        getBackgroundColor(arg0: number): number;
        dumpOptionsForReport(): string;
        chatLinksPrompt(): Internal.OptionInstance<boolean>;
        darkMojangStudiosBackground(): Internal.OptionInstance<boolean>;
        set guiScale(arg0: Internal.OptionInstance_<any>)
        get modelPartsFancyMenu(): Internal.Set<any>
        set serverRenderDistance(arg0: number)
        get cloudsType(): Internal.CloudStatus
        get file(): Internal.File
        set cameraType(arg0: Internal.CameraType_)
        get effectiveRenderDistance(): number
        get cameraType(): Internal.CameraType
        readonly keySwapOffhand: Internal.KeyMapping;
        readonly keyDown: Internal.KeyMapping;
        static readonly RENDER_DISTANCE_NORMAL: 8;
        static readonly RENDER_DISTANCE_FAR: 12;
        hideBundleTutorial: boolean;
        readonly keyUp: Internal.KeyMapping;
        static readonly RENDER_DISTANCE_EXTREME: 32;
        skipMultiplayerWarning: boolean;
        readonly keyShift: Internal.KeyMapping;
        hideGui: boolean;
        readonly keyScreenshot: Internal.KeyMapping;
        pauseOnLostFocus: boolean;
        languageCode: string;
        readonly keyPlayerList: Internal.KeyMapping;
        static readonly AUTO_GUI_SCALE: 0;
        readonly keyRight: Internal.KeyMapping;
        smoothCamera: boolean;
        readonly keyCommand: Internal.KeyMapping;
        readonly keyAttack: Internal.KeyMapping;
        renderFpsChart: boolean;
        readonly keyChat: Internal.KeyMapping;
        readonly keyPickItem: Internal.KeyMapping;
        joinedFirstServer: boolean;
        static readonly RENDER_DISTANCE_TINY: 2;
        incompatibleResourcePacks: Internal.List<string>;
        readonly keyFullscreen: Internal.KeyMapping;
        skipRealms32bitWarning: boolean;
        fullscreenVideoModeString: string;
        useNativeTransport: boolean;
        glDebugVerbosity: number;
        readonly keyTogglePerspective: Internal.KeyMapping;
        static readonly RENDER_DISTANCE_REALLY_FAR: 16;
        readonly keySmoothCamera: Internal.KeyMapping;
        static readonly UNLIMITED_FRAMERATE_CUTOFF: 260;
        overrideWidth: number;
        readonly keySaveHotbarActivator: Internal.KeyMapping;
        static readonly RENDER_DISTANCE_SHORT: 4;
        overrideHeight: number;
        renderDebug: boolean;
        lastMpIp: string;
        readonly keyAdvancements: Internal.KeyMapping;
        readonly keyLeft: Internal.KeyMapping;
        readonly keyJump: Internal.KeyMapping;
        readonly keyUse: Internal.KeyMapping;
        readonly keyDrop: Internal.KeyMapping;
        onboardAccessibility: boolean;
        resourcePacks: Internal.List<string>;
        readonly keySocialInteractions: Internal.KeyMapping;
        readonly keySpectatorOutlines: Internal.KeyMapping;
        readonly keySprint: Internal.KeyMapping;
        readonly keyInventory: Internal.KeyMapping;
        readonly keyLoadHotbarActivator: Internal.KeyMapping;
        advancedItemTooltips: boolean;
        renderDebugCharts: boolean;
        syncWrites: boolean;
        readonly keyHotbarSlots: Internal.KeyMapping[];
        hideServerAddress: boolean;
        tutorialStep: Internal.TutorialSteps;
        keyMappings: Internal.KeyMapping[];
        static readonly DEFAULT_SOUND_DEVICE: "";
    }
    type Options_ = Options;
    interface Weighted <T> {
        abstract getSound(arg0: Internal.RandomSource_): T;
        abstract getWeight(): number;
        abstract preloadIfRequired(arg0: Internal.SoundEngine_): void;
        get weight(): number
    }
    type Weighted_<T> = Weighted<T>;
    class SecurityMode extends Internal.Enum<Internal.SecurityMode> implements Internal.IHasTextComponent, Internal.IIncrementalEnum<Internal.SecurityMode> {
        static byIndexStatic(arg0: number): Internal.SecurityMode;
        getNext(): this;
        static valueOf(arg0: string): Internal.SecurityMode;
        adjust(arg0: number, arg1: Internal.Predicate_<Internal.SecurityMode>): this;
        getNext(arg0: Internal.Predicate_<Internal.SecurityMode>): this;
        static values(): Internal.SecurityMode[];
        getPrevious(arg0: Internal.Predicate_<Internal.SecurityMode>): this;
        getPrevious(): this;
        byIndex(arg0: number): this;
        getTextComponent(): net.minecraft.network.chat.Component;
        adjust(arg0: number): this;
        get next(): Internal.SecurityMode
        get previous(): Internal.SecurityMode
        get textComponent(): net.minecraft.network.chat.Component
        static readonly PUBLIC: Internal.SecurityMode;
        static readonly PRIVATE: Internal.SecurityMode;
        static readonly TRUSTED: Internal.SecurityMode;
    }
    type SecurityMode_ = SecurityMode | "public" | "trusted" | "private";
    class Heightmap {
        constructor(arg0: Internal.ChunkAccess_, arg1: Internal.Heightmap$Types_)
        getHighestTaken(arg0: number, arg1: number): number;
        static primeHeightmaps(arg0: Internal.ChunkAccess_, arg1: Internal.Set_<Internal.Heightmap$Types>): void;
        getFirstAvailable(arg0: number, arg1: number): number;
        getRawData(): number[];
        update(arg0: number, arg1: number, arg2: number, arg3: Internal.BlockState_): boolean;
        setRawData(arg0: Internal.ChunkAccess_, arg1: Internal.Heightmap$Types_, arg2: number[]): void;
        get rawData(): number[]
    }
    type Heightmap_ = Heightmap;
    class CustomCommandEventJS extends Internal.EntityEventJS {
        constructor(l: Internal.Level_, e: Internal.Entity_, p: BlockPos_, i: string)
        getId(): string;
        getBlock(): Internal.BlockContainerJS;
        get id(): string
        get block(): Internal.BlockContainerJS
    }
    type CustomCommandEventJS_ = CustomCommandEventJS;
    interface RepeatedDelayStrategy {
        abstract delayCyclesAfterSuccess(): number;
        exponentialBackoff(arg0: number): this;
        abstract delayCyclesAfterFailure(): number;
        readonly CONSTANT: Internal.RepeatedDelayStrategy;
    }
    type RepeatedDelayStrategy_ = RepeatedDelayStrategy;
    abstract class AbstractWidget implements Internal.LayoutElement, Internal.NarratableEntry, Internal.GuiEventListener, Internal.UniqueWidget, Internal.CustomizableWidget, Internal.IMixinAbstractWidget, Internal.Renderable {
        constructor(arg0: number, arg1: number, arg2: number, arg3: number, arg4: net.minecraft.network.chat.Component_)
        charTyped(arg0: string, arg1: number): boolean;
        setCustomBackgroundNormalFancyMenu(arg0: Internal.RenderableResource_): void;
        onRelease(arg0: number, arg1: number): void;
        getY(): number;
        setFocused(arg0: boolean): void;
        mouseClicked(arg0: number, arg1: number, arg2: number): boolean;
        keyReleased(arg0: number, arg1: number, arg2: number): boolean;
        getTooltip(): Internal.Tooltip;
        addHoverOrFocusStateListenerFancyMenu(arg0: Internal.Consumer_<any>): void;
        onClick(arg0: number, arg1: number): void;
        setAlpha(arg0: number): void;
        getAlphaFancyMenu(): number;
        setCustomYFancyMenu(arg0: number): void;
        nextFocusPath(arg0: Internal.FocusNavigationEvent_): Internal.ComponentPath;
        setLastHoverStateFancyMenu(arg0: boolean): void;
        getWidth(): number;
        getLastHoverOrFocusStateFancyMenu(): boolean;
        isNineSliceCustomBackgroundTexture_FancyMenu(): boolean;
        keyPressed(arg0: number, arg1: number, arg2: number): boolean;
        setCustomBackgroundHoverFancyMenu(arg0: Internal.RenderableResource_): void;
        setHiddenFancyMenu(arg0: boolean): void;
        isHoveredOrFocused(): boolean;
        render(arg0: Internal.GuiGraphics_, arg1: number, arg2: number, arg3: number): void;
        setMessage(arg0: net.minecraft.network.chat.Component_): void;
        setMessageFieldFancyMenu(arg0: net.minecraft.network.chat.Component_): void;
        setHoverSoundFancyMenu(arg0: Internal.IAudio_): void;
        isFocused(): boolean;
        getX(): number;
        setCustomHeightFancyMenu(arg0: number): void;
        getCustomLabelFancyMenu(): net.minecraft.network.chat.Component;
        isActive(): boolean;
        getTabOrderGroup(): number;
        tickHoverStateListenersFancyMenu(arg0: boolean): void;
        setCustomLabelFancyMenu(arg0: net.minecraft.network.chat.Component_): void;
        getMessage(): net.minecraft.network.chat.Component;
        getCustomWidthFancyMenu(): number;
        getCustomHeightFancyMenu(): number;
        setWidth(arg0: number): void;
        getHeight(): number;
        resetWidgetSizeAndPositionFancyMenu(): void;
        getFGColor(): number;
        narrationPriority(): Internal.NarratableEntry$NarrationPriority;
        setCustomClickSoundFancyMenu(arg0: Internal.IAudio_): void;
        isHiddenFancyMenu(): boolean;
        playDownSound(arg0: Internal.SoundManager_): void;
        setCustomXFancyMenu(arg0: number): void;
        static wrapDefaultNarrationMessage(arg0: net.minecraft.network.chat.Component_): Internal.MutableComponent;
        getFocusStateListenersFancyMenu(): Internal.List<any>;
        getCurrentFocusPath(): Internal.ComponentPath;
        setFGColor(arg0: number): void;
        getHoverStateListenersFancyMenu(): Internal.List<any>;
        setHeight(arg0: number): void;
        getCustomClickSoundFancyMenu(): Internal.IAudio;
        setCustomBackgroundResetBehaviorFancyMenu(arg0: Internal.CustomizableWidget$CustomBackgroundResetBehavior_): void;
        setLastHoverOrFocusStateFancyMenu(arg0: boolean): void;
        setWidgetIdentifierFancyMenu(arg0: string): this;
        getHoverLabelFancyMenu(): net.minecraft.network.chat.Component;
        setTooltip(arg0: Internal.Tooltip_): void;
        getResetCustomizationsListenersFancyMenu(): Internal.List<any>;
        clearFGColor(): void;
        setX(arg0: number): void;
        resetWidgetCustomizationsFancyMenu(): void;
        mouseMoved(arg0: number, arg1: number): void;
        tickHoverOrFocusStateListenersFancyMenu(arg0: boolean): void;
        getRectangle(): Internal.ScreenRectangle;
        setCustomWidthFancyMenu(arg0: number): void;
        getWidgetIdentifierFancyMenu(): string;
        isHovered(): boolean;
        getCustomXFancyMenu(): number;
        setHoverLabelFancyMenu(arg0: net.minecraft.network.chat.Component_): void;
        addHoverStateListenerFancyMenu(arg0: Internal.Consumer_<any>): void;
        setPosition(arg0: number, arg1: number): void;
        getLastFocusStateFancyMenu(): boolean;
        addResetCustomizationsListenerFancyMenu(arg0: Internal.Runnable_): void;
        setHeightFancyMenu(arg0: number): void;
        visitWidgets(arg0: Internal.Consumer_<Internal.AbstractWidget>): void;
        tickFocusStateListenersFancyMenu(arg0: boolean): void;
        isMouseOver(arg0: number, arg1: number): boolean;
        setLastFocusStateFancyMenu(arg0: boolean): void;
        getHoverSoundFancyMenu(): Internal.IAudio;
        getCustomBackgroundResetBehaviorFancyMenu(): Internal.CustomizableWidget$CustomBackgroundResetBehavior;
        getLastHoverStateFancyMenu(): boolean;
        getHoverOrFocusStateListenersFancyMenu(): Internal.List<any>;
        setCustomBackgroundInactiveFancyMenu(arg0: Internal.RenderableResource_): void;
        setNineSliceCustomBackground_FancyMenu(arg0: boolean): void;
        mouseScrolled(arg0: number, arg1: number, arg2: number): boolean;
        setTooltipDelay(arg0: number): void;
        getCustomYFancyMenu(): number;
        setY(arg0: number): void;
        getNineSliceCustomBackgroundBorderX_FancyMenu(): number;
        mouseDragged(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number): boolean;
        setNineSliceBorderY_FancyMenu(arg0: number): void;
        getNineSliceCustomBackgroundBorderY_FancyMenu(): number;
        getCustomBackgroundNormalFancyMenu(): Internal.RenderableResource;
        setTabOrderGroup(arg0: number): void;
        setNineSliceBorderX_FancyMenu(arg0: number): void;
        getCustomBackgroundHoverFancyMenu(): Internal.RenderableResource;
        getCustomBackgroundInactiveFancyMenu(): Internal.RenderableResource;
        renderTexture(arg0: Internal.GuiGraphics_, arg1: ResourceLocation_, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number, arg7: number, arg8: number, arg9: number, arg10: number): void;
        addFocusStateListenerFancyMenu(arg0: Internal.Consumer_<any>): void;
        mouseReleased(arg0: number, arg1: number, arg2: number): boolean;
        getOriginalMessageFancyMenu(): net.minecraft.network.chat.Component;
        updateNarration(arg0: Internal.NarrationElementOutput_): void;
        renderCustomBackgroundFancyMenu(arg0: Internal.AbstractWidget_, arg1: Internal.GuiGraphics_, arg2: number, arg3: number, arg4: number, arg5: number): boolean;
        set customBackgroundNormalFancyMenu(arg0: Internal.RenderableResource_)
        get y(): number
        set focused(arg0: boolean)
        get tooltip(): Internal.Tooltip
        set alpha(arg0: number)
        get alphaFancyMenu(): number
        set customYFancyMenu(arg0: number)
        set lastHoverStateFancyMenu(arg0: boolean)
        get width(): number
        get lastHoverOrFocusStateFancyMenu(): boolean
        get nineSliceCustomBackgroundTexture_FancyMenu(): boolean
        set customBackgroundHoverFancyMenu(arg0: Internal.RenderableResource_)
        set hiddenFancyMenu(arg0: boolean)
        get hoveredOrFocused(): boolean
        set message(arg0: net.minecraft.network.chat.Component_)
        set messageFieldFancyMenu(arg0: net.minecraft.network.chat.Component_)
        set hoverSoundFancyMenu(arg0: Internal.IAudio_)
        get focused(): boolean
        get x(): number
        set customHeightFancyMenu(arg0: number)
        get customLabelFancyMenu(): net.minecraft.network.chat.Component
        get active(): boolean
        get tabOrderGroup(): number
        set customLabelFancyMenu(arg0: net.minecraft.network.chat.Component_)
        get message(): net.minecraft.network.chat.Component
        get customWidthFancyMenu(): number
        get customHeightFancyMenu(): number
        set width(arg0: number)
        get height(): number
        get FGColor(): number
        set customClickSoundFancyMenu(arg0: Internal.IAudio_)
        get hiddenFancyMenu(): boolean
        set customXFancyMenu(arg0: number)
        get focusStateListenersFancyMenu(): Internal.List<any>
        get currentFocusPath(): Internal.ComponentPath
        set FGColor(arg0: number)
        get hoverStateListenersFancyMenu(): Internal.List<any>
        set height(arg0: number)
        get customClickSoundFancyMenu(): Internal.IAudio
        set customBackgroundResetBehaviorFancyMenu(arg0: Internal.CustomizableWidget$CustomBackgroundResetBehavior_)
        set lastHoverOrFocusStateFancyMenu(arg0: boolean)
        set widgetIdentifierFancyMenu(arg0: string)
        get hoverLabelFancyMenu(): net.minecraft.network.chat.Component
        set tooltip(arg0: Internal.Tooltip_)
        get resetCustomizationsListenersFancyMenu(): Internal.List<any>
        set x(arg0: number)
        get rectangle(): Internal.ScreenRectangle
        set customWidthFancyMenu(arg0: number)
        get widgetIdentifierFancyMenu(): string
        get hovered(): boolean
        get customXFancyMenu(): number
        set hoverLabelFancyMenu(arg0: net.minecraft.network.chat.Component_)
        get lastFocusStateFancyMenu(): boolean
        set heightFancyMenu(arg0: number)
        set lastFocusStateFancyMenu(arg0: boolean)
        get hoverSoundFancyMenu(): Internal.IAudio
        get customBackgroundResetBehaviorFancyMenu(): Internal.CustomizableWidget$CustomBackgroundResetBehavior
        get lastHoverStateFancyMenu(): boolean
        get hoverOrFocusStateListenersFancyMenu(): Internal.List<any>
        set customBackgroundInactiveFancyMenu(arg0: Internal.RenderableResource_)
        set nineSliceCustomBackground_FancyMenu(arg0: boolean)
        set tooltipDelay(arg0: number)
        get customYFancyMenu(): number
        set y(arg0: number)
        get nineSliceCustomBackgroundBorderX_FancyMenu(): number
        set nineSliceBorderY_FancyMenu(arg0: number)
        get nineSliceCustomBackgroundBorderY_FancyMenu(): number
        get customBackgroundNormalFancyMenu(): Internal.RenderableResource
        set tabOrderGroup(arg0: number)
        set nineSliceBorderX_FancyMenu(arg0: number)
        get customBackgroundHoverFancyMenu(): Internal.RenderableResource
        get customBackgroundInactiveFancyMenu(): Internal.RenderableResource
        get originalMessageFancyMenu(): net.minecraft.network.chat.Component
        visible: boolean;
        static readonly WIDGETS_LOCATION: ResourceLocation;
        height: number;
        static readonly ACCESSIBILITY_TEXTURE: ResourceLocation;
        x: number;
        y: number;
        static readonly UNSET_FG_COLOR: -1;
        active: boolean;
        hoverOrFocusedStartTime: number;
    }
    type AbstractWidget_ = AbstractWidget;
    abstract class BackendRenderTarget {
        constructor(width: number, height: number)
        getVkImageInfo(info: Internal.VulkanImageInfo_): boolean;
        getGLFramebufferInfo(info: Internal.GLFramebufferInfo_): boolean;
        getWidth(): number;
        abstract isProtected(): boolean;
        abstract getBackendFormat(): Internal.BackendFormat;
        setVkImageLayout(layout: number): void;
        getHeight(): number;
        abstract getBackend(): number;
        setVkQueueFamilyIndex(queueFamilyIndex: number): void;
        abstract getSampleCount(): number;
        abstract getStencilBits(): number;
        get width(): number
        get "protected"(): boolean
        get backendFormat(): Internal.BackendFormat
        set vkImageLayout(layout: number)
        get height(): number
        get backend(): number
        set vkQueueFamilyIndex(queueFamilyIndex: number)
        get sampleCount(): number
        get stencilBits(): number
    }
    type BackendRenderTarget_ = BackendRenderTarget;
    class QIOCraftingTransferHelper$SingularHashedItemSource {
        constructor(qioSource: Internal.UUID_, used: number)
        constructor(slot: number, used: number)
        getSlot(): number;
        getQioSource(): Internal.UUID;
        setUsed(used: number): void;
        getUsed(): number;
        get slot(): number
        get qioSource(): Internal.UUID
        set used(used: number)
        get used(): number
    }
    type QIOCraftingTransferHelper$SingularHashedItemSource_ = QIOCraftingTransferHelper$SingularHashedItemSource;
    class EntityEvent extends net.minecraftforge.eventbus.api.Event {
        constructor()
        constructor(arg0: Internal.Entity_)
        getEntity(): Internal.Entity;
        get entity(): Internal.Entity
    }
    type EntityEvent_ = EntityEvent;
    class ModWallHangingSignBlock extends Internal.WallHangingSignBlock {
        constructor(properties: Internal.BlockBehaviour$Properties_, type: Internal.WoodType_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type ModWallHangingSignBlock_ = ModWallHangingSignBlock;
    class State extends Internal.Enum<Internal.State> {
        static values(): Internal.State[];
        isExtraLoud(): boolean;
        getTransitionDestination(): this;
        canTransition(): boolean;
        getName(): string;
        static valueOf(name: string): Internal.State;
        get extraLoud(): boolean
        get transitionDestination(): Internal.State
        get name(): string
        static readonly DOWN: Internal.State;
        static readonly WANDER: Internal.State;
        static readonly CLIMB_RUN: Internal.State;
        static readonly JUMP: Internal.State;
        static readonly CLIMB: Internal.State;
        static readonly UP_RUN: Internal.State;
        static readonly DOWN_RUN: Internal.State;
        static readonly SWIM: Internal.State;
        static readonly WALK: Internal.State;
        static readonly STAND: Internal.State;
        static readonly RUN: Internal.State;
        static readonly UP: Internal.State;
        static readonly LAND: Internal.State;
    }
    type State_ = "wander" | "jump" | "down" | "walk" | "climb" | "up_run" | "swim" | "run" | "stand" | "climb_run" | "land" | "up" | State | "down_run";
    class Chair extends Internal.FurnitureObjectNonFaceable {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type Chair_ = Chair;
    class Realms32BitWarningStatus {
        constructor(arg0: Internal.Minecraft_)
        showRealms32BitWarningIfNeeded(arg0: Internal.Screen_): void;
    }
    type Realms32BitWarningStatus_ = Realms32BitWarningStatus;
    class ModelQuadFacing extends Internal.Enum<Internal.ModelQuadFacing> {
        static fromDirection(arg0: Internal.Direction_): Internal.ModelQuadFacing;
        static values(): Internal.ModelQuadFacing[];
        static valueOf(arg0: string): Internal.ModelQuadFacing;
        getOpposite(): this;
        get opposite(): Internal.ModelQuadFacing
        static readonly NEG_X: Internal.ModelQuadFacing;
        static readonly UNASSIGNED: Internal.ModelQuadFacing;
        static readonly NONE: 0;
        static readonly NEG_Y: Internal.ModelQuadFacing;
        static readonly COUNT: 7;
        static readonly POS_Z: Internal.ModelQuadFacing;
        static readonly NEG_Z: Internal.ModelQuadFacing;
        static readonly POS_X: Internal.ModelQuadFacing;
        static readonly VALUES: Internal.ModelQuadFacing[];
        static readonly ALL: 127;
        static readonly POS_Y: Internal.ModelQuadFacing;
    }
    type ModelQuadFacing_ = "unassigned" | "pos_z" | "neg_z" | "pos_y" | "neg_y" | "pos_x" | "neg_x" | ModelQuadFacing;
    class PrivacyMode extends Internal.Enum<Internal.PrivacyMode> implements Internal.StringRepresentable {
        static keys(arg0: Internal.StringRepresentable_[]): Internal.Keyable;
        static fromEnumWithMapping<E extends Internal.Enum<E> & Internal.StringRepresentable>(arg0: Internal.Supplier_<E[]>, arg1: Internal.Function_<string, string>): Internal.StringRepresentable$EnumCodec<E>;
        static fromEnum<E extends Internal.Enum<E> & Internal.StringRepresentable>(arg0: Internal.Supplier_<E[]>): Internal.StringRepresentable$EnumCodec<E>;
        static values(): Internal.PrivacyMode[];
        getSerializedName(): string;
        static valueOf(name: string): Internal.PrivacyMode;
        get serializedName(): string
        readonly name: string;
        static readonly ALLIES: Internal.PrivacyMode;
        static readonly PUBLIC: Internal.PrivacyMode;
        static readonly NAME_MAP: Internal.NameMap<Internal.PrivacyMode>;
        static readonly PRIVATE: Internal.PrivacyMode;
        static readonly VALUES: Internal.PrivacyMode[];
    }
    type PrivacyMode_ = "public" | "allies" | PrivacyMode | "private";
    class InteractionResultHolder <T> {
        constructor(arg0: Internal.InteractionResult_, arg1: T)
        getResult(): Internal.InteractionResult;
        static fail<T>(arg0: T): Internal.InteractionResultHolder<T>;
        static consume<T>(arg0: T): Internal.InteractionResultHolder<T>;
        getObject(): T;
        static success<T>(arg0: T): Internal.InteractionResultHolder<T>;
        static sidedSuccess<T>(arg0: T, arg1: boolean): Internal.InteractionResultHolder<T>;
        static pass<T>(arg0: T): Internal.InteractionResultHolder<T>;
        get result(): Internal.InteractionResult
        get object(): T
    }
    type InteractionResultHolder_<T> = InteractionResultHolder<T>;
    class ModBlocks$16 extends Internal.TrapDoorBlock {
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type ModBlocks$16_ = ModBlocks$16;
    class ModBlocks$17 extends Internal.DoorBlock {
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type ModBlocks$17_ = ModBlocks$17;
    class ModBlocks$14 extends Internal.TrapDoorBlock {
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type ModBlocks$14_ = ModBlocks$14;
    class ModBlocks$15 extends Internal.DoorBlock {
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type ModBlocks$15_ = ModBlocks$15;
    class StoringChunkProgressListener implements Internal.ChunkProgressListener {
        constructor(arg0: number)
        getProgress(): number;
        start(): void;
        getFullDiameter(): number;
        getStatus(arg0: number, arg1: number): Internal.ChunkStatus;
        getDiameter(): number;
        stop(): void;
        onStatusChange(arg0: Internal.ChunkPos_, arg1: Internal.ChunkStatus_): void;
        updateSpawnPos(arg0: Internal.ChunkPos_): void;
        get progress(): number
        get fullDiameter(): number
        get diameter(): number
    }
    type StoringChunkProgressListener_ = StoringChunkProgressListener;
    class PushBox {
        constructor(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number)
        getVerticalBias(): number;
        postUpdate(): void;
        getW(arg0: number, arg1: number): number;
        getX(arg0: number, arg1: number): number;
        update(): void;
        getH(arg0: number, arg1: number): number;
        getY(arg0: number, arg1: number): number;
        getAnchorY(): number;
        getAnchorX(): number;
        isActive(): boolean;
        setActive(arg0: boolean): void;
        push(arg0: Internal.PushboxHandler$State_, arg1: number, arg2: number): void;
        get verticalBias(): number
        get anchorY(): number
        get anchorX(): number
        get active(): boolean
        set active(arg0: boolean)
    }
    type PushBox_ = PushBox;
    class BuilderType <T> extends Internal.Record {
        constructor(type: string, builderClass: Internal.BuilderBase<T>, factory: Internal.BuilderFactory_)
        factory(): Internal.BuilderFactory;
        type(): string;
        builderClass(): Internal.BuilderBase<T>;
    }
    type BuilderType_<T> = BuilderType<T>;
    class ModBlocks$18 extends Internal.TrapDoorBlock {
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type ModBlocks$18_ = ModBlocks$18;
    class ModBlocks$19 extends Internal.FenceGateBlock {
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type ModBlocks$19_ = ModBlocks$19;
    class TileEntityThermodynamicConductor extends Internal.TileEntityTransmitter {
        constructor(blockProvider: Internal.IBlockProvider_, pos: BlockPos_, state: Internal.BlockState_)
        getTransmitter(): Internal.ThermodynamicConductor;
        deserializeNBT(arg0: Internal.CompoundTag_): void;
        onRightClick(player: Internal.Player_): Internal.InteractionResult;
        onSneakRightClick(player: Internal.Player_): Internal.InteractionResult;
        deserializeNBT(arg0: Internal.Tag_): void;
        requestModelDataUpdate(): void;
        onLoad(): void;
        serializeNBT(): Internal.Tag;
        tdv$setDynamicLightEnabled(arg0: boolean): void;
        getCapability<T>(arg0: Internal.Capability_<T>): Internal.LazyOptional<T>;
        tdv$isDynamicLightEnabled(): boolean;
        hasCustomOutlineRendering(arg0: Internal.Player_): boolean;
        get transmitter(): Internal.ThermodynamicConductor
    }
    type TileEntityThermodynamicConductor_ = TileEntityThermodynamicConductor;
    class BlockContainerJS implements Internal.SpecialEquality {
        constructor(blockEntity: Internal.BlockEntity_)
        constructor(w: Internal.Level_, p: BlockPos_)
        getTags(): Internal.Collection<ResourceLocation>;
        getWest(): this;
        getY(): number;
        static checkSpecialEquality(o: any, o1: any, shallow: boolean): boolean;
        getNorth(): this;
        getBlockLight(): number;
        spawnLightning(): void;
        spawnFireworks(fireworks: Internal.FireworksJS_): void;
        getPos(): BlockPos;
        getDown(): this;
        getLight(): number;
        getDrops(): Internal.List<Internal.ItemStack>;
        getSouth(): this;
        getSkyLight(): number;
        mergeEntityData(tag: Internal.CompoundTag_): void;
        getCanSeeSky(): boolean;
        getDimension(): ResourceLocation;
        getBlockState(): Internal.BlockState;
        specialEquals(o: any, shallow: boolean): boolean;
        hasTag(tag: ResourceLocation_): boolean;
        getTypeData(): Internal.CompoundTag;
        getInventory(): Internal.InventoryKJS;
        offset(x: number, y: number, z: number): this;
        offset(f: Internal.Direction_): this;
        offset(f: Internal.Direction_, d: number): this;
        spawnLightning(effectOnly: boolean, player: Internal.ServerPlayer_): void;
        getEast(): this;
        getEntityId(): string;
        getX(): number;
        createEntity(type: Internal.EntityType_<any>): Internal.Entity;
        getDrops(entity: Internal.Entity_, heldItem: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        set(id: ResourceLocation_, properties: Internal.Map_<any, any>): void;
        popItem(item: Internal.ItemStack_): void;
        set(id: ResourceLocation_, properties: Internal.Map_<any, any>, flags: number): void;
        getLevel(): Internal.Level;
        setBlockState(state: Internal.BlockState_, flags: number): void;
        popItemFromFace(item: Internal.ItemStack_, dir: Internal.Direction_): void;
        getEntity(): Internal.BlockEntity;
        getPlayersInRadius(radius: number): Internal.EntityArrayList;
        clearCache(): void;
        getUp(): this;
        getZ(): number;
        getEntityData(): Internal.CompoundTag;
        spawnLightning(effectOnly: boolean): void;
        getItem(): Internal.ItemStack;
        getInventory(facing: Internal.Direction_): Internal.InventoryKJS;
        getId(): string;
        canSeeSkyFromBelowWater(): boolean;
        getProperties(): Internal.Map<string, string>;
        createExplosion(): Internal.ExplosionJS;
        setEntityData(tag: Internal.CompoundTag_): void;
        set(id: ResourceLocation_): void;
        getPlayersInRadius(): Internal.EntityArrayList;
        getBiomeId(): ResourceLocation;
        get tags(): Internal.Collection<ResourceLocation>
        get west(): Internal.BlockContainerJS
        get y(): number
        get north(): Internal.BlockContainerJS
        get blockLight(): number
        get pos(): BlockPos
        get down(): Internal.BlockContainerJS
        get light(): number
        get drops(): Internal.List<Internal.ItemStack>
        get south(): Internal.BlockContainerJS
        get skyLight(): number
        get canSeeSky(): boolean
        get dimension(): ResourceLocation
        get blockState(): Internal.BlockState
        get typeData(): Internal.CompoundTag
        get inventory(): Internal.InventoryKJS
        get east(): Internal.BlockContainerJS
        get entityId(): string
        get x(): number
        get level(): Internal.Level
        get entity(): Internal.BlockEntity
        get up(): Internal.BlockContainerJS
        get z(): number
        get entityData(): Internal.CompoundTag
        get item(): Internal.ItemStack
        get id(): string
        get properties(): Internal.Map<string, string>
        set entityData(tag: Internal.CompoundTag_)
        get playersInRadius(): Internal.EntityArrayList
        get biomeId(): ResourceLocation
        readonly minecraftLevel: Internal.Level;
    }
    type BlockContainerJS_ = BlockContainerJS;
    class ModBlocks$20 extends Internal.ButtonBlock {
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type ModBlocks$20_ = ModBlocks$20;
    class ModBlocks$21 extends Internal.PressurePlateBlock {
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type ModBlocks$21_ = ModBlocks$21;
    class EnderDragon extends Internal.Mob implements Internal.Enemy {
        constructor(arg0: Internal.EntityType_<Internal.EnderDragon>, arg1: Internal.Level_)
        getHeadLookVector(arg0: number): Vec3d;
        getDistance(pos: BlockPos_): number;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number): void;
        removeAttribute(attribute: Internal.Attribute_, identifier: string): void;
        playSound(id: Internal.SoundEvent_, volume: number, pitch: number): void;
        setDefaultMovementSpeedMultiplier(speed: number): void;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        getLatencyPos(arg0: number, arg1: number): number[];
        getOffHandItem(): Internal.ItemStack;
        isOnScoreboardTeam(teamId: string): boolean;
        getEquipment(slot: Internal.EquipmentSlot_): Internal.ItemStack;
        swing(): void;
        getPickedResult(arg0: Internal.HitResult_): Internal.ItemStack;
        hurt(arg0: Internal.EnderDragonPart_, arg1: DamageSource_, arg2: number): boolean;
        runCommandSilent(command: string): number;
        setPosition(x: number, y: number, z: number): void;
        canStartSwimming(): boolean;
        isPlayer(): boolean;
        isAnimal(): boolean;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        setY(y: number): void;
        getCapability<T>(arg0: Internal.Capability_<T>): Internal.LazyOptional<T>;
        isLiving(): boolean;
        damageEquipment(slot: Internal.EquipmentSlot_): void;
        rayTrace(): Internal.RayTraceResultJS;
        getTotalMovementSpeed(): number;
        alwaysAccepts(): boolean;
        moveInFluid(arg0: Internal.FluidState_, arg1: Vec3d_, arg2: number): boolean;
        isInFluidType(arg0: Internal.FluidState_): boolean;
        getSubEntities(): Internal.EnderDragonPart[];
        findClosestNode(): number;
        damageHeldItem(): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        shouldUpdateFluidWhileBoating(arg0: Internal.FluidState_, arg1: Internal.Boat_): boolean;
        setMotionZ(z: number): void;
        setPosition(block: Internal.BlockContainerJS_): void;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        attack(hp: number): void;
        canSwimInFluidType(arg0: Internal.FluidType_): boolean;
        getFightOrigin(): BlockPos;
        getTeamId(): string;
        setMaxHealth(hp: number): void;
        canBeRiddenUnderFluidType(arg0: Internal.FluidType_, arg1: Internal.Entity_): boolean;
        getFacing(): Internal.Direction;
        onCrystalDestroyed(arg0: Internal.EndCrystal_, arg1: BlockPos_, arg2: DamageSource_): void;
        shouldRiderSit(): boolean;
        getLegsArmorItem(): Internal.ItemStack;
        setMainHandItem(item: Internal.ItemStack_): void;
        isHoldingInAnyHand(i: Internal.Ingredient_): boolean;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        isInFluidType(arg0: Internal.FluidType_): boolean;
        getReachDistance(): number;
        getFluidMotionScale(arg0: Internal.FluidType_): number;
        getMotionX(): number;
        isWaterCreature(): boolean;
        getItem(): Internal.ItemStack;
        setX(x: number): void;
        setAttributeBaseValue(attribute: Internal.Attribute_, value: number): void;
        findClosestNode(arg0: number, arg1: number, arg2: number): number;
        getPotionEffects(): Internal.EntityPotionEffectsJS;
        isFrame(): boolean;
        setLegsArmorItem(item: Internal.ItemStack_): void;
        playSound(id: Internal.SoundEvent_): void;
        foodEaten(is: Internal.ItemStack_): void;
        self(): Internal.LivingEntity;
        getDefaultMovementSpeed(): number;
        getHeldItem(hand: Internal.InteractionHand_): Internal.ItemStack;
        swing(hand: Internal.InteractionHand_): void;
        onFlap(): void;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        static createAttributes(): Internal.AttributeSupplier$Builder;
        getAttributeTotalValue(attribute: Internal.Attribute_): number;
        isPeacefulCreature(): boolean;
        isUndead(): boolean;
        setRotation(yaw: number, pitch: number): void;
        getStepHeight(): number;
        isAmbientCreature(): boolean;
        setFightOrigin(arg0: BlockPos_): void;
        getSoundFromFluidType(arg0: Internal.FluidType_, arg1: Internal.SoundAction_): Internal.SoundEvent;
        isMonster(): boolean;
        canHydrateInFluidType(arg0: Internal.FluidType_): boolean;
        getType(): string;
        self(): Internal.Entity;
        setChestArmorItem(item: Internal.ItemStack_): void;
        getBlock(): Internal.BlockContainerJS;
        getNbt(): Internal.CompoundTag;
        setEquipment(slot: Internal.EquipmentSlot_, item: Internal.ItemStack_): void;
        getMotionY(): number;
        getName(): net.minecraft.network.chat.Component;
        getPassengers(): Internal.EntityArrayList;
        setTotalMovementSpeedMultiplier(speed: number): void;
        getFluidFallDistanceModifier(arg0: Internal.FluidType_): number;
        isInFluidType(arg0: Internal.BiPredicate_<Internal.FluidType, number>): boolean;
        setHeldItem(hand: Internal.InteractionHand_, item: Internal.ItemStack_): void;
        canFluidExtinguish(arg0: Internal.FluidType_): boolean;
        isFlapping(): boolean;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        getHeadPartYOffset(arg0: number, arg1: number[], arg2: number[]): number;
        isPushedByFluid(arg0: Internal.FluidType_): boolean;
        getFeetArmorItem(): Internal.ItemStack;
        setOffHandItem(item: Internal.ItemStack_): void;
        setDefaultMovementSpeed(speed: number): void;
        sinkInFluid(arg0: Internal.FluidType_): void;
        getMainHandItem(): Internal.ItemStack;
        spawn(): void;
        getServer(): Internal.MinecraftServer;
        setMotionX(x: number): void;
        canEntityBeSeen(entity: Internal.LivingEntity_): boolean;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        tdv$isDynamicLightEnabled(): boolean;
        setNbt(nbt: Internal.CompoundTag_): void;
        getLevel(): Internal.Level;
        getScriptType(): Internal.ScriptType;
        setDragonFight(arg0: Internal.EndDragonFight_): void;
        setMovementSpeedAddition(speed: number): void;
        getHeadArmorItem(): Internal.ItemStack;
        modifyAttribute(attribute: Internal.Attribute_, identifier: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        tdv$setDynamicLightEnabled(arg0: boolean): void;
        setFeetArmorItem(item: Internal.ItemStack_): void;
        setPositionAndRotation(x: number, y: number, z: number, yaw: number, pitch: number): void;
        hasCustomOutlineRendering(arg0: Internal.Player_): boolean;
        findPath(arg0: number, arg1: number, arg2: Internal.Node_): net.minecraft.world.level.pathfinder.Path;
        getPhaseManager(): Internal.EnderDragonPhaseManager;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        getEyeHeightForge(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        getChestArmorItem(): Internal.ItemStack;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number): void;
        getMotionZ(): number;
        tell(message: net.minecraft.network.chat.Component_): void;
        serializeNBT(): Internal.CompoundTag;
        setZ(z: number): void;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        deserializeNBT(arg0: Internal.CompoundTag_): void;
        isEyeInFluidType(arg0: Internal.FluidType_): boolean;
        getDistanceSq(pos: BlockPos_): number;
        getDragonFight(): Internal.EndDragonFight;
        getProfile(): Internal.GameProfile;
        getAttributeBaseValue(attribute: Internal.Attribute_): number;
        setHeadArmorItem(item: Internal.ItemStack_): void;
        getClassification(arg0: boolean): Internal.MobCategory;
        runCommand(command: string): number;
        canDrownInFluidType(arg0: Internal.FluidType_): boolean;
        set defaultMovementSpeedMultiplier(speed: number)
        get offHandItem(): Internal.ItemStack
        get player(): boolean
        get animal(): boolean
        set y(y: number)
        get living(): boolean
        get totalMovementSpeed(): number
        get subEntities(): Internal.EnderDragonPart[]
        get displayName(): net.minecraft.network.chat.Component
        set motionZ(z: number)
        set position(block: Internal.BlockContainerJS_)
        get fightOrigin(): BlockPos
        get teamId(): string
        set maxHealth(hp: number)
        get facing(): Internal.Direction
        get legsArmorItem(): Internal.ItemStack
        set mainHandItem(item: Internal.ItemStack_)
        get reachDistance(): number
        get motionX(): number
        get waterCreature(): boolean
        get item(): Internal.ItemStack
        set x(x: number)
        get potionEffects(): Internal.EntityPotionEffectsJS
        get frame(): boolean
        set legsArmorItem(item: Internal.ItemStack_)
        get defaultMovementSpeed(): number
        set motionY(y: number)
        get peacefulCreature(): boolean
        get undead(): boolean
        get stepHeight(): number
        get ambientCreature(): boolean
        set fightOrigin(arg0: BlockPos_)
        get monster(): boolean
        get type(): string
        set chestArmorItem(item: Internal.ItemStack_)
        get block(): Internal.BlockContainerJS
        get nbt(): Internal.CompoundTag
        get motionY(): number
        get name(): net.minecraft.network.chat.Component
        get passengers(): Internal.EntityArrayList
        set totalMovementSpeedMultiplier(speed: number)
        get flapping(): boolean
        get feetArmorItem(): Internal.ItemStack
        set offHandItem(item: Internal.ItemStack_)
        set defaultMovementSpeed(speed: number)
        get mainHandItem(): Internal.ItemStack
        get server(): Internal.MinecraftServer
        set motionX(x: number)
        set nbt(nbt: Internal.CompoundTag_)
        get level(): Internal.Level
        get scriptType(): Internal.ScriptType
        set dragonFight(arg0: Internal.EndDragonFight_)
        set movementSpeedAddition(speed: number)
        get headArmorItem(): Internal.ItemStack
        set feetArmorItem(item: Internal.ItemStack_)
        get phaseManager(): Internal.EnderDragonPhaseManager
        get chestArmorItem(): Internal.ItemStack
        get motionZ(): number
        set z(z: number)
        set statusMessage(message: net.minecraft.network.chat.Component_)
        get dragonFight(): Internal.EndDragonFight
        get profile(): Internal.GameProfile
        set headArmorItem(item: Internal.ItemStack_)
        oFlapTime: number;
        nearestCrystal: Internal.EndCrystal;
        flapTime: number;
        static readonly DATA_PHASE: Internal.EntityDataAccessor<number>;
        yRotA: number;
        readonly head: Internal.EnderDragonPart;
        dragonDeathTime: number;
        readonly positions: number[][];
        posPointer: number;
        inWall: boolean;
    }
    type EnderDragon_ = EnderDragon;
    class TileEntityMechanicalPipe extends Internal.TileEntityTransmitter implements Internal.IComputerTile {
        constructor(blockProvider: Internal.IBlockProvider_, pos: BlockPos_, state: Internal.BlockState_)
        getTransmitter(): Internal.Transmitter<any, any, any>;
        deserializeNBT(arg0: Internal.Tag_): void;
        requestModelDataUpdate(): void;
        getCapability<T>(arg0: Internal.Capability_<T>): Internal.LazyOptional<T>;
        tdv$isDynamicLightEnabled(): boolean;
        getComputerName(): string;
        hasComputerSupport(): boolean;
        getComputerMethods(holder: Internal.BoundMethodHolder_): void;
        deserializeNBT(arg0: Internal.CompoundTag_): void;
        onRightClick(player: Internal.Player_): Internal.InteractionResult;
        onSneakRightClick(player: Internal.Player_): Internal.InteractionResult;
        onLoad(): void;
        serializeNBT(): Internal.Tag;
        tdv$setDynamicLightEnabled(arg0: boolean): void;
        isComputerCapabilityPersistent(): boolean;
        hasCustomOutlineRendering(arg0: Internal.Player_): boolean;
        get transmitter(): Internal.Transmitter<any, any, any>
        get computerName(): string
        get computerCapabilityPersistent(): boolean
    }
    type TileEntityMechanicalPipe_ = TileEntityMechanicalPipe;
    interface Delayed extends Internal.Comparable<Internal.Delayed> {
        abstract getDelay(arg0: Internal.TimeUnit_): number;
        abstract compareTo(arg0: Internal.Delayed_): number;
    }
    type Delayed_ = Delayed;
    class WaypointWorld {
        constructor(arg0: Internal.WaypointWorldContainer_, arg1: string, arg2: Internal.ResourceKey_<Internal.Level>)
        setId(arg0: string): void;
        getCurrentSet(): Internal.WaypointSet;
        hasSomethingToRemoveOnSave(): boolean;
        getFullId(): string;
        getId(): string;
        getContainer(): Internal.WaypointWorldContainer;
        getInternalWorldKey(): string;
        requestRemovalOnSave(arg0: string): void;
        setCurrent(arg0: string): void;
        onSaveCleanup(arg0: Internal.File_): void;
        addSet(arg0: string): void;
        getServerWaypointsDisabled(): Internal.HashMap<string, boolean>;
        setContainer(arg0: Internal.WaypointWorldContainer_): void;
        getCurrent(): string;
        getServerWaypoints(): Internal.HashMap<number, Internal.Waypoint>;
        getSets(): Internal.HashMap<string, Internal.WaypointSet>;
        getDimId(): Internal.ResourceKey<Internal.Level>;
        set id(arg0: string)
        get currentSet(): Internal.WaypointSet
        get fullId(): string
        get id(): string
        get container(): Internal.WaypointWorldContainer
        get internalWorldKey(): string
        set current(arg0: string)
        get serverWaypointsDisabled(): Internal.HashMap<string, boolean>
        set container(arg0: Internal.WaypointWorldContainer_)
        get current(): string
        get serverWaypoints(): Internal.HashMap<number, Internal.Waypoint>
        get sets(): Internal.HashMap<string, Internal.WaypointSet>
        get dimId(): Internal.ResourceKey<Internal.Level>
    }
    type WaypointWorld_ = WaypointWorld;
    class WrenchResult extends Internal.Enum<Internal.WrenchResult> {
        static values(): Internal.WrenchResult[];
        static valueOf(name: string): Internal.WrenchResult;
        static readonly PASS: Internal.WrenchResult;
        static readonly SUCCESS: Internal.WrenchResult;
        static readonly NO_SECURITY: Internal.WrenchResult;
        static readonly DISMANTLED: Internal.WrenchResult;
    }
    type WrenchResult_ = WrenchResult | "pass" | "no_security" | "success" | "dismantled";
    /**
     * @deprecated
     * This class is marked to be removed in future!
    */
    interface DomainCombiner {
        abstract combine(arg0: Internal.ProtectionDomain_[], arg1: Internal.ProtectionDomain_[]): Internal.ProtectionDomain[];
        (arg0: Internal.ProtectionDomain[], arg1: Internal.ProtectionDomain[]): Internal.ProtectionDomain_[];
    }
    type DomainCombiner_ = DomainCombiner;
    class FilterMask {
        constructor(arg0: number)
        apply(arg0: string): string;
        static read(arg0: Internal.FriendlyByteBuf_): Internal.FilterMask;
        applyWithFormatting(arg0: string): net.minecraft.network.chat.Component;
        isEmpty(): boolean;
        setFiltered(arg0: number): void;
        isFullyFiltered(): boolean;
        static write(arg0: Internal.FriendlyByteBuf_, arg1: Internal.FilterMask_): void;
        get empty(): boolean
        set filtered(arg0: number)
        get fullyFiltered(): boolean
        static readonly CODEC: Internal.Codec<Internal.FilterMask>;
        static readonly FILTERED_STYLE: Internal.Style;
        static readonly PASS_THROUGH: Internal.FilterMask;
        static readonly FULLY_FILTERED: Internal.FilterMask;
    }
    type FilterMask_ = FilterMask;
    class LavaFluid$Flowing extends Internal.LavaFluid {
        constructor()
        getAdjacentBlockPathType(arg0: Internal.FluidState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canHydrate(arg0: Internal.FluidState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: BlockPos_): boolean;
        getExplosionResistance(arg0: Internal.FluidState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        arch$holder(): Internal.Holder<Internal.Fluid>;
        getBlockPathType(arg0: Internal.FluidState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: boolean): Internal.BlockPathTypes;
        supportsBoating(arg0: Internal.FluidState_, arg1: Internal.Boat_): boolean;
        arch$registryName(): ResourceLocation;
        move(arg0: Internal.FluidState_, arg1: Internal.LivingEntity_, arg2: Vec3d_, arg3: number): boolean;
        canExtinguish(arg0: Internal.FluidState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        shouldUpdateWhileBoating(arg0: Internal.FluidState_, arg1: Internal.Boat_, arg2: Internal.Entity_): boolean;
    }
    type LavaFluid$Flowing_ = LavaFluid$Flowing;
    class GameRules implements Internal.GameRulesKJS {
        constructor()
        constructor(arg0: Internal.DynamicLike_<any>)
        set(rule: string, value: string): void;
        kjs$getBoolean(rule: string): boolean;
        createTag(): Internal.CompoundTag;
        kjs$getInt(rule: string): number;
        getRule<T extends Internal.GameRules$Value<T>>(arg0: Internal.GameRules$Key_<T>): T;
        get(rule: string): Internal.GameRules$Value<any>;
        static register<T extends Internal.GameRules$Value<T>>(arg0: string, arg1: Internal.GameRules$Category_, arg2: Internal.GameRules$Type_<T>): Internal.GameRules$Key<T>;
        getBoolean(arg0: Internal.GameRules$Key_<Internal.GameRules$BooleanValue>): boolean;
        static visitGameRuleTypes(arg0: Internal.GameRules$GameRuleTypeVisitor_): void;
        assignFrom(arg0: Internal.GameRules_, arg1: Internal.MinecraftServer_): void;
        kjs$getString(rule: string): string;
        copy(): this;
        getInt(arg0: Internal.GameRules$Key_<Internal.GameRules$IntegerValue>): number;
        static readonly RULE_DO_WARDEN_SPAWNING: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_MAX_COMMAND_CHAIN_LENGTH: Internal.GameRules$Key<Internal.GameRules$IntegerValue>;
        static readonly RULE_MOBGRIEFING: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_DISABLE_ELYTRA_MOVEMENT_CHECK: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_FREEZE_DAMAGE: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_DOINSOMNIA: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_COMMAND_MODIFICATION_BLOCK_LIMIT: Internal.GameRules$Key<Internal.GameRules$IntegerValue>;
        static readonly RULE_DAYLIGHT: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_DO_TRADER_SPAWNING: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_REDUCEDDEBUGINFO: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_DO_IMMEDIATE_RESPAWN: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_DOMOBSPAWNING: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_DOBLOCKDROPS: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_COMMANDBLOCKOUTPUT: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_TNT_EXPLOSION_DROP_DECAY: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_WEATHER_CYCLE: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_NATURAL_REGENERATION: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_FIRE_DAMAGE: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_FORGIVE_DEAD_PLAYERS: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_SHOWDEATHMESSAGES: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_PLAYERS_SLEEPING_PERCENTAGE: Internal.GameRules$Key<Internal.GameRules$IntegerValue>;
        static readonly RULE_WATER_SOURCE_CONVERSION: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_FALL_DAMAGE: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_MOB_EXPLOSION_DROP_DECAY: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_DISABLE_RAIDS: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_BLOCK_EXPLOSION_DROP_DECAY: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_LOGADMINCOMMANDS: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_SPAWN_RADIUS: Internal.GameRules$Key<Internal.GameRules$IntegerValue>;
        static readonly RULE_SENDCOMMANDFEEDBACK: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_SNOW_ACCUMULATION_HEIGHT: Internal.GameRules$Key<Internal.GameRules$IntegerValue>;
        static readonly RULE_ANNOUNCE_ADVANCEMENTS: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_DOENTITYDROPS: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_LAVA_SOURCE_CONVERSION: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_DO_PATROL_SPAWNING: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_DO_VINES_SPREAD: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly DEFAULT_RANDOM_TICK_SPEED: 3;
        static readonly RULE_DOFIRETICK: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_LIMITED_CRAFTING: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_SPECTATORSGENERATECHUNKS: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_MAX_ENTITY_CRAMMING: Internal.GameRules$Key<Internal.GameRules$IntegerValue>;
        static readonly RULE_DROWNING_DAMAGE: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_UNIVERSAL_ANGER: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_GLOBAL_SOUND_EVENTS: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_KEEPINVENTORY: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_DOMOBLOOT: Internal.GameRules$Key<Internal.GameRules$BooleanValue>;
        static readonly RULE_RANDOMTICKING: Internal.GameRules$Key<Internal.GameRules$IntegerValue>;
    }
    type GameRules_ = GameRules;
    interface CraftingContainerKJS {
        getMenu(): Internal.AbstractContainerMenu;
        get menu(): Internal.AbstractContainerMenu
    }
    type CraftingContainerKJS_ = CraftingContainerKJS;
    class Instant implements Internal.Comparable<Internal.Instant>, Internal.Temporal, Internal.TemporalAdjuster, Internal.Serializable {
        minusSeconds(arg0: number): this;
        plus(arg0: number, arg1: Internal.TemporalUnit_): this;
        static parse(arg0: Internal.CharSequence_): Internal.Instant;
        isBefore(arg0: Internal.Instant_): boolean;
        compareTo(arg0: any): number;
        static ofEpochSecond(arg0: number, arg1: number): Internal.Instant;
        static ofEpochSecond(arg0: number): Internal.Instant;
        plusSeconds(arg0: number): this;
        getLong(arg0: Internal.TemporalField_): number;
        plus(arg0: Internal.TemporalAmount_): this;
        static now(): Internal.Instant;
        minus(arg0: number, arg1: Internal.TemporalUnit_): Internal.Temporal;
        isSupported(arg0: Internal.TemporalField_): boolean;
        static from(arg0: Internal.TemporalAccessor_): Internal.Instant;
        "with"(arg0: Internal.TemporalField_, arg1: number): this;
        minusNanos(arg0: number): this;
        truncatedTo(arg0: Internal.TemporalUnit_): this;
        static now(arg0: Internal.Clock_): Internal.Instant;
        adjustInto(arg0: Internal.Temporal_): Internal.Temporal;
        "with"(arg0: Internal.TemporalAdjuster_): this;
        query<R>(arg0: Internal.TemporalQuery_<R>): R;
        until(arg0: Internal.Temporal_, arg1: Internal.TemporalUnit_): number;
        atOffset(arg0: Internal.ZoneOffset_): Internal.OffsetDateTime;
        isSupported(arg0: Internal.TemporalUnit_): boolean;
        getNano(): number;
        range(arg0: Internal.TemporalField_): Internal.ValueRange;
        getEpochSecond(): number;
        plusMillis(arg0: number): this;
        toEpochMilli(): number;
        isAfter(arg0: Internal.Instant_): boolean;
        get(arg0: Internal.TemporalField_): number;
        atZone(arg0: Internal.ZoneId_): Internal.ZonedDateTime;
        compareTo(arg0: Internal.Instant_): number;
        plusNanos(arg0: number): this;
        static ofEpochMilli(arg0: number): Internal.Instant;
        minus(arg0: Internal.TemporalAmount_): Internal.Temporal;
        minusMillis(arg0: number): this;
        get nano(): number
        get epochSecond(): number
        static readonly EPOCH: Internal.Instant;
        static readonly MAX: Internal.Instant;
        static readonly MIN: Internal.Instant;
    }
    type Instant_ = Instant;
    interface ImmutableStringReader {
        abstract getTotalLength(): number;
        abstract peek(): string;
        abstract getCursor(): number;
        abstract getRead(): string;
        abstract canRead(): boolean;
        abstract getRemainingLength(): number;
        abstract getRemaining(): string;
        abstract canRead(arg0: number): boolean;
        abstract peek(arg0: number): string;
        abstract getString(): string;
        get totalLength(): number
        get cursor(): number
        get read(): string
        get remainingLength(): number
        get remaining(): string
        get string(): string
    }
    type ImmutableStringReader_ = ImmutableStringReader;
    class GridFlags extends Internal.Enum<Internal.GridFlags> {
        static valueOf(arg0: string): Internal.GridFlags;
        static values(): Internal.GridFlags[];
        static readonly REQUIRE_CHANNEL: Internal.GridFlags;
        static readonly COMPRESSED_CHANNEL: Internal.GridFlags;
        static readonly DENSE_CAPACITY: Internal.GridFlags;
        static readonly PREFERRED: Internal.GridFlags;
        static readonly MULTIBLOCK: Internal.GridFlags;
        static readonly CANNOT_CARRY: Internal.GridFlags;
        static readonly CANNOT_CARRY_COMPRESSED: Internal.GridFlags;
    }
    type GridFlags_ = "compressed_channel" | GridFlags | "preferred" | "multiblock" | "cannot_carry_compressed" | "cannot_carry" | "dense_capacity" | "require_channel";
    abstract class AbstractTexture implements Internal.AutoCloseable {
        constructor()
        setBlurMipmap(arg0: boolean, arg1: boolean): void;
        bind(): void;
        restoreLastBlurMipmap(): void;
        abstract load(arg0: Internal.ResourceManager_): void;
        close(): void;
        releaseId(): void;
        setFilter(arg0: boolean, arg1: boolean): void;
        reset(arg0: Internal.TextureManager_, arg1: Internal.ResourceManager_, arg2: ResourceLocation_, arg3: Internal.Executor_): void;
        getId(): number;
        get id(): number
        static readonly NOT_ASSIGNED: -1;
    }
    type AbstractTexture_ = AbstractTexture;
    class BlockFrame extends Internal.BaseEntityBlock {
        constructor(arg0: number)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        getTicker<T extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        static writeToNbt(arg0: Internal.CompoundTag_, arg1: string, arg2: Internal.BlockState_): void;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        static readFromNbt(arg0: Internal.CompoundTag_): Internal.BlockState;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static readonly FACING: Internal.DirectionProperty;
    }
    type BlockFrame_ = BlockFrame;
    class ModBlocks$12 extends Internal.PressurePlateBlock {
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type ModBlocks$12_ = ModBlocks$12;
    class ModBlocks$13 extends Internal.DoorBlock {
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type ModBlocks$13_ = ModBlocks$13;
    abstract class GrowingPlantHeadBlock extends Internal.GrowingPlantBlock implements Internal.BonemealableBlock {
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        isBonemealSuccess(arg0: Internal.Level_, arg1: Internal.RandomSource_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        performBonemeal(arg0: Internal.ServerLevel_, arg1: Internal.RandomSource_, arg2: BlockPos_, arg3: Internal.BlockState_): void;
        getMaxAgeState(arg0: Internal.BlockState_): Internal.BlockState;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        isValidBonemealTarget(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: boolean): boolean;
        isMaxAge(arg0: Internal.BlockState_): boolean;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static readonly AGE: Internal.IntegerProperty;
        static readonly MAX_AGE: 25;
    }
    type GrowingPlantHeadBlock_ = GrowingPlantHeadBlock;
    class ModifiableBiomeInfo$BiomeInfo$Builder {
        getClimateSettings(): Internal.ClimateSettingsBuilder;
        getMobSpawnSettings(): Internal.MobSpawnSettingsBuilder;
        static copyOf(arg0: Internal.ModifiableBiomeInfo$BiomeInfo_): Internal.ModifiableBiomeInfo$BiomeInfo$Builder;
        getGenerationSettings(): Internal.BiomeGenerationSettingsBuilder;
        getSpecialEffects(): Internal.BiomeSpecialEffectsBuilder;
        build(): Internal.ModifiableBiomeInfo$BiomeInfo;
        get climateSettings(): Internal.ClimateSettingsBuilder
        get mobSpawnSettings(): Internal.MobSpawnSettingsBuilder
        get generationSettings(): Internal.BiomeGenerationSettingsBuilder
        get specialEffects(): Internal.BiomeSpecialEffectsBuilder
    }
    type ModifiableBiomeInfo$BiomeInfo$Builder_ = ModifiableBiomeInfo$BiomeInfo$Builder;
    class ModBlocks$10 extends Internal.PressurePlateBlock {
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type ModBlocks$10_ = ModBlocks$10;
    class ModBlocks$11 extends Internal.ButtonBlock {
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type ModBlocks$11_ = ModBlocks$11;
    class IRecipeTransferError$Type extends Internal.Enum<Internal.IRecipeTransferError$Type> {
        static valueOf(arg0: string): Internal.IRecipeTransferError$Type;
        static values(): Internal.IRecipeTransferError$Type[];
        static readonly INTERNAL: Internal.IRecipeTransferError$Type;
        static readonly COSMETIC: Internal.IRecipeTransferError$Type;
        static readonly USER_FACING: Internal.IRecipeTransferError$Type;
        readonly allowsTransfer: boolean;
    }
    type IRecipeTransferError$Type_ = IRecipeTransferError$Type | "internal" | "user_facing" | "cosmetic";
    class RealmsNotification {
        dismissable(): boolean;
        static parseList(arg0: string): Internal.List<Internal.RealmsNotification>;
        seen(): boolean;
        uuid(): Internal.UUID;
    }
    type RealmsNotification_ = RealmsNotification;
    interface IDrawable {
        abstract draw(arg0: Internal.GuiGraphics_, arg1: number, arg2: number): void;
        abstract getWidth(): number;
        abstract getHeight(): number;
        draw(arg0: Internal.GuiGraphics_): void;
        get width(): number
        get height(): number
    }
    type IDrawable_ = IDrawable;
    interface BucketPickup extends Internal.IForgeBucketPickup {
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        abstract pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        /**
         * @deprecated
        */
        abstract getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        /**
         * @deprecated
        */
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
    }
    type BucketPickup_ = BucketPickup;
    class TileEntityUniversalCable extends Internal.TileEntityTransmitter implements Internal.IComputerTile {
        constructor(blockProvider: Internal.IBlockProvider_, pos: BlockPos_, state: Internal.BlockState_)
        getTransmitter(): Internal.Transmitter<any, any, any>;
        deserializeNBT(arg0: Internal.Tag_): void;
        requestModelDataUpdate(): void;
        getCapability<T>(arg0: Internal.Capability_<T>): Internal.LazyOptional<T>;
        tdv$isDynamicLightEnabled(): boolean;
        getComputerName(): string;
        hasComputerSupport(): boolean;
        getComputerMethods(holder: Internal.BoundMethodHolder_): void;
        deserializeNBT(arg0: Internal.CompoundTag_): void;
        onRightClick(player: Internal.Player_): Internal.InteractionResult;
        onSneakRightClick(player: Internal.Player_): Internal.InteractionResult;
        onLoad(): void;
        serializeNBT(): Internal.Tag;
        tdv$setDynamicLightEnabled(arg0: boolean): void;
        isComputerCapabilityPersistent(): boolean;
        hasCustomOutlineRendering(arg0: Internal.Player_): boolean;
        get transmitter(): Internal.Transmitter<any, any, any>
        get computerName(): string
        get computerCapabilityPersistent(): boolean
    }
    type TileEntityUniversalCable_ = TileEntityUniversalCable;
    class EnumGetMethod extends Internal.Enum<Internal.EnumGetMethod> {
        static values(): Internal.EnumGetMethod[];
        isCaseSensitive(): boolean;
        static valueOf(arg0: string): Internal.EnumGetMethod;
        isOrdinalOk(): boolean;
        validate<T extends Internal.Enum<T>>(arg0: any, arg1: T): boolean;
        get<T extends Internal.Enum<T>>(arg0: any, arg1: T): T;
        get caseSensitive(): boolean
        get ordinalOk(): boolean
        static readonly ORDINAL_OR_NAME: Internal.EnumGetMethod;
        static readonly NAME: Internal.EnumGetMethod;
        static readonly NAME_IGNORECASE: Internal.EnumGetMethod;
        static readonly ORDINAL_OR_NAME_IGNORECASE: Internal.EnumGetMethod;
    }
    type EnumGetMethod_ = "name" | "ordinal_or_name" | EnumGetMethod | "ordinal_or_name_ignorecase" | "name_ignorecase";
    class GirderEncasedShaftBlock extends Internal.HorizontalAxisKineticBlock implements Internal.ISpecialBlockItemRequirement, Internal.IBE<Internal.KineticBlockEntity>, com.simibubi.create.content.equipment.wrench.IWrenchable, Internal.SimpleWaterloggedBlock {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getBlockEntity(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.KineticBlockEntity;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        getRequiredItems(arg0: Internal.BlockState_, arg1: Internal.BlockEntity_): Internal.ItemRequirement;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        withBlockEntityDo(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Consumer_<Internal.KineticBlockEntity>): void;
        getBlockEntityClass(): typeof Internal.KineticBlockEntity;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        playRemoveSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        getMinimumRequiredSpeedLevel(): Internal.IRotate$SpeedLevel;
        getTicker<S extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<S>): Internal.BlockEntityTicker<S>;
        playRotateSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        getBlockEntityOptional(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.Optional<Internal.KineticBlockEntity>;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        newBlockEntity(arg0: BlockPos_, arg1: Internal.BlockState_): Internal.BlockEntity;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        static onRemove(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.BlockState_): void;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockEntityType(): Internal.BlockEntityType<Internal.KineticBlockEntity>;
        hideStressImpact(): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        onBlockEntityUse(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Function_<Internal.KineticBlockEntity, Internal.InteractionResult>): Internal.InteractionResult;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        onSneakWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        updateAfterWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.BlockState;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        showCapacityWithAnnotation(): boolean;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        get blockEntityClass(): typeof Internal.KineticBlockEntity
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get minimumRequiredSpeedLevel(): Internal.IRotate$SpeedLevel
        get blockEntityType(): Internal.BlockEntityType<Internal.KineticBlockEntity>
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static readonly TOP: Internal.BooleanProperty;
        static readonly BOTTOM: Internal.BooleanProperty;
    }
    type GirderEncasedShaftBlock_ = GirderEncasedShaftBlock;
    class ShaderCaps extends icyllis.arc3d.compiler.ShaderCaps {
        constructor()
        applyOptionsOverrides(options: Internal.ContextOptions_): void;
        mustEnableAdvBlendEqs(): boolean;
        mMaxFragmentSamplers: number;
        mShadingLanguage420Pack: boolean;
        mShadingLanguage420PackExtensionName: string;
        mVertexIDSupport: boolean;
        mColorSpaceMathNeedsFloat: boolean;
        mEnhancedLayouts: boolean;
        mPreferFlatInterpolation: boolean;
        mRequiresLocalOutputColorForFBFetch: boolean;
        mInfinitySupport: boolean;
        static readonly NotSupported_AdvBlendEqInteraction: 0;
        mTextureQueryLod: boolean;
        mTextureQueryLodExtension: string;
        mAvoidDfDxForGradientsWhenPossible: boolean;
        mDualSourceBlendingSupport: boolean;
        mAdvBlendEqInteraction: number;
        mSecondaryOutputExtension: string;
        mEnhancedLayoutsExtensionName: string;
        mBitManipulationSupport: boolean;
        static readonly Automatic_AdvBlendEqInteraction: 1;
        mMustObfuscateUniformColor: boolean;
        mMustWriteToFragColor: boolean;
        static readonly GeneralEnable_AdvBlendEqInteraction: 2;
        mReducedShaderMode: boolean;
        mNonConstantArrayIndexSupport: boolean;
    }
    type ShaderCaps_ = ShaderCaps;
    interface ISlurryTracker extends Internal.IContentsListener {
        abstract getSlurryTanks(side: Internal.Direction_): Internal.List<Internal.ISlurryTank>;
        abstract onContentsChanged(): void;
    }
    type ISlurryTracker_ = ISlurryTracker;
    class PlaySoundEvent extends net.minecraftforge.client.event.sound.SoundEvent {
        constructor()
        constructor(arg0: Internal.SoundEngine_, arg1: Internal.SoundInstance_)
        getSound(): Internal.SoundInstance;
        setSound(arg0: Internal.SoundInstance_): void;
        getName(): string;
        getOriginalSound(): Internal.SoundInstance;
        get sound(): Internal.SoundInstance
        set sound(arg0: Internal.SoundInstance_)
        get name(): string
        get originalSound(): Internal.SoundInstance
    }
    type PlaySoundEvent_ = PlaySoundEvent;
    interface IEventBus {
        abstract unregister(arg0: any): void;
        abstract addListener<T extends net.minecraftforge.eventbus.api.Event>(arg0: Internal.EventPriority_, arg1: boolean, arg2: Internal.Consumer_<T>): void;
        abstract post(arg0: net.minecraftforge.eventbus.api.Event_): boolean;
        abstract addGenericListener<T extends Internal.GenericEvent<any>, F>(arg0: F, arg1: Internal.EventPriority_, arg2: Internal.Consumer_<T>): void;
        abstract addGenericListener<T extends Internal.GenericEvent<any>, F>(arg0: F, arg1: Internal.Consumer_<T>): void;
        abstract post(arg0: net.minecraftforge.eventbus.api.Event_, arg1: Internal.IEventBusInvokeDispatcher_): boolean;
        abstract register(arg0: any): void;
        abstract addGenericListener<T extends Internal.GenericEvent<any>, F>(arg0: F, arg1: Internal.EventPriority_, arg2: boolean, arg3: Internal.Consumer_<T>): void;
        abstract addGenericListener<T extends Internal.GenericEvent<any>, F>(arg0: F, arg1: Internal.EventPriority_, arg2: boolean, arg3: T, arg4: Internal.Consumer_<T>): void;
        abstract shutdown(): void;
        abstract start(): void;
        abstract addListener<T extends net.minecraftforge.eventbus.api.Event>(arg0: Internal.EventPriority_, arg1: Internal.Consumer_<T>): void;
        abstract addListener<T extends net.minecraftforge.eventbus.api.Event>(arg0: Internal.EventPriority_, arg1: boolean, arg2: T, arg3: Internal.Consumer_<T>): void;
        abstract addListener<T extends net.minecraftforge.eventbus.api.Event>(arg0: Internal.Consumer_<T>): void;
    }
    type IEventBus_ = IEventBus;
    class FrameBlock extends Internal.MimicBlock implements Internal.EntityBlock, Internal.IFrameBlock {
        constructor(properties: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        getTicker<T extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        registerFilledBlock(inserted: Internal.Block_, filled: Internal.Block_): void;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        getFilledBlock(inserted: Internal.Block_): Internal.Block;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        newBlockEntity(pPos: BlockPos_, pState: Internal.BlockState_): Internal.BlockEntity;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static readonly OCCLUSION_SHAPE: Internal.ArrayVoxelShape;
        static readonly FRAMED_BLOCKS: [Internal.FrameBlock, Internal.FrameBraceBlock, Internal.FrameBlock];
        static readonly HAS_BLOCK: Internal.BooleanProperty;
        static readonly WATERLOGGED: Internal.BooleanProperty;
        static readonly LIGHT_LEVEL: Internal.IntegerProperty;
    }
    type FrameBlock_ = FrameBlock;
    class Proxy$Type extends Internal.Enum<Internal.Proxy$Type> {
        static valueOf(arg0: string): Internal.Proxy$Type;
        static values(): Internal.Proxy$Type[];
        static readonly SOCKS: Internal.Proxy$Type;
        static readonly HTTP: Internal.Proxy$Type;
        static readonly DIRECT: Internal.Proxy$Type;
    }
    type Proxy$Type_ = Proxy$Type | "http" | "socks" | "direct";
    class EntityAttributeCreationEvent extends net.minecraftforge.eventbus.api.Event implements Internal.IModBusEvent {
        constructor()
        constructor(arg0: Internal.Map_<Internal.EntityType<Internal.LivingEntity>, Internal.AttributeSupplier>)
        put(arg0: Internal.EntityType_<Internal.LivingEntity>, arg1: Internal.AttributeSupplier_): void;
    }
    type EntityAttributeCreationEvent_ = EntityAttributeCreationEvent;
    class HatStandItem extends Internal.Item {
        constructor(properties: Internal.Item$Properties_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type HatStandItem_ = HatStandItem;
    class BaseFunction extends Internal.IdScriptableObject implements dev.latvian.mods.rhino.Function {
        constructor()
        constructor(scope: Internal.Scriptable_, prototype: Internal.Scriptable_)
        constructor(isGenerator: boolean)
        enumerationIteratorNext(cx: Internal.Context_, currentId: Internal.Consumer_<any>): boolean;
        getArity(): number;
        getFunctionName(): string;
        call(cx: Internal.Context_, scope: Internal.Scriptable_, thisObj: Internal.Scriptable_, args: any[]): any;
        setImmunePrototypeProperty(value: any): void;
        createObject(cx: Internal.Context_, scope: Internal.Scriptable_): Internal.Scriptable;
        getAllIds(cx: Internal.Context_): any[];
        enumerationIteratorHasNext(cx: Internal.Context_, currentId: Internal.Consumer_<any>): boolean;
        construct(cx: Internal.Context_, scope: Internal.Scriptable_, args: any[]): Internal.Scriptable;
        getLength(): number;
        get arity(): number
        get functionName(): string
        set immunePrototypeProperty(value: any)
        get length(): number
    }
    type BaseFunction_ = BaseFunction;
    class HierarchyEvent extends Internal.AWTEvent {
        constructor(arg0: Internal.Component_, arg1: number, arg2: Internal.Component_, arg3: Internal.Container_, arg4: number)
        constructor(arg0: Internal.Component_, arg1: number, arg2: Internal.Component_, arg3: Internal.Container_)
        getChangedParent(): Internal.Container;
        getComponent(): Internal.Component;
        getChanged(): Internal.Component;
        getChangeFlags(): number;
        get changedParent(): Internal.Container
        get component(): Internal.Component
        get changed(): Internal.Component
        get changeFlags(): number
        static readonly ANCESTOR_RESIZED: 1402;
        static readonly PARENT_CHANGED: 1;
        static readonly ANCESTOR_MOVED: 1401;
        static readonly HIERARCHY_LAST: 1402;
        static readonly HIERARCHY_FIRST: 1400;
        static readonly HIERARCHY_CHANGED: 1400;
        static readonly DISPLAYABILITY_CHANGED: 2;
        static readonly SHOWING_CHANGED: 4;
    }
    type HierarchyEvent_ = HierarchyEvent;
    class ArmBlockEntity extends Internal.KineticBlockEntity implements Internal.ITransformableBlockEntity {
        constructor(arg0: Internal.BlockEntityType_<any>, arg1: BlockPos_, arg2: Internal.BlockState_)
        writeInteractionPoints(arg0: Internal.CompoundTag_): void;
        deserializeNBT(arg0: Internal.Tag_): void;
        containedFluidTooltip(arg0: Internal.List_<net.minecraft.network.chat.Component>, arg1: boolean, arg2: Internal.LazyOptional_<Internal.IFluidHandler>): boolean;
        write(arg0: Internal.CompoundTag_, arg1: boolean): void;
        static getRange(): number;
        getCapability<T>(arg0: Internal.Capability_<T>): Internal.LazyOptional<T>;
        redstoneUpdate(): void;
        tdv$isDynamicLightEnabled(): boolean;
        deserializeNBT(arg0: Internal.CompoundTag_): void;
        transform(arg0: Internal.StructureTransform_): void;
        getModelData(): Internal.ModelData;
        onLoad(): void;
        serializeNBT(): Internal.Tag;
        tdv$setDynamicLightEnabled(arg0: boolean): void;
        hasCustomOutlineRendering(arg0: Internal.Player_): boolean;
        get range(): number
        get modelData(): Internal.ModelData
    }
    type ArmBlockEntity_ = ArmBlockEntity;
    interface IModeItem {
        abstract changeMode(player: Internal.Player_, stack: Internal.ItemStack_, shift: number, displayChange: Internal.IModeItem$DisplayChange_): void;
        displayModeChange(player: Internal.Player_): void;
        supportsSlotType(stack: Internal.ItemStack_, slotType: Internal.EquipmentSlot_): boolean;
        isModeItem(stack: Internal.ItemStack_, slotType: Internal.EquipmentSlot_, allowRadial: boolean): boolean;
        getScrollTextComponent(stack: Internal.ItemStack_): net.minecraft.network.chat.Component;
        isModeItem(player: Internal.Player_, slotType: Internal.EquipmentSlot_): boolean;
        isModeItem(player: Internal.Player_, slotType: Internal.EquipmentSlot_, allowRadial: boolean): boolean;
        isModeItem(stack: Internal.ItemStack_, slotType: Internal.EquipmentSlot_): boolean;
        (player: Internal.Player, stack: Internal.ItemStack, shift: number, displayChange: Internal.IModeItem$DisplayChange): void;
    }
    type IModeItem_ = IModeItem;
    class EightDirectionProperty extends Internal.EnumProperty<any> {
        constructor()
        static readonly FACING: Internal.EightDirectionProperty;
    }
    type EightDirectionProperty_ = EightDirectionProperty;
    interface Appendable {
        abstract append(arg0: Internal.CharSequence_): this;
        abstract append(arg0: Internal.CharSequence_, arg1: number, arg2: number): this;
        abstract append(arg0: string): this;
    }
    type Appendable_ = Appendable;
    class SconceBlock extends Internal.LightUpWaterBlock {
        constructor(properties: Internal.BlockBehaviour$Properties_, lightLevel: number, particleData: Internal.Supplier_<T>)
        constructor(properties: Internal.BlockBehaviour$Properties_, particleData: Internal.Supplier_<T>)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        playExtinguishSound(world: Internal.LevelAccessor_, pos: BlockPos_): void;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        extinguish(player: Internal.Entity_, state: Internal.BlockState_, pos: BlockPos_, world: Internal.LevelAccessor_): boolean;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        interactWithPlayer(state: Internal.BlockState_, level: Internal.Level_, pos: BlockPos_, player: Internal.Player_, handIn: Internal.InteractionHand_): Internal.InteractionResult;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        isLitUp(state: Internal.BlockState_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        playLightUpSound(world: Internal.LevelAccessor_, pos: BlockPos_, type: Internal.ILightable$FireSourceType_): void;
        spawnSmokeParticles(state: Internal.BlockState_, pos: BlockPos_, world: Internal.LevelAccessor_): void;
        interactWithProjectile(level: Internal.Level_, state: Internal.BlockState_, projectile: Internal.Projectile_, pos: BlockPos_): boolean;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        toggleLitState(state: Internal.BlockState_, lit: boolean): Internal.BlockState;
        canBeExtinguishedBy(item: Internal.ItemStack_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type SconceBlock_ = SconceBlock;
    class WrappedDeferredRegister <T> {
        createAndRegister(bus: Internal.IEventBus_, builder: Internal.UnaryOperator_<Internal.RegistryBuilder<T>>): Internal.Supplier<Internal.IForgeRegistry<T>>;
        createAndRegisterChemical(bus: Internal.IEventBus_): Internal.Supplier<Internal.IForgeRegistry<T>>;
        createAndRegister(bus: Internal.IEventBus_): Internal.Supplier<Internal.IForgeRegistry<T>>;
        register(bus: Internal.IEventBus_): void;
    }
    type WrappedDeferredRegister_<T> = WrappedDeferredRegister<T>;
    class PonderScene {
        constructor(arg0: Internal.PonderWorld_, arg1: string, arg2: ResourceLocation_, arg3: Internal.Collection_<Internal.PonderTag>)
        applyTo<E extends Internal.PonderElement, F>(arg0: Internal.ElementLink_<E>, arg1: Internal.Function_<E, F>): F;
        getTitle(): string;
        begin(): void;
        forEach<T extends Internal.PonderElement>(arg0: T, arg1: Internal.Consumer_<T>): void;
        getTags(): Internal.List<Internal.PonderTag>;
        getScaleFactor(): number;
        renderOverlay(arg0: Internal.PonderUI_, arg1: Internal.GuiGraphics_, arg2: number): void;
        shouldHidePlatformShadow(): boolean;
        forEachVisible<T extends Internal.PonderElement>(arg0: T, arg1: Internal.Consumer_<T>): void;
        markKeyframe(arg0: number): void;
        resolve<E extends Internal.PonderElement>(arg0: Internal.ElementLink_<E>): E;
        getKeyframeCount(): number;
        getId(): ResourceLocation;
        getCurrentTime(): number;
        getSceneProgress(): number;
        getPointOfInterest(): Vec3d;
        getBaseWorldSection(): Internal.WorldSectionElement;
        runWith<E extends Internal.PonderElement>(arg0: Internal.ElementLink_<E>, arg1: Internal.Consumer_<E>): void;
        getOutliner(): Internal.Outliner;
        rayTraceScene(arg0: Vec3d_, arg1: Vec3d_): com.simibubi.create.foundation.utility.Pair<Internal.ItemStack, BlockPos>;
        tick(): void;
        getSceneBuildingUtil(): Internal.SceneBuildingUtil;
        getComponent(): ResourceLocation;
        builder(): Internal.SceneBuilder;
        registerText(arg0: string): Internal.Supplier<string>;
        getString(arg0: string): string;
        renderScene(arg0: Internal.SuperRenderTypeBuffer_, arg1: Internal.PoseStack_, arg2: number): void;
        getKeyframeTime(arg0: number): number;
        deselect(): void;
        forEach(arg0: Internal.Consumer_<Internal.PonderElement>): void;
        fadeOut(): void;
        getBounds(): Internal.BoundingBox;
        seekToTime(arg0: number): void;
        setPointOfInterest(arg0: Vec3d_): void;
        getTransform(): Internal.PonderScene$SceneTransform;
        getYOffset(): number;
        reset(): void;
        forEachWorldEntity<T extends Internal.Entity>(arg0: T, arg1: Internal.Consumer_<T>): void;
        linkElement<E extends Internal.PonderElement>(arg0: E, arg1: Internal.ElementLink_<E>): void;
        getTotalTime(): number;
        getNamespace(): string;
        getElements(): Internal.Set<Internal.PonderElement>;
        getBasePlateOffsetX(): number;
        addToSceneTime(arg0: number): void;
        getBasePlateOffsetZ(): number;
        isFinished(): boolean;
        stopCounting(): void;
        getWorld(): Internal.PonderWorld;
        setFinished(arg0: boolean): void;
        getBasePlateSize(): number;
        addElement(arg0: Internal.PonderElement_): void;
        get title(): string
        get tags(): Internal.List<Internal.PonderTag>
        get scaleFactor(): number
        get keyframeCount(): number
        get id(): ResourceLocation
        get currentTime(): number
        get sceneProgress(): number
        get pointOfInterest(): Vec3d
        get baseWorldSection(): Internal.WorldSectionElement
        get outliner(): Internal.Outliner
        get sceneBuildingUtil(): Internal.SceneBuildingUtil
        get component(): ResourceLocation
        get bounds(): Internal.BoundingBox
        set pointOfInterest(arg0: Vec3d_)
        get transform(): Internal.PonderScene$SceneTransform
        get YOffset(): number
        get totalTime(): number
        get namespace(): string
        get elements(): Internal.Set<Internal.PonderElement>
        get basePlateOffsetX(): number
        get basePlateOffsetZ(): number
        get finished(): boolean
        get world(): Internal.PonderWorld
        set finished(arg0: boolean)
        get basePlateSize(): number
        static readonly TITLE_KEY: "header";
    }
    type PonderScene_ = PonderScene;
    class MekanismContainerType <T, CONTAINER extends Internal.AbstractContainerMenu> extends Internal.BaseMekanismContainerType<T, CONTAINER, Internal.MekanismContainerType$IMekanismContainerFactory<T, CONTAINER>> {
        create(arg0: number, arg1: Internal.Inventory_, arg2: Internal.FriendlyByteBuf_): any;
        static tile<TILE extends Internal.TileEntityMekanism, CONTAINER extends Internal.AbstractContainerMenu>(type: TILE, constructor_: Internal.MekanismContainerType$IMekanismContainerFactory_<TILE, CONTAINER>): Internal.MekanismContainerType<TILE, CONTAINER>;
        static entity<ENTITY extends Internal.Entity, CONTAINER extends Internal.AbstractContainerMenu & Internal.IEntityContainer<ENTITY>>(type: ENTITY, constructor_: Internal.MekanismContainerType$IMekanismSidedContainerFactory_<ENTITY, CONTAINER>): Internal.MekanismContainerType<ENTITY, CONTAINER>;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        create(data: any): Internal.MenuConstructor;
        static entity<ENTITY extends Internal.Entity, CONTAINER extends Internal.AbstractContainerMenu & Internal.IEntityContainer<ENTITY>>(type: ENTITY, constructor_: Internal.MekanismContainerType$IMekanismContainerFactory_<ENTITY, CONTAINER>): Internal.MekanismContainerType<ENTITY, CONTAINER>;
        create(id: number, inv: Internal.Inventory_, data: any): CONTAINER;
        static tile<TILE extends Internal.TileEntityMekanism, CONTAINER extends Internal.AbstractContainerMenu>(type: TILE, constructor_: Internal.MekanismContainerType$IMekanismSidedContainerFactory_<TILE, CONTAINER>): Internal.MekanismContainerType<TILE, CONTAINER>;
        static create<T extends Internal.AbstractContainerMenu>(arg0: Internal.IContainerFactory_<T>): Internal.MenuType<T>;
    }
    type MekanismContainerType_<T, CONTAINER extends Internal.AbstractContainerMenu> = MekanismContainerType<T, CONTAINER>;
    class ModBlockProperties$RakeDirection extends Internal.Enum<Internal.ModBlockProperties$RakeDirection> implements Internal.StringRepresentable {
        static keys(arg0: Internal.StringRepresentable_[]): Internal.Keyable;
        static fromEnumWithMapping<E extends Internal.Enum<E> & Internal.StringRepresentable>(arg0: Internal.Supplier_<E[]>, arg1: Internal.Function_<string, string>): Internal.StringRepresentable$EnumCodec<E>;
        static fromEnum<E extends Internal.Enum<E> & Internal.StringRepresentable>(arg0: Internal.Supplier_<E[]>): Internal.StringRepresentable$EnumCodec<E>;
        static valueOf(name: string): Internal.ModBlockProperties$RakeDirection;
        getSerializedName(): string;
        static fromDirections(directions: Internal.List_<Internal.Direction>): Internal.ModBlockProperties$RakeDirection;
        static values(): Internal.ModBlockProperties$RakeDirection[];
        getDirections(): Internal.List<Internal.Direction>;
        get serializedName(): string
        get directions(): Internal.List<Internal.Direction>
        static readonly NORTH_SOUTH: Internal.ModBlockProperties$RakeDirection;
        static readonly NORTH_WEST: Internal.ModBlockProperties$RakeDirection;
        static readonly NORTH_EAST: Internal.ModBlockProperties$RakeDirection;
        static readonly SOUTH_EAST: Internal.ModBlockProperties$RakeDirection;
        static readonly SOUTH_WEST: Internal.ModBlockProperties$RakeDirection;
        static readonly EAST_WEST: Internal.ModBlockProperties$RakeDirection;
    }
    type ModBlockProperties$RakeDirection_ = ModBlockProperties$RakeDirection | "north_west" | "north_east" | "south_west" | "north_south" | "east_west" | "south_east";
    class PlayerEvent$ItemCraftedEvent extends Internal.PlayerEvent {
        constructor()
        constructor(arg0: Internal.Player_, arg1: Internal.ItemStack_, arg2: net.minecraft.world.Container_)
        getInventory(): net.minecraft.world.Container;
        getCrafting(): Internal.ItemStack;
        getEntity(): Internal.Entity;
        get inventory(): net.minecraft.world.Container
        get crafting(): Internal.ItemStack
        get entity(): Internal.Entity
    }
    type PlayerEvent$ItemCraftedEvent_ = PlayerEvent$ItemCraftedEvent;
    class FluidHydrogenFluoride extends Internal.FluidNonPlaceable {
        constructor()
        getAdjacentBlockPathType(arg0: Internal.FluidState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canHydrate(arg0: Internal.FluidState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: BlockPos_): boolean;
        getExplosionResistance(arg0: Internal.FluidState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        canConvertToSource(arg0: Internal.FluidState_, arg1: Internal.Level_, arg2: BlockPos_): boolean;
        arch$holder(): Internal.Holder<Internal.Fluid>;
        getBlockPathType(arg0: Internal.FluidState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: boolean): Internal.BlockPathTypes;
        supportsBoating(arg0: Internal.FluidState_, arg1: Internal.Boat_): boolean;
        arch$registryName(): ResourceLocation;
        move(arg0: Internal.FluidState_, arg1: Internal.LivingEntity_, arg2: Vec3d_, arg3: number): boolean;
        canExtinguish(arg0: Internal.FluidState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        shouldUpdateWhileBoating(arg0: Internal.FluidState_, arg1: Internal.Boat_, arg2: Internal.Entity_): boolean;
        static readonly FORGE_TAG: "hydrofluoric_acid";
    }
    type FluidHydrogenFluoride_ = FluidHydrogenFluoride;
    class StreamTagVisitor$EntryResult extends Internal.Enum<Internal.StreamTagVisitor$EntryResult> {
        static valueOf(arg0: string): Internal.StreamTagVisitor$EntryResult;
        static values(): Internal.StreamTagVisitor$EntryResult[];
        static readonly BREAK: Internal.StreamTagVisitor$EntryResult;
        static readonly SKIP: Internal.StreamTagVisitor$EntryResult;
        static readonly ENTER: Internal.StreamTagVisitor$EntryResult;
        static readonly HALT: Internal.StreamTagVisitor$EntryResult;
    }
    type StreamTagVisitor$EntryResult_ = StreamTagVisitor$EntryResult | "break" | "halt" | "skip" | "enter";
    class DispenserBlock extends Internal.BaseEntityBlock implements com.simibubi.create.foundation.mixin.accessor.DispenserBlockAccessor, Internal.DispenserBlockAccessor {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        static registerBehavior(arg0: Internal.ItemLike_, arg1: Internal.DispenseItemBehavior_): void;
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        static getDispenserRegistry_$md$f6d287$0(): Internal.Map<any, any>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        getDispenseMethod(arg0: Internal.ItemStack_): Internal.DispenseItemBehavior;
        getTicker<T extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        handler$zmd000$onCuttingBoardDispenseFromInject(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: Internal.CallbackInfo_, arg3: Internal.BlockSourceImpl_, arg4: Internal.DispenserBlockEntity_, arg5: number, arg6: Internal.ItemStack_): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        create$callGetDispenseMethod(arg0: Internal.ItemStack_): Internal.DispenseItemBehavior;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        static getDispensePosition(arg0: Internal.BlockSource_): Internal.Position;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        static getDispenserRegistry(): Internal.Map<Internal.Item, Internal.DispenseItemBehavior>;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get dispenserRegistry_$md$f6d287$0(): Internal.Map<any, any>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        get dispenserRegistry(): Internal.Map<Internal.Item, Internal.DispenseItemBehavior>
        static DISPENSER_REGISTRY: {[key: Internal.ItemMekanismArmor]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.ExperienceBottleItem]: any, [key: Internal.BombItem]: any, [key: Internal.SplashPotionItem]: any, [key: Internal.BlockItem]: any, [key: Internal.BlockItem]: any, [key: Internal.BlockItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.ItemCompositeArmor]: any, [key: Internal.SpectralArrowItem]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.SpaceSuitItem]: any, [key: Internal.ShearsItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.ItemMekanismPaxel]: any, [key: Internal.ItemCombatArmor]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.CustomDyeableArmorItem]: any, [key: Internal.BucketItem]: any, [key: Internal.MinecartItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ArmorItem]: any, [key: Internal.Item]: any, [key: Internal.BlockItem]: any, [key: Internal.FlintAndSteelItem]: any, [key: Internal.DyeableExtendedArmorItem]: any, [key: Internal.BlockItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.AxeItem]: any, [key: Internal.Item]: any, [key: Internal.BottleItem]: any, [key: Internal.ItemMekanismShield]: any, [key: Internal.ItemHazmatSuitArmor]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BucketItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.JetSuitItem]: any, [key: Internal.MinecartItem]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.ItemMekaTool]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.ConsumableItem]: any, [key: Internal.BombItem]: any, [key: Internal.BucketItem]: any, [key: Internal.ItemMekanismShield]: any, [key: Internal.HoneycombItem]: any, [key: Internal.BucketItem]: any, [key: Internal.BlockItem]: any, [key: Internal.BoneMealItem]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BucketItem]: any, [key: Internal.ArmorItem]: any, [key: Internal.ItemBalloon]: any, [key: Internal.ArmorItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.MobBucketItem]: any, [key: Internal.HorseArmorItem]: any, [key: Internal.BoatItem]: any, [key: Internal.DivingHelmetItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BoatItem]: any, [key: Internal.ItemMekanismPaxel]: any, [key: electrodynamics.common.item.gear.armor.types.ItemJetpack]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.NetheriteSpaceSuitItem]: any, [key: Internal.BowlFoodItem]: any, [key: Internal.MinecartContraptionItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BlockItem]: any, [key: Internal.BacktankItem$Layered]: any, [key: Internal.MilkBucketItem]: any, [key: Internal.CustomDyeableArmorItem]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ConsumableItem]: any, [key: Internal.BoatItem]: any, [key: Internal.ItemFreeRunners]: any, [key: Internal.ArmorItem]: any, [key: Internal.Item]: any, [key: Internal.ItemMekanismAxe]: any, [key: Internal.HotCocoaItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.CustomDyeableArmorItem]: any, [key: Internal.DivingHelmetItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.ArmorItem]: any, [key: Internal.TippedArrowItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BoatItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.MilkBottleItem]: any, [key: Internal.MelonJuiceItem]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.ItemBalloon]: any, [key: Internal.BlockItem]: any, [key: Internal.AxeItem]: any, [key: Internal.ItemHDPEElytra]: any, [key: Internal.ConsumableItem]: any, [key: Internal.ArmorItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.AxeItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.JarItem]: any, [key: Internal.ItemBalloon]: any, [key: Internal.ItemBalloon]: any, [key: Internal.ArmorItem]: any, [key: Internal.StandingAndWallBlockItem]: any, [key: Internal.ItemHazmatSuitArmor]: any, [key: Internal.ItemHazmatSuitArmor]: any, [key: Internal.QuartzAxeItem]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.SnowballItem]: any, [key: Internal.MobBucketItem]: any, [key: Internal.Item]: any, [key: Internal.ArmorItem]: any, [key: Internal.ArmorItem]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BoatItem]: any, [key: Internal.ItemMekanismPaxel]: any, [key: Internal.BoatItem]: any, [key: Internal.FireworkRocketItem]: any, [key: Internal.DrinkableItem]: any, [key: Internal.BlockItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.BucketItem]: any, [key: Internal.ItemCombatArmor]: any, [key: Internal.BlockItem]: any, [key: Internal.ItemMekanismPaxel]: any, [key: Internal.ItemBalloon]: any, [key: Internal.SoapItem]: any, [key: Internal.BlockItem]: any, [key: Internal.WoodBasedBlockItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BucketItem]: any, [key: Internal.DyeableHorseArmorItem]: any, [key: Internal.HorseArmorItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BombItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.EggItem]: any, [key: Internal.ConsumableItem]: any, [key: Internal.ItemMekanismAxe]: any, [key: Internal.BombItem]: any, [key: Internal.ItemBalloon]: any, [key: Internal.BombItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.FluixAxeItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.HorseArmorItem]: any, [key: Internal.ItemBalloon]: any, [key: Internal.ItemHazmatSuitArmor]: any, [key: Internal.BlockItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BucketItem]: any, [key: Internal.BlockItem]: any, [key: Internal.BucketItem]: any, [key: Internal.BlockItem]: any, [key: Internal.BlockItem]: any, [key: Internal.ItemRefinedGlowstoneArmor]: any, [key: Internal.ItemBalloon]: any, [key: Internal.ItemBalloon]: any, [key: Internal.BlockItem]: any, [key: Internal.BubbleBlockItem]: any, [key: Internal.Item]: any, [key: Internal.ItemScubaMask]: any, [key: Internal.BacktankItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.DivingBootsItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ConsumableItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ItemMekanismShield]: any, [key: Internal.DyeableExtendedArmorItem]: any, [key: Internal.StandingAndWallBlockItem]: any, [key: Internal.StandingAndWallBlockItem]: any, [key: Internal.Item]: any, [key: Internal.BucketItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ArmorItem]: any, [key: Internal.BoatItem]: any, [key: Internal.ItemMekanismPaxel]: any, [key: Internal.KeyItem]: any, [key: Internal.AxeItem]: any, [key: Internal.ItemMekanismPaxel]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.DyeableArmorItem]: any, [key: Internal.SolidBucketItem]: any, [key: Internal.ItemMekaSuitArmor]: any, [key: Internal.ConsumableItem]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.ItemBalloon]: any, [key: Internal.ArmorItem]: any, [key: Internal.ItemMekanismAxe]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BucketItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.CoconutSliceItem]: any, [key: Internal.RottenTomatoItem]: any, [key: Internal.BucketItem]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.AxeItem]: any, [key: Internal.ItemRefinedGlowstoneArmor]: any, [key: Internal.ItemMekanismShield]: any, [key: Internal.ArmorItem]: any, [key: Internal.ItemMekanismAxe]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.MobBucketItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.ItemArmoredFreeRunners]: any, [key: Internal.BlockItem]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.ItemMekaSuitArmor]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BucketItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.CustomDyeableArmorItem]: any, [key: Internal.ArmorItem]: any, [key: Internal.ItemCombatArmor]: any, [key: Internal.ArmorItem]: any, [key: Internal.ShieldItem]: any, [key: Internal.CustomDyeableArmorItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ItemMekanismShield]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.DyeableExtendedArmorItem]: any, [key: Internal.ItemMekanismPaxel]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.RopeArrowItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.ElytraItem]: any, [key: Internal.ItemRefinedGlowstoneArmor]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.MinecartItem]: any, [key: Internal.ArmorItem]: any, [key: Internal.BlockItem]: any, [key: Internal.ItemMekanismAxe]: any, [key: Internal.ItemMekaSuitArmor]: any, [key: Internal.ItemBalloon]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BlockItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.SaddleItem]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.ItemMekanismShield]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ItemArmoredJetpack]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.BlockItem]: any, [key: Internal.ItemHydraulicBoots]: any, [key: Internal.ItemNightVisionGoggles]: any, [key: Internal.ItemCompositeArmor]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ItemMekanismAxe]: any, [key: Internal.ItemBalloon]: any, [key: Internal.BlockItem]: any, [key: Internal.BambooSpikesTippedItem]: any, [key: Internal.BlockItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.ArmorItem]: any, [key: Internal.BucketItem]: any, [key: Internal.BucketItem]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.ArmorItem]: any, [key: Internal.ItemMekanismPaxel]: any, [key: Internal.BlockItem]: any, [key: Internal.ItemBalloon]: any, [key: Internal.MinecartItem]: any, [key: Internal.BlockItem]: any, [key: Internal.Item]: any, [key: Internal.DyeableExtendedArmorItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.AxeItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BlockItem]: any, [key: Internal.BlockItem]: any, [key: Internal.ItemCompositeArmor]: any, [key: Internal.MinecartContraptionItem]: any, [key: Internal.BlockItem]: any, [key: Internal.StandingAndWallBlockItem]: any, [key: Internal.BucketItem]: any, [key: Internal.ItemRubberArmor]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.DyeableArmorItem]: any, [key: Internal.ItemJetpack]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BlockItem]: any, [key: Internal.BucketItem]: any, [key: Internal.CustomDyeableArmorItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.CustomDyeableArmorItem]: any, [key: Internal.ItemMekanismPaxel]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BlockItem]: any, [key: Internal.Item]: any, [key: Internal.ColorApplicatorItem]: any, [key: Internal.ItemServoLeggings]: any, [key: Internal.BoatItem]: any, [key: Internal.QuartzAxeItem]: any, [key: Internal.BlockItem]: any, [key: Internal.ItemBalloon]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BombItem]: any, [key: Internal.BlockItem]: any, [key: Internal.CustomDyeableArmorItem]: any, [key: Internal.ItemMekaSuitArmor]: any, [key: Internal.BoatItem]: any, [key: Internal.DyeableExtendedArmorItem]: any, [key: Internal.MatterCannonItem]: any, [key: Internal.DyeableExtendedArmorItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.Item]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.BucketItem]: any, [key: Internal.BowlFoodItem]: any, [key: Internal.BucketItem]: any, [key: Internal.ItemBalloon]: any, [key: Internal.BoatItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.FireChargeItem]: any, [key: Internal.BoatItem]: any, [key: Internal.BoatItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ArmorItem]: any, [key: Internal.EntropyManipulatorItem]: any, [key: Internal.BoatItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.BoatItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.PotionItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.BlockItem]: any, [key: Internal.DivingBootsItem]: any, [key: Internal.BlockItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.StandingAndWallBlockItem]: any, [key: Internal.DyeableExtendedArmorItem]: any, [key: Internal.BoatItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.ItemMekanismPaxel]: any, [key: Internal.BuildersTeaItem]: any, [key: Internal.SackItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BlockItem]: any, [key: Internal.BoatItem]: any, [key: Internal.BlockItem]: any, [key: Internal.ItemRefinedGlowstoneArmor]: any, [key: Internal.DyeableExtendedArmorItem]: any, [key: Internal.ItemMekanismPaxel]: any, [key: Internal.HoneyBottleItem]: any, [key: Internal.DyeableArmorItem]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ArmorStandItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.MinecartItem]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ItemMekanismPaxel]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.ItemBalloon]: any, [key: Internal.EnderpearlItem]: any, [key: Internal.ArmorItem]: any, [key: Internal.BucketItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.MinecartItem]: any, [key: Internal.BucketItem]: any, [key: Internal.BoatItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.MobBucketItem]: any, [key: Internal.ItemBalloon]: any, [key: Internal.DyeBottleItem]: any, [key: Internal.SuspiciousStewItem]: any, [key: Internal.MobBucketItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.BoatItem]: any, [key: Internal.ItemNutritionalPasteBucket]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BlockItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BlockItem]: any, [key: Internal.AEBaseBlockItem]: any, [key: Internal.ArmorItem]: any, [key: Internal.BucketItem]: any, [key: Internal.BlockItem]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.BucketItem]: any, [key: Internal.EndermanHeadItem]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.BowlFoodItem]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.ArrowItem]: any, [key: Internal.BlockItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ArmorItem]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.GogglesItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.Item]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.ItemMekanismArmor]: any, [key: Internal.BucketItem]: any, [key: Internal.LingeringPotionItem]: any, [key: Internal.BlockItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.PlayerHeadItem]: any, [key: Internal.Item]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.StandingAndWallBlockItem]: any, [key: Internal.ConsumableItem]: any, [key: Internal.ShulkerShellItem]: any, [key: Internal.CustomDyeableArmorItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ItemCompositeArmor]: any, [key: Internal.ExtendedArmorItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.MobBucketItem]: any, [key: Internal.SpawnEggItem]: any, [key: Internal.ForgeSpawnEggItem]: any, [key: Internal.DispenserMinecartItem]: any, [key: Internal.ItemScubaTank]: any, [key: Internal.ItemCombatArmor]: any, [key: Internal.MinecartContraptionItem]: any, [key: Internal.DyeableArmorItem]: any, [key: Internal.ItemBalloon]: any, [key: Internal.BlockItem]: any};
        static readonly TRIGGERED: Internal.BooleanProperty;
        static readonly FACING: Internal.DirectionProperty;
    }
    type DispenserBlock_ = DispenserBlock;
    class FogShape extends Internal.Enum<Internal.FogShape> {
        static valueOf(arg0: string): Internal.FogShape;
        static values(): Internal.FogShape[];
        getIndex(): number;
        get index(): number
        static readonly CYLINDER: Internal.FogShape;
        static readonly SPHERE: Internal.FogShape;
    }
    type FogShape_ = FogShape | "cylinder" | "sphere";
    class TileComponentFrequency implements Internal.ITileComponent {
        constructor(tile: Internal.TileEntityMekanism_)
        removeFrequencyFromData(type: Internal.FrequencyType_<any>, data: Internal.Frequency$FrequencyIdentity_, player: Internal.UUID_): void;
        readFromUpdateTag(updateTag: Internal.CompoundTag_): void;
        track(type: Internal.FrequencyType_<any>, needsSync: boolean, needsListCache: boolean, notifyNeighbors: boolean): void;
        tickServer(): void;
        readConfiguredFrequencies(player: Internal.Player_, data: Internal.CompoundTag_): void;
        addToUpdateTag(updateTag: Internal.CompoundTag_): void;
        write(nbtTags: Internal.CompoundTag_): void;
        trackForMainContainer(container: Internal.MekanismContainer_): void;
        invalidate(): void;
        getPublicCache<FREQ extends Internal.Frequency>(type: Internal.FrequencyType_<FREQ>): Internal.List<FREQ>;
        unsetFrequency<FREQ extends Internal.Frequency>(type: Internal.FrequencyType_<FREQ>): void;
        hasCustomFrequencies(): boolean;
        read(nbtTags: Internal.CompoundTag_): void;
        getFrequency<FREQ extends Internal.Frequency>(type: Internal.FrequencyType_<FREQ>): FREQ;
        removed(): void;
        setFrequencyFromData<FREQ extends Internal.Frequency>(type: Internal.FrequencyType_<FREQ>, data: Internal.Frequency$FrequencyIdentity_, player: Internal.UUID_): void;
        writeConfiguredFrequencies(data: Internal.CompoundTag_): void;
        getPrivateCache<FREQ extends Internal.Frequency>(type: Internal.FrequencyType_<FREQ>): Internal.List<FREQ>;
    }
    type TileComponentFrequency_ = TileComponentFrequency;
    class ControlsHandler {
        constructor(arg0: Internal.IXaeroMinimap_, arg1: Internal.XaeroMinimapSession_)
        keyDownPost(arg0: Internal.KeyMapping_): void;
        setKeyState(arg0: Internal.KeyMapping_, arg1: boolean): void;
        isDown(arg0: Internal.KeyMapping_): boolean;
        keyDown(arg0: Internal.KeyMapping_, arg1: boolean, arg2: boolean): void;
        keyDownPre(arg0: Internal.KeyMapping_): void;
        keyUp(arg0: Internal.KeyMapping_, arg1: boolean): void;
        keyUpPre(arg0: Internal.KeyMapping_): void;
        keyUpPost(arg0: Internal.KeyMapping_): void;
    }
    type ControlsHandler_ = ControlsHandler;
    class GeodeLayerSettings {
        constructor(arg0: number, arg1: number, arg2: number, arg3: number)
        readonly innerLayer: number;
        readonly middleLayer: number;
        static readonly CODEC: Internal.Codec<Internal.GeodeLayerSettings>;
        readonly outerLayer: number;
        readonly filling: number;
    }
    type GeodeLayerSettings_ = GeodeLayerSettings;
    interface CompositeContext {
        abstract compose(arg0: Internal.Raster_, arg1: Internal.Raster_, arg2: Internal.WritableRaster_): void;
        abstract dispose(): void;
    }
    type CompositeContext_ = CompositeContext;
    interface RegistrySupplier <T> extends Internal.DeferredSupplier<T> {
        abstract getRegistrarManager(): Internal.RegistrarManager;
        getKey(): Internal.ResourceKey<T>;
        stream(): Internal.Stream<T>;
        ifPresent(action: Internal.Consumer_<T>): void;
        orElseGet(supplier: Internal.Supplier_<T>): T;
        ifPresentOrElse(action: Internal.Consumer_<T>, emptyAction: Internal.Runnable_): void;
        getRegistryKey(): Internal.ResourceKey<Internal.Registry<T>>;
        abstract getRegistrar(): Internal.Registrar<T>;
        getOrNull(): T;
        orElse(other: T): T;
        abstract getId(): ResourceLocation;
        abstract isPresent(): boolean;
        abstract getRegistryId(): ResourceLocation;
        abstract get(): T;
        listen(callback: Internal.Consumer_<T>): void;
        toOptional(): Internal.Optional<T>;
        get registrarManager(): Internal.RegistrarManager
        get key(): Internal.ResourceKey<T>
        get registryKey(): Internal.ResourceKey<Internal.Registry<T>>
        get registrar(): Internal.Registrar<T>
        get orNull(): T
        get id(): ResourceLocation
        get present(): boolean
        get registryId(): ResourceLocation
    }
    type RegistrySupplier_<T> = RegistrySupplier<T>;
    class MetricSampler$MetricSamplerBuilder <T> {
        constructor(arg0: string, arg1: Internal.MetricCategory_, arg2: Internal.ToDoubleFunction_<T>, arg3: T)
        withBeforeTick(arg0: Internal.Consumer_<T>): this;
        withThresholdAlert(arg0: Internal.MetricSampler$ThresholdTest_): this;
        build(): Internal.MetricSampler;
    }
    type MetricSampler$MetricSamplerBuilder_<T> = MetricSampler$MetricSamplerBuilder<T>;
    interface ResultConsumer <S> {
        abstract onCommandComplete(arg0: Internal.CommandContext_<S>, arg1: boolean, arg2: number): void;
        (arg0: Internal.CommandContext<S>, arg1: boolean, arg2: number): void;
    }
    type ResultConsumer_<S> = ResultConsumer<S>;
    class ImageCapabilities implements Internal.Cloneable {
        constructor(arg0: boolean)
        clone(): any;
        isAccelerated(): boolean;
        isTrueVolatile(): boolean;
        get accelerated(): boolean
        get trueVolatile(): boolean
    }
    type ImageCapabilities_ = ImageCapabilities;
    class TripWireBlock extends Internal.Block {
        constructor(arg0: Internal.TripWireHookBlock_, arg1: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        shouldConnectTo(arg0: Internal.BlockState_, arg1: Internal.Direction_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static readonly ATTACHED: Internal.BooleanProperty;
        static readonly NORTH: Internal.BooleanProperty;
        static readonly SOUTH: Internal.BooleanProperty;
        static readonly WEST: Internal.BooleanProperty;
        static readonly POWERED: Internal.BooleanProperty;
        static readonly DISARMED: Internal.BooleanProperty;
        static readonly EAST: Internal.BooleanProperty;
    }
    type TripWireBlock_ = TripWireBlock;
    class DecoratedPotRecipe extends Internal.CustomRecipe {
        constructor(arg0: ResourceLocation_, arg1: Internal.CraftingBookCategory_)
        getIngredients(): Internal.NonNullList<Internal.Ingredient>;
        getGroup(): string;
        getToastSymbol(): Internal.ItemStack;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        matches(arg0: Internal.CraftingContainer_, arg1: Internal.Level_): boolean;
        getSchema(): Internal.RecipeSchema;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        getRemainingItems(arg0: Internal.CraftingContainer_): Internal.NonNullList<Internal.ItemStack>;
        getType(): ResourceLocation;
        assemble(arg0: Internal.CraftingContainer_, arg1: Internal.RegistryAccess_): Internal.ItemStack;
        setGroup(group: string): void;
        getOrCreateId(): ResourceLocation;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        isIncomplete(): boolean;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        static createDecoratedPotItem(arg0: Internal.DecoratedPotBlockEntity$Decorations_): Internal.ItemStack;
        getMod(): string;
        get ingredients(): Internal.NonNullList<Internal.Ingredient>
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get schema(): Internal.RecipeSchema
        get type(): ResourceLocation
        set group(group: string)
        get orCreateId(): ResourceLocation
        get incomplete(): boolean
        get mod(): string
    }
    type DecoratedPotRecipe_ = DecoratedPotRecipe;
    interface AccessibleSelection {
        abstract clearAccessibleSelection(): void;
        abstract addAccessibleSelection(arg0: number): void;
        abstract getAccessibleSelection(arg0: number): Internal.Accessible;
        abstract removeAccessibleSelection(arg0: number): void;
        abstract selectAllAccessibleSelection(): void;
        abstract isAccessibleChildSelected(arg0: number): boolean;
        abstract getAccessibleSelectionCount(): number;
        get accessibleSelectionCount(): number
    }
    type AccessibleSelection_ = AccessibleSelection;
    class ProjectileImpactEvent extends Internal.EntityEvent {
        constructor()
        constructor(arg0: Internal.Projectile_, arg1: Internal.HitResult_)
        getImpactResult(): Internal.ProjectileImpactEvent$ImpactResult;
        getProjectile(): Internal.Projectile;
        setImpactResult(arg0: Internal.ProjectileImpactEvent$ImpactResult_): void;
        getRayTraceResult(): Internal.HitResult;
        get impactResult(): Internal.ProjectileImpactEvent$ImpactResult
        get projectile(): Internal.Projectile
        set impactResult(arg0: Internal.ProjectileImpactEvent$ImpactResult_)
        get rayTraceResult(): Internal.HitResult
    }
    type ProjectileImpactEvent_ = ProjectileImpactEvent;
    class ModuleDescriptor$Exports$Modifier extends Internal.Enum<Internal.ModuleDescriptor$Exports$Modifier> {
        static values(): Internal.ModuleDescriptor$Exports$Modifier[];
        static valueOf(arg0: string): Internal.ModuleDescriptor$Exports$Modifier;
        static readonly SYNTHETIC: Internal.ModuleDescriptor$Exports$Modifier;
        static readonly MANDATED: Internal.ModuleDescriptor$Exports$Modifier;
    }
    type ModuleDescriptor$Exports$Modifier_ = "mandated" | "synthetic" | ModuleDescriptor$Exports$Modifier;
    class DynamicRecipeComponent extends Internal.Record {
        constructor(desc: Internal.TypeDescJS_, factory: Internal.DynamicRecipeComponent$Factory_)
        desc(): Internal.TypeDescJS;
        factory(): Internal.DynamicRecipeComponent$Factory;
    }
    type DynamicRecipeComponent_ = DynamicRecipeComponent;
    class Item implements Internal.FeatureElement, Internal.ItemFTBL, Internal.ItemLike, Internal.IForgeItem, Internal.ItemKJS, Internal.IrisItemLightProvider, Internal.IExtendedItem, Internal.InjectedItemExtension {
        constructor(arg0: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        setRarity(arg0: Internal.Rarity_): void;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        getDestroySpeed(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): number;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        /**
         * @deprecated
        */
        onDestroyed(arg0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isComplex(): boolean;
        onCraftedBy(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        onUseTick(arg0: Internal.Level_, arg1: Internal.LivingEntity_, arg2: Internal.ItemStack_, arg3: number): void;
        appendHoverText(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.List_<net.minecraft.network.chat.Component>, arg3: Internal.TooltipFlag_): void;
        canBeHurtBy(arg0: DamageSource_): boolean;
        /**
         * @deprecated
        */
        getFoodProperties(): Internal.FoodProperties;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        getDescriptionId(): string;
        getUseAnimation(arg0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        asItem(): this;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        getTypeData(): Internal.CompoundTag;
        getDefaultInstance(): Internal.ItemStack;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getBarWidth(arg0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getItem(): this;
        getBarColor(arg0: Internal.ItemStack_): number;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        /**
         * @deprecated
        */
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        /**
         * @deprecated
        */
        hasCraftingRemainingItem(): boolean;
        getDescription(): net.minecraft.network.chat.Component;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        static byId(arg0: number): Internal.Item;
        getRenderPropertiesInternal(): any;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        interactLivingEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.LivingEntity_, arg3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        moonlight$setClientAnimationExtension(obj: any): void;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        useOn(arg0: Internal.UseOnContext_): Internal.InteractionResult;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        getRarity(arg0: Internal.ItemStack_): Internal.Rarity;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        isEdible(): boolean;
        getTooltipImage(arg0: Internal.ItemStack_): Internal.Optional<Internal.TooltipComponent>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        /**
         * @deprecated
        */
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        handler$bml000$initializeClient(consumer: Internal.Consumer_<any>, ci: Internal.CallbackInfo_): void;
        getId(): string;
        isEnchantable(arg0: Internal.ItemStack_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther(arg0: Internal.ItemStack_, arg1: Internal.Slot_, arg2: Internal.ClickAction_, arg3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        isFoil(arg0: Internal.ItemStack_): boolean;
        isRepairable(arg0: Internal.ItemStack_): boolean;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        useOnRelease(arg0: Internal.ItemStack_): boolean;
        canAttackBlock(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        setDigSpeed(speed: number): void;
        getDescriptionId(arg0: Internal.ItemStack_): string;
        releaseUsing(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.LivingEntity_, arg3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible(arg0: Internal.ItemStack_): boolean;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getUseDuration(arg0: Internal.ItemStack_): number;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        /**
         * @deprecated
        */
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock(arg0: Internal.Block_): Internal.Item;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        canFitInsideContainerItems(): boolean;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        isCorrectToolForDrops(arg0: Internal.BlockState_): boolean;
        verifyTagAfterLoad(arg0: Internal.CompoundTag_): void;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        finishUsingItem(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        getEatingSound(): Internal.SoundEvent;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        initializeClient(arg0: Internal.Consumer_<Internal.IClientItemExtensions>): void;
        getDamage(arg0: Internal.ItemStack_): number;
        mineBlock(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.BlockState_, arg3: BlockPos_, arg4: Internal.LivingEntity_): boolean;
        setNameKey(arg0: string): void;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName(arg0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        /**
         * @deprecated
        */
        getDefaultAttributeModifiers(arg0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        inventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Entity_, arg3: number, arg4: boolean): void;
        hurtEnemy(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: Internal.LivingEntity_): boolean;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        /**
         * @deprecated
        */
        getCraftingRemainingItem(): this;
        getTypeItemStackKey(): Internal.ItemStackKey;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        shouldOverrideMultiplayerNbt(): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        requiredFeatures(): Internal.FeatureFlagSet;
        static getId(arg0: Internal.Item_): number;
        overrideOtherStackedOnMe(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.Slot_, arg3: Internal.ClickAction_, arg4: Internal.Player_, arg5: Internal.SlotAccess_): boolean;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        /**
         * @deprecated
        */
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get typeData(): Internal.CompoundTag
        get defaultInstance(): Internal.ItemStack
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        /**
         * @deprecated
        */
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get renderPropertiesInternal(): any
        set itemBuilder(b: Internal.ItemBuilder_)
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        /**
         * @deprecated
        */
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        /**
         * @deprecated
        */
        get maxStackSize(): number
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        /**
         * @deprecated
        */
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
        static readonly BY_BLOCK: {[key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.ThresholdSwitchBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.HoglinMountBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.SlidingDoorBlock]: Internal.BlockItem, [key: Internal.SculkVeinBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.EncasedFanBlock]: Internal.BlockItem, [key: Internal.NotSoMysteriousCubeBlock]: Internal.AEBaseBlockItem, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.CarvedPumpkinBlock]: Internal.BlockItem, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.AwningBlock]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.TaskScreenBlock]: Internal.ScreenBlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.IndustrialLampBlock]: Internal.BlockItem, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.MushroomBlock]: Internal.BlockItem, [key: Internal.LadderBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.CartAssemblerBlock]: Internal.CartAssemblerBlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ReactorEnergyBlock]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.SlidingDoorBlock]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.AzaleaFlowerBlock]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.BlockEnergyCube]: Internal.ItemBlockEnergyCube, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockQIOComponent$ItemBlockQIOInventoryComponent, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.SurfaceMossBlock]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.Log_Bridge]: Internal.FuelBlockItemWithInfo, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.CherryLeavesBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.InfestedBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.HeatPipeBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.ControllerBlock]: Internal.AEBaseBlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.WindmillBearingBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.SkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.CoralBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.MatrixFrameBlock]: Internal.AEBaseBlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: earth.terrarium.adastra.common.blocks.GlobeBlock]: Internal.RenderedBlockItem, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockInductionCell, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.FeastBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.CoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.TintedGlassBlock]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.SafeBlock]: Internal.SafeItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.ElectricalConnectorBlock]: Internal.BlockItem, [key: Internal.PulleyBlock]: Internal.WoodBasedBlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.HoneyBlock]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.FlywheelBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.AtomizerBlock]: Internal.BlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.GoldTrapdoorBlock]: Internal.BlockItem, [key: Internal.VineBlock]: Internal.BlockItem, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.ReactorFuelAcceptorBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.EndermanSkullWallBlock]: Internal.EndermanHeadItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.ExperienceBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.CarrotBlock]: Internal.ItemNameBlockItem, [key: Internal.LeverBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.MachineBlock]: Internal.TooltipBlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RedstoneLampBlock]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ReactorTransparentBlock]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.BlockValve]: Internal.BlockItemDescriptable, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.MetalScaffoldingBlock]: Internal.MetalScaffoldingBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockThermodynamicConductor]: Internal.ItemBlockThermodynamicConductor, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.PlayerHeadBlock]: Internal.PlayerHeadItem, [key: Internal.RedstoneContactBlock]: Internal.RedstoneContactItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.RedstoneIlluminatorBlock]: Internal.BlockItem, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.BlockEnergyCube]: Internal.ItemBlockEnergyCube, [key: Internal.Bridge_Support]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ImplementedMagnetBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.BoilingWaterCauldronBlock]: Internal.Items$1, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.PistonBaseBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.CaveVinesBlock]: Internal.ItemNameBlockItem, [key: Internal.EndermanSkullBlock]: Internal.EndermanHeadItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: com.simibubi.create.content.contraptions.pulley.PulleyBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockInductionProvider, [key: Internal.ModStairBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.TallFlowerBlock]: Internal.DoubleHighBlockItem, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.BookPileBlock]: Internal.EnchantedBookItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.WildCropBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BrassTunnelBlock]: Internal.BeltTunnelItem, [key: Internal.Log_Bridge]: Internal.FuelBlockItemWithInfo, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.MachineBlock]: Internal.TooltipBlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BrewingStandBlock]: Internal.BlockItem, [key: Internal.LampBlock]: Internal.ChemicalBlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FlaxBaleBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.MechanicalCrafterBlock]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockQIOComponent$ItemBlockQIOInventoryComponent, [key: Internal.FungusColonyBlock]: Internal.FungusColonyItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.SharestoneBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockLogisticalSorter]: Internal.ItemBlockMachine, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.TallGrassBlock]: Internal.BlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.HugeMushroomBlock]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.WindVaneBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.InterfaceBlock]: Internal.AEBaseBlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.IOPortBlock]: Internal.AEBaseBlockItem, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.FlapDisplayBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.RailBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.FlagBlock]: Internal.FlagItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.MechanicalPistonBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.SconceBlock]: Internal.StandingAndWallBlockItem, [key: Internal.BaseCoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.WildCropBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.CabbageBlock]: Internal.ItemNameBlockItem, [key: Internal.SafetyNetBlock]: Internal.FuelBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BlockRadioactiveWasteBarrel]: Internal.ItemBlockRadioactiveWasteBarrel, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.ReactorCoreBlock]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.WaystoneBlock]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SmallIndustrialLampBlock]: Internal.BlockItem, [key: Internal.GearshiftBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RiceRollMedleyBlock]: Internal.BlockItem, [key: Internal.PoweredBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.WhistleBlock]: Internal.BlockItem, [key: Internal.BlockCardboardBox]: Internal.ItemBlockCardboardBox, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.AzaleaBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.PitcherCropBlock]: Internal.ItemNameBlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockFactoryMachine<any, any>]: Internal.ItemBlockMachine, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.JapaneseDoors]: Internal.BlockItem, [key: Internal.DoublePlantBlock]: Internal.DoubleHighBlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.BasketBlock]: Internal.FuelBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.SpatialIOPortBlock]: Internal.AEBaseBlockItem, [key: Internal.CoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.GarageDoor]: Internal.FuelItemBlock, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockQIOComponent, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.ConnectedGlassBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CarpetBlock]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Bridge_Lantern]: Internal.LightInfo, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.PortstoneBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.StationBlock]: Internal.TrackTargetingBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.CoconutLeavesBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.BambooSpikesBlock]: Internal.BambooSpikesTippedItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.CampfireBlock]: Internal.BlockItem, [key: Internal.GutterTall]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.ChorusPlantBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.SandyShrubBlock]: Internal.BlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.DisplayLinkBlock]: Internal.DisplayLinkBlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.FungusBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Rail_Bridge]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.SharestoneBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.BarrierBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.WallLanternBlock]: Internal.BlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.RainGutter]: Internal.BlockItem, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.CreativeCrateBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.BlockThermodynamicConductor]: Internal.ItemBlockThermodynamicConductor, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.NetherWartBlock]: Internal.ItemNameBlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.FodderBlock]: Internal.BlockItem, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockMechanicalPipe]: Internal.ItemBlockMechanicalPipe, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockGasPipe]: Internal.BlockItemGasPipe, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.RootedDirtBlock]: Internal.BlockItem, [key: Internal.StripedChair]: Internal.ItemBlock, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.TaskScreenBlock]: Internal.ScreenBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.Bamboo_Bridge]: Internal.FuelBlockItemWithInfo, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.MagmaBlock]: Internal.BlockItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Rail_Bridge]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.Rail_Bridge]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.SkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.WallSkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.BubbleBlock]: Internal.BubbleBlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.CoconutBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockUniversalCable]: Internal.ItemBlockUniversalCable, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.NetheriteTrapdoorBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.FurnaceBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.ItemDrainBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RainGutter]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SeagrassBlock]: Internal.BlockItem, [key: Internal.WaystoneBlock]: Internal.BlockItem, [key: Internal.ModWallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.AnvilBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.FallingBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BaseCoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.BlockStructuralGlass<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.WaterPumpBlock]: Internal.TooltipBlockItem, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: mekanism.common.block.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.CeilingBannerBlock]: Internal.BannerItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockBin]: Internal.ItemBlockBin, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: earth.terrarium.adastra.common.blocks.SlidingDoorBlock]: Internal.BlockItem, [key: earth.terrarium.adastra.common.blocks.pipes.PipeBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockMachine, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BlockLaserFocusMatrix]: Internal.ItemBlockTooltip<any>, [key: Internal.Log_Bridge]: Internal.FuelBlockItemWithInfo, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.SmallIndustrialLampBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TrackObserverBlock]: Internal.TrackTargetingBlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ModBlocks$2]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.ModBlocks$14]: Internal.BlockItem, [key: Internal.StonecutterBlock]: Internal.BlockItem, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.StemBlock]: Internal.ItemNameBlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockGasPipe]: Internal.BlockItemGasPipe, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FluidTankBlock]: Internal.FluidTankItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.RainGutter]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.ChainBlock]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.EncasedCogwheelBlock]: Internal.BlockItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.CombinerBlock]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.SoapBlock]: Internal.BlockItem, [key: Internal.TatamiMatBlock]: Internal.FuelBlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.InfestedBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.WeightedPressurePlateBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.AmethystClusterBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.DragonEggBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.Rail_Bridge]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.EquipableCarvedPumpkinBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.FlagBlock]: Internal.FlagItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.CogBlock]: Internal.BlockItem, [key: Internal.IndustrialLampBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.GutterTall]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.DriveBlock]: Internal.AEBaseBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.MimicarnationBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.CuttingBoardBlock]: Internal.FuelBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ImplementedMagnetBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FrameBlock]: Internal.TimberFrameItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.ModStandingSignBlock]: Internal.SignItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.QuantumRingBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BellBlock]: Internal.BlockItem, [key: Internal.GarageDoor]: Internal.BlockItem, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.IceBlock]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.QuartzFixtureBlock]: Internal.AEBaseBlockItem, [key: Internal.Rail_Bridge]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.Steep]: Internal.BlockItem, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.PoweredRailBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ShaftBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockInductionCell, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CrankBlock]: Internal.AEBaseBlockItem, [key: Internal.Chair]: Internal.ItemBlock, [key: earth.terrarium.adastra.common.blocks.SlidingDoorBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.ComparatorBlock]: Internal.BlockItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.TatamiBlock]: Internal.FuelBlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.FlagBlock]: Internal.FlagItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockFrame]: Internal.BlockItemDescriptable, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.TntBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.CoralBlock]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.NyliumBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.TurtleEggBlock]: Internal.BlockItem, [key: Internal.InscriberBlock]: Internal.AEBaseBlockItem, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TatamiHalfMatBlock]: Internal.FuelBlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.GutterTall]: Internal.BlockItem, [key: Internal.InfestedBlock]: Internal.BlockItem, [key: Internal.WallTorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.MushroomColonyBlock]: Internal.MushroomColonyItem, [key: Internal.LampBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.StickBlock]: Internal.Item, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.FlagBlock]: Internal.BlockItem, [key: Internal.DissolverBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.StatueBlock]: Internal.BlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.BeltBlock]: Internal.BeltConnectorItem, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.IndustrialLampBlock]: Internal.BlockItem, [key: Internal.Bridge_Block_Rope]: Internal.FuelBlockItemWithInfo, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockLogisticalTransporter]: Internal.ItemBlockLogisticalTransporter, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.ModBlocks$12]: Internal.BlockItem, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.SculkBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.TorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.HoneyGlazedHamBlock]: Internal.BlockItem, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.FlagBlock]: Internal.FlagItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.BlockValve]: Internal.BlockItemDescriptable, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.BlockGasTransformerAddonTank]: Internal.BlockItemDescriptable, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.Bridge_Block_Rope]: Internal.FuelBlockItemWithInfo, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CopycatPanelBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.EnergiserBlock]: Internal.AssemblyOperatorBlockItem, [key: Internal.Bridge_Block_Rope]: Internal.FuelBlockItemWithInfo, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.FlagBlock]: Internal.BlockItem, [key: Internal.AwningBlock]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.JarBlock]: Internal.JarItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.MechanicalMixerBlock]: Internal.AssemblyOperatorBlockItem, [key: Internal.RainGutter]: Internal.BlockItem, [key: Internal.CookingPotBlock]: Internal.CookingPotItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Bridge_Support]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.CeilingBannerBlock]: Internal.BannerItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.WallSkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.RollerBlock]: Internal.RollerBlockItem, [key: Internal.BlockSeismicMarker]: Internal.BlockItemDescriptable, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.RelayerBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.LargeWaterWheelBlock]: Internal.LargeWaterWheelBlockItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.FlagBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockInductionProvider, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.ElevatorPulleyBlock]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.TurnTableBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.GutterTall]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.HosePulleyBlock]: Internal.BlockItem, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockFactoryMachine<any, any>]: Internal.ItemBlockMachine, [key: Internal.BlockPressurizedTube]: Internal.ItemBlockPressurizedTube, [key: Internal.DropperBlock]: Internal.BlockItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.RopeBlock]: Internal.RopeItem, [key: Internal.Bridge_Support]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Bridge_Block_Rope]: Internal.FuelBlockItemWithInfo, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.WildCropBlock]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.SmallIndustrialLampBlock]: Internal.BlockItem, [key: Internal.BlockFluidTank]: Internal.ItemBlockFluidTank, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.CasingBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.SmallIndustrialLampBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.AwningBlock]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.FlagBlock]: Internal.FlagItem, [key: Internal.EncasedShaftBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.RainGutter]: Internal.BlockItem, [key: Internal.EncasedShaftBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.MotorBlock]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.BambooStalkBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.SlimeBlock]: Internal.BlockItem, [key: Internal.SkilletBlock]: Internal.SkilletItem, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.ModCeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.CraftingUnitBlock]: Internal.CraftingBlockItem, [key: Internal.AwningBlock]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.AwningBlock]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ReactorHeatVentBlock]: Internal.BlockItem, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockFluidPipe]: Internal.BlockItemDescriptable, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.EnergyCellBlock]: Internal.EnergyCellBlockItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.NozzleBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockObsidianTNT]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BracketBlock]: Internal.BracketBlockItem, [key: Internal.SkyChestBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.RainGutter]: Internal.BlockItem, [key: Internal.JapaneseDoors]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockChemicalTank, [key: Internal.MotorBlock]: Internal.BlockItem, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.MachineBlock]: Internal.TooltipBlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.BedBlock]: Internal.BedItem, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.GravelBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: earth.terrarium.adastra.common.blocks.pipes.PipeBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BracketBlock]: Internal.BracketBlockItem, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.PipeDuctBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.ModStairBlock]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.FarmBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.PumpkinBlock]: Internal.BlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.MelonBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.CommandBlock]: Internal.GameMasterBlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.HeatPumpBlock]: Internal.BlockItem, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.HopperBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockChemicalTank, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.Bridge_Support]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.IndustrialLampBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.HalfTransparentBlock]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.SandcastleBlock]: Internal.SandcastleBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.CanvasRugBlock]: Internal.FuelBlockItem, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.AwningBlock]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.LinearChassisBlock]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.FlagBlock]: Internal.FlagItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.GutterTall]: Internal.BlockItem, [key: Internal.GutterTall]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.LecternBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.ModWallSignBlock]: Internal.SignItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.GlassBlock]: Internal.TooltipBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.WallTorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockMachine, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: earth.terrarium.adastra.common.blocks.GlobeBlock]: Internal.RenderedBlockItem, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.AwningBlock]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.SpeakerBlock]: Internal.WoodBasedBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.IndustrialLampBlock]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: Internal.FuelBlockItemWithInfo, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CasingBlock]: Internal.BlockItem, [key: Internal.BlockLogisticalTransporter]: Internal.ItemBlockLogisticalTransporter, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.SequencedGearshiftBlock]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.MetalLadderBlock]: Internal.BlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.AwningBlock]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.StuffedHoglinBlock]: Internal.BlockItem, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.SmallIndustrialLampBlock]: Internal.BlockItem, [key: Internal.StirlingEngineBlock]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.LampBlock]: Internal.ChemicalBlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockBase<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockBin]: Internal.ItemBlockBin, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.MudBlock]: Internal.BlockItem, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.BlastFurnaceBlock]: Internal.BlockItem, [key: Internal.LiquifierBlock]: Internal.BlockItem, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WildCropBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CoralPlantBlock]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.CraftingUnitBlock]: Internal.CraftingBlockItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BaseCoralPlantBlock]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Log_Bridge]: Internal.FuelBlockItemWithInfo, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.FlagBlock]: Internal.FlagItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.InfestedBlock]: Internal.BlockItem, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.FlagBlock]: Internal.FlagItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.BuddingAmethystBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Bridge_Support]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.EnchantmentTableBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockCompressor]: Internal.BlockItemDescriptable, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.MetalLadderBlock]: Internal.BlockItem, [key: Internal.ModBlocks$10]: Internal.BlockItem, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.CommandBlock]: Internal.GameMasterBlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.SpeedControllerBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.PiglinWallSkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.LavaCauldronBlock]: Internal.Items$1, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockTeleporter, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.SmallIndustrialLampBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ChargerBlock]: Internal.AEBaseBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.CellWorkbenchBlock]: Internal.AEBaseBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.FallingBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.WeepingVinesBlock]: Internal.BlockItem, [key: Internal.OrganicCompostBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockChargepad]: Internal.ItemBlockTooltip<any>, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RainGutter]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BuddingCertusQuartzBlock]: Internal.AEBaseBlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.TwistingVinesBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.SchematicTableBlock]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.BlockBin]: Internal.ItemBlockBin, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.Bridge_Stairs]: Internal.FuelBlockItemWithInfo, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.IndustrialLampBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.HourGlassBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.MetalScaffoldingBlock]: Internal.MetalScaffoldingBlockItem, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.RainGutter]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.PotatoBlock]: Internal.ItemNameBlockItem, [key: Internal.Bridge_Support]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.CuckooClockBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.GeneratorCoilBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.FlaxBlock]: Internal.ItemNameBlockItem, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.ModBlocks$6]: Internal.BlockItem, [key: Internal.HangingRootsBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: mekanism.common.block.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.BlockMechanicalPipe]: Internal.ItemBlockMechanicalPipe, [key: Internal.CommandBlock]: Internal.GameMasterBlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.AzaleaLogBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockMachine, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FlagBlock]: Internal.BlockItem, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SchematicannonBlock]: Internal.BlockItem, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPersonalChest]: Internal.ItemBlockPersonalStorage<any>, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.IronGateBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.CabinetBlock]: Internal.BlockItem, [key: Internal.Bridge_Block_Rope]: Internal.FuelBlockItemWithInfo, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CraftingUnitBlock]: Internal.CraftingBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SharestoneBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockMachine, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BacktankBlock]: Internal.BacktankItem$BacktankBlockItem, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.DeployerBlock]: Internal.AssemblyOperatorBlockItem, [key: Internal.BlockPipePump]: Internal.BlockItemDescriptable, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.SkyStoneTankBlock]: Internal.AEBaseBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.SolarHeatingPlateBlock]: Internal.BlockItem, [key: Internal.BrassDiodeBlock]: Internal.BlockItem, [key: Internal.IndustrialLampBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.LightDetectorBlock]: Internal.AEBaseBlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockMachine, [key: Internal.SconceBlock]: Internal.StandingAndWallBlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: mekanism.common.block.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.BaseCoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.WarpPlateBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.JarBoatBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockSecurityDesk, [key: Internal.RootsBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlackboardBlock]: Internal.BlackboardItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockQIOComponent, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.CocoaBlock]: Internal.ItemNameBlockItem, [key: Internal.SpongeBlock]: Internal.BlockItem, [key: Internal.ModWallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.BlockPipePump]: Internal.BlockItemDescriptable, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.BlockFluidTank]: Internal.ItemBlockFluidTank, [key: Internal.SmallIndustrialLampBlock]: Internal.BlockItem, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.WallTorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.SharestoneBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.TallFlowerBlock]: Internal.DoubleHighBlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.PumpBlock]: Internal.BlockItem, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.SandBlock]: Internal.BlockItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Bridge_Block_Rope]: Internal.FuelBlockItemWithInfo, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockFluidTank]: Internal.ItemBlockFluidTank, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.CartographyTableBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.SmallIndustrialLampBlock]: Internal.BlockItem, [key: Internal.HauntedBellBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: dev.ftb.mods.ftbquests.block.DetectorBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.MyceliumBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: earth.terrarium.adastra.common.blocks.GlobeBlock]: Internal.RenderedBlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.GunpowderBlock]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.MetalScaffoldingBlock]: Internal.MetalScaffoldingBlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.CreativeMotorBlock]: Internal.BlockItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: mekanism.common.block.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.ObserverBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CasingBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.CabinetBlock]: Internal.BlockItem, [key: Internal.DrillBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CraftingUnitBlock]: Internal.CraftingBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.FlagBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.WetSpongeBlock]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SconceWallBlock]: Internal.StandingAndWallBlockItem, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockMachine, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.DispenserBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.QuartzLampBlock]: Internal.BlockItem, [key: Internal.CompactorBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.FlippedBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.LockBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: mekanism.common.block.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockLaserAmplifier, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ControlsBlock]: Internal.BlockItem, [key: Internal.RichSoilFarmlandBlock]: Internal.BlockItem, [key: Internal.ChestBlock]: Internal.BlockItem, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockCustomGlass]: Internal.BlockItemDescriptable, [key: Internal.GarageDoor]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.AmethystClusterBlock]: Internal.BlockItem, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.RichSoilBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.Rail_Bridge]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.CeilingBannerBlock]: Internal.BannerItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.ReactorCoreBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockEnergyCube]: Internal.ItemBlockEnergyCube, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BuddingCertusQuartzBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.BlackstoneFurnaceBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: earth.terrarium.adastra.common.blocks.SlidingDoorBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DetectorRailBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.LanternBlock]: Internal.BlockItem, [key: Internal.MossBlock]: Internal.BlockItem, [key: earth.terrarium.adastra.common.blocks.SlidingDoorBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockInductionProvider, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockBase<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.MachineBlock]: Internal.TooltipBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.GirderBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ModBlocks$9]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.ModBlocks$13]: Internal.BlockItem, [key: Internal.StrawBaleBlock]: Internal.BlockItem, [key: Internal.StructureBlock]: Internal.GameMasterBlockItem, [key: Internal.QuestBarrierBlock]: Internal.QuestBarrierBlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.CoralPlantBlock]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.BlockFluidTank]: Internal.ItemBlockFluidTank, [key: Internal.BlockFactoryMachine$BlockFactoryMachineModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.GlobeBlock]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.BlockRestrictiveTransporter]: Internal.ItemBlockRestrictiveTransporter, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.GutterTall]: Internal.BlockItem, [key: Internal.DeadBushBlock]: Internal.BlockItem, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.CoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.SharestoneBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.SeaPickleBlock]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BrassFunnelBlock]: Internal.FunnelItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.FlagBlock]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.SharestoneBlock]: Internal.BlockItem, [key: Internal.TallGrassBlock]: Internal.BlockItem, [key: Internal.ModStairBlock]: Internal.BlockItem, [key: Internal.RedStoneWireBlock]: Internal.ItemNameBlockItem, [key: Internal.EndLampBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.ModWallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.BlockLogisticalTransporter]: Internal.ItemBlockLogisticalTransporter, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.MetalLadderBlock]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.BlockMechanicalPipe]: Internal.ItemBlockMechanicalPipe, [key: Internal.ModWallSignBlock]: Internal.SignItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.SharestoneBlock]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.Log_Bridge]: Internal.FuelBlockItemWithInfo, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.GutterTall]: Internal.BlockItem, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.BlockIndustrialAlarm]: Internal.ItemBlockTooltip<any>, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockMachine, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.BlockEnergyCube]: Internal.ItemBlockEnergyCube, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FungusBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.TinyTNTBlock]: Internal.AEBaseBlockItem, [key: Internal.StageBarrierBlock]: Internal.StageBarrierBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.JigsawBlock]: Internal.GameMasterBlockItem, [key: Internal.SolarHeatingPlateBlock]: Internal.BlockItem, [key: Internal.BrassDiodeBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FrameBlock]: Internal.TimberFrameItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.RoastChickenBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.RepeaterBlock]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.ModStandingSignBlock]: Internal.SignItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.IndustrialLampBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.JukeboxBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.RadioBlock]: Internal.TooltipBlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Log_Bridge]: Internal.FuelBlockItemWithInfo, [key: Internal.BlockUniversalCable]: Internal.ItemBlockUniversalCable, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.GutterTall]: Internal.BlockItem, [key: Internal.InfestedBlock]: Internal.BlockItem, [key: Internal.ModCeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.FlagBlock]: Internal.FlagItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.MachineBlock]: Internal.TooltipBlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.SoulSandBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.SackBlock]: Internal.SackItem, [key: Internal.ItemShelfBlock]: Internal.WoodBasedBlockItem, [key: Internal.CarbonBrushesBlock]: Internal.BlockItem, [key: Internal.CoralPlantBlock]: Internal.BlockItem, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockInductionProvider, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BeaconBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockInductionCell, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.ControllerRailBlock]: Internal.BlockItem, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.ModCeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.LampBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockChemicalTank, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.TrainTrapdoorBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BaseCoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.FlagBlock]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.WitherRoseBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: earth.terrarium.adastra.common.blocks.GlobeBlock]: Internal.RenderedBlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.FlagBlock]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.StickerBlock]: Internal.BlockItem, [key: Internal.CeilingBannerBlock]: Internal.BannerItem, [key: Internal.ModWallSignBlock]: Internal.SignItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ModBlocks$18]: Internal.BlockItem, [key: Internal.CogWheelBlock]: Internal.CogwheelBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.BlockTurbineRotor]: Internal.ItemBlockTooltip<any>, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.TallFlowerBlock]: Internal.DoubleHighBlockItem, [key: Internal.LaunchPadBlock]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.BlazeBurnerBlock]: Internal.BlazeBurnerBlockItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.SmallIndustrialLampBlock]: Internal.BlockItem, [key: Internal.EjectorBlock]: Internal.EjectorItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockDiversionTransporter]: Internal.ItemBlockDiversionTransporter, [key: Internal.ModStairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CraftingTableBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.GarageDoor]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.ModWallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockLaserTractorBeam, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.VibrationChamberBlock]: Internal.AEBaseBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.IronGateBlock]: Internal.BlockItem, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.CoralBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ReactorInputBlock]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.CrystalResonanceGeneratorBlock]: Internal.AEBaseBlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.MushroomBlock]: Internal.BlockItem, [key: Internal.FloweringAzaleaLogBlock]: Internal.BlockItem, [key: Internal.CrushingWheelBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SolidCoriumBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.DoublePlantBlock]: Internal.DoubleHighBlockItem, [key: Internal.BlockGasPipe]: Internal.BlockItemGasPipe, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.SteamEngineBlock]: Internal.BlockItem, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.CrankBlock]: Internal.BlockItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.GlassBlock]: Internal.BlockItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.ClockworkBearingBlock]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.LanternBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.ReactorOutputBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BaseCoralPlantBlock]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.DirtPathBlock]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.RainGutter]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.FungusColonyBlock]: Internal.FungusColonyItem, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.RainGutter]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.IndustrialLampBlock]: Internal.BlockItem, [key: Internal.CeilingBannerBlock]: Internal.BannerItem, [key: Internal.HugeMushroomBlock]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.ShepherdsPieBlock]: Internal.BlockItem, [key: Internal.TripWireHookBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SharestoneBlock]: Internal.BlockItem, [key: Internal.MangroveRootsBlock]: Internal.BlockItem, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.WebBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.GantryCarriageBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.ModStandingSignBlock]: Internal.SignItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.PedestalBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.EncasedCogwheelBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.SkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.AnvilBlock]: Internal.BlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.WeightedPressurePlateBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.RedstoneWallTorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ImplementedMagnetBlock]: Internal.BlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.NyliumBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.Rail_Bridge]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.SpringLauncherBlock]: Internal.BlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.PatternProviderBlock]: Internal.AEBaseBlockItem, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.EncasedCogwheelBlock]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.IndustrialLampBlock]: Internal.BlockItem, [key: Internal.NixieTubeBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.CoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.PlacardBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.InfestedRotatedPillarBlock]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockQIOComponent, [key: Internal.CalibratedSculkSensorBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.FlagBlock]: Internal.FlagItem, [key: Internal.LampBlock]: Internal.ChemicalBlockItem, [key: Internal.PortableStorageInterfaceBlock]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.FlagBlock]: Internal.FlagItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.EtrionicBlastFurnaceBlock]: Internal.TooltipBlockItem, [key: Internal.CakeBlock]: Internal.BlockItem, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.CoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.BaseCoralPlantBlock]: Internal.BlockItem, [key: Internal.PistonBaseBlock]: Internal.BlockItem, [key: Internal.BlockBounding]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.EnergiserBlock]: Internal.AssemblyOperatorBlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.NoticeBoardBlock]: Internal.WoodBasedBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.SpatialAnchorBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.CoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.EndRodBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.EnergiserBlock]: Internal.AssemblyOperatorBlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.GutterTall]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.SconceWallBlock]: Internal.StandingAndWallBlockItem, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.SculkShriekerBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine<any, any>]: Internal.ItemBlockMachine, [key: earth.terrarium.adastra.common.blocks.SlidingDoorBlock]: Internal.BlockItem, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.ModBlocks$4]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CoconutSaplingBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FluidPipeBlock]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.SpoutBlock]: Internal.AssemblyOperatorBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.AndesiteFunnelBlock]: Internal.FunnelItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.FeatherBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.GantryShaftBlock]: Internal.BlockItem, [key: Internal.AmethystClusterBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.MysteriousCubeBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.WildCropBlock]: Internal.BlockItem, [key: Internal.BlockCustomGlass]: Internal.BlockItemDescriptable, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.PinkPetalsBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ModBlocks$21]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.ElevatorContactBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.CertusQuartzClusterBlock]: Internal.AEBaseBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.SugarBlock]: Internal.SugarCubeItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.RainGutter]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.FlagBlock]: Internal.BlockItem, [key: Internal.Log_Bridge]: Internal.FuelBlockItemWithInfo, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ImplementedMagnetBlock]: Internal.BlockItem, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ModBlocks$8]: Internal.BlockItem, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.LadderBlock]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.LinearChassisBlock]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.MechanicalPressBlock]: Internal.AssemblyOperatorBlockItem, [key: Internal.GarageDoor]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.CeilingBannerBlock]: Internal.BannerItem, [key: Internal.BlockPressurizedTube]: Internal.ItemBlockPressurizedTube, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.Bridge_Torch]: Internal.LightInfo, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.CeilingBannerBlock]: Internal.BannerItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.GutterTall]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.WildFlaxBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.TomatoVineBlock]: Internal.ModItems$1, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.MotorExtensionBlock]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockPressurizedTube]: Internal.ItemBlockPressurizedTube, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockFactoryMachine<any, any>]: Internal.ItemBlockMachine, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.SmartObserverBlock]: Internal.BlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BrushableBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Bridge_Support]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.GutterTall]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.IndustrialLampBlock]: Internal.BlockItem, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.SharestoneBlock]: Internal.BlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.WildCropBlock]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.PropelplantCaneBlock]: Internal.BlockItem, [key: Internal.IndustrialLampBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.NoteBlock]: Internal.BlockItem, [key: Internal.LootCrateOpenerBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.CoralPlantBlock]: Internal.BlockItem, [key: Internal.ModBlocks$15]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.ChorusFlowerBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.BacktankBlock]: Internal.BacktankItem$BacktankBlockItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.Block]: Internal.BlockItem, [key: Internal.KelpBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.RainGutter]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.FlagBlock]: Internal.FlagItem, [key: Internal.CoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.HangingFlowerPotBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockCompressor]: Internal.BlockItemDescriptable, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockLogisticalTransporter]: Internal.ItemBlockLogisticalTransporter, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.LightningRodBlock]: Internal.BlockItem, [key: Internal.GlobeBlock]: Internal.BlockItem, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.WallSkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.CageBlock]: Internal.CageItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FallingBlock]: Internal.BlockItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.MechanicalPistonBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.Log_Bridge]: Internal.FuelBlockItemWithInfo, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.CraftingUnitBlock]: Internal.CraftingBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.FusionControllerBlock]: Internal.BlockItem, [key: Internal.PointedDripstoneBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.RakedGravelBlock]: Internal.BlockItem, [key: Internal.IndustrialLampBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.Bridge_Block_Rope]: Internal.FuelBlockItemWithInfo, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CogWheelBlock]: Internal.CogwheelBlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.BellowsBlock]: Internal.WoodBasedBlockItem, [key: Internal.AwningBlock]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.CeilingBannerBlock]: Internal.BannerItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.WallSkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.UrnBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockWindGenerator, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BaseCoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.ThinIceBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: earth.terrarium.adastra.common.blocks.GlobeBlock]: Internal.RenderedBlockItem, [key: Internal.BlockThermodynamicConductor]: Internal.ItemBlockThermodynamicConductor, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.SharestoneBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: Internal.PieBlock]: Internal.BlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.QuantumLinkChamberBlock]: Internal.AEBaseBlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: mekanism.common.block.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.RiceBlock]: Internal.RiceItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Log_Bridge]: Internal.FuelBlockItemWithInfo, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.FlowerBoxBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CableBusBlock]: Internal.AEBaseBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Rail_Bridge]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Rail_Bridge]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Log_Bridge]: Internal.FuelBlockItemWithInfo, [key: Internal.DaylightDetectorBlock]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.WaystoneBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.EnergyAcceptorBlock]: Internal.AEBaseBlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.AwningBlock]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.CoriumBlock]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.TallFlowerBlock]: Internal.DoubleHighBlockItem, [key: Internal.BlockUniversalCable]: Internal.ItemBlockUniversalCable, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.BaseCoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.CrystalDisplayBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.SmallDripleafBlock]: Internal.DoubleHighBlockItem, [key: Internal.Bridge_Support]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.ScaffoldingBlock]: Internal.ScaffoldingBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.BlockThermoelectricManipulator]: Internal.BlockItemDescriptable, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.PieBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.SweetBerryBushBlock]: Internal.ItemNameBlockItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SharestoneBlock]: Internal.BlockItem, [key: Internal.SeashellBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.TorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.RainGutter]: Internal.BlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.CropBlock]: Internal.ItemNameBlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.SlidingDoorBlock]: Internal.BlockItem, [key: Internal.CauldronBlock]: Internal.Items$1, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.EnderChestBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.CeilingBannerBlock]: Internal.BannerItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.GlowLichenBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.GlassPaneBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockBin]: Internal.ItemBlockBin, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.FarmersDelightCompat$PlanterRichBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TargetBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CasingBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.SandBlock]: Internal.BlockItem, [key: Internal.SkyChestBlock]: Internal.AEBaseBlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.SmithingTableBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.GutterTall]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.CasingBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.TurntableBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.MangroveLeavesBlock]: Internal.BlockItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.HeaterBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.CeilingBannerBlock]: Internal.BannerItem, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.ConnectedGlassBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.BlockFactoryMachine<any, any>]: Internal.ItemBlockMachine, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockMachine, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.ChiseledBookShelfBlock]: Internal.BlockItem, [key: Internal.WitherWallSkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.OxygenDistributorBlock]: Internal.TooltipRenderedBlockItem, [key: Internal.CraftingUnitBlock]: Internal.CraftingBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.CeilingBannerBlock]: Internal.BannerItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FlagBlock]: Internal.BlockItem, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RainGutter]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.ChuteBlock]: Internal.ChuteItem, [key: Internal.MangrovePropaguleBlock]: Internal.BlockItem, [key: Internal.WaterWheelBlock]: Internal.BlockItem, [key: Internal.BigDripleafStemBlock]: Internal.Items$1, [key: Internal.Block]: Internal.BlockItem, [key: Internal.EnergyCellBlock]: Internal.EnergyCellBlockItem, [key: Internal.Bridge_Block_Rope]: Internal.FuelBlockItemWithInfo, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BarrelBlock]: Internal.BlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.CraftingUnitBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.BlockPipeFilter]: Internal.BlockItemDescriptable, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.GrowthAcceleratorBlock]: Internal.AEBaseBlockItem, [key: Internal.PistonExtensionPoleBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SharestoneBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.Block]: Internal.BlockItem, [key: Internal.IndustrialLampBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.GoldDoorBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine<any, any>]: Internal.ItemBlockMachine, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.CeilingBannerBlock]: Internal.BannerItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.SoulCompostBlock]: Internal.BlockItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.CuckooClockBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.ModCeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.FlagBlock]: Internal.BlockItem, [key: Internal.RiceBaleBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.FrameBraceBlock]: Internal.TimberFrameItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.SpatialPylonBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.CeilingBannerBlock]: Internal.BannerItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.ModWallSignBlock]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CondenserBlock]: Internal.AEBaseBlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RadialChassisBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.WildRiceBlock]: Internal.DoubleHighBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BuddingTomatoBlock]: Internal.ModItems$1, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.AshLayerBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.CeilingBannerBlock]: Internal.BannerItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.AmethystBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.AwningBlock]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.DoublePlantBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockFluidPipe]: Internal.BlockItemDescriptable, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FloweringAzaleaLogBlock]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.RichSoulSoilBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.ItemGenBlock]: Internal.AEBaseBlockItem, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: Internal.Bridge_Support]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.GrassBlock]: Internal.BlockItem, [key: Internal.FluidTankBlock]: Internal.FluidTankItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.SmallIndustrialLampBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.EndPortalFrameBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.OnionBlock]: Internal.ItemNameBlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.NetheriteDoorBlock]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CertusQuartzClusterBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.MusicManagerBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.RootsBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.FlagBlock]: Internal.FlagItem, [key: Internal.BeehiveBlock]: Internal.BlockItem, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.ModBlocks$19]: Internal.BlockItem, [key: Internal.Bridge_Support]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: earth.terrarium.adastra.common.blocks.SlidingDoorBlock]: Internal.BlockItem, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.SharestoneBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.PancakeBlock]: Internal.PancakeItem, [key: Internal.ChainDriveBlock]: Internal.BlockItem, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.SpawnerBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SmallIndustrialLampBlock]: Internal.BlockItem, [key: Internal.FletchingTableBlock]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.Bridge_Block_Rope]: Internal.FuelBlockItemWithInfo, [key: Internal.WirelessAccessPointBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.GaugeBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: mekanism.common.block.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.FrogspawnBlock]: Internal.PlaceOnWaterBlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.HugeMushroomBlock]: Internal.BlockItem, [key: Internal.CoralBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.PipeDuctBlock]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.CassetteDeckBlock]: Internal.BlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.PortableStorageInterfaceBlock]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.CasingBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.PieBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.Counter]: Internal.ItemBlock, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.FlagBlock]: Internal.FlagItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: earth.terrarium.adastra.common.blocks.SlidingDoorBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.GarageDoor]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.CopycatStepBlock]: Internal.BlockItem, [key: Internal.BlazeRodBlock]: Internal.Item, [key: Internal.Block]: Internal.BlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.ArmBlock]: Internal.ArmItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.ModBlocks$1]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.FlagBlock]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.BeetrootBlock]: Internal.ItemNameBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockChemicalTank, [key: Internal.BeltTunnelBlock]: Internal.BeltTunnelItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.ClockBlock]: Internal.BlockItem, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.SmartChuteBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CryingObsidianBlock]: Internal.BlockItem, [key: Internal.ModBlocks$7]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BaseCoralPlantBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Rail_Bridge]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.ModStandingSignBlock]: Internal.SignItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SporeBlossomBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.MechanicalBearingBlock]: Internal.BlockItem, [key: Internal.HarvesterBlock]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlidingDoorBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockInductionCell, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.PowderSnowCauldronBlock]: Internal.Items$1, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.SconceBlock]: Internal.StandingAndWallBlockItem, [key: Internal.CoralPlantBlock]: Internal.BlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockQuantumEntangloporter, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.FissionControllerBlock]: Internal.BlockItem, [key: Internal.RainGutter]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CeilingBannerBlock]: Internal.BannerItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockPersonalBarrel]: Internal.ItemBlockPersonalStorage<any>, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BaseCoralPlantBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BaseCoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.CoralBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: earth.terrarium.adastra.common.blocks.pipes.PipeBlock]: Internal.BlockItem, [key: Internal.BlockThermodynamicConductor]: Internal.ItemBlockThermodynamicConductor, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockFrame]: Internal.BlockItemDescriptable, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.LadderBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ModBlocks$17]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.SawBlock]: Internal.BlockItem, [key: Internal.BaseCoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.SmallIndustrialLampBlock]: Internal.BlockItem, [key: Internal.EncasedCogwheelBlock]: Internal.BlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.EnergyGeneratorBlock]: Internal.AEBaseBlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.FlagBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.BlockFactoryMachine<any, any>]: Internal.ItemBlockMachine, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.FlintBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ReactorBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.SharestoneBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.MotorBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.ConduitBlock]: Internal.BlockItem, [key: Internal.ClipboardBlock]: Internal.ClipboardBlockItem, [key: earth.terrarium.adastra.common.blocks.GlobeBlock]: Internal.RenderedBlockItem, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.PhantomNodeBlock]: Internal.AEBaseBlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.BlockFactoryMachine<any, any>]: Internal.ItemBlockMachine, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.BuddingCertusQuartzBlock]: Internal.AEBaseBlockItem, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.BlockBin]: Internal.ItemBlockBin, [key: Internal.BlackstoneBlastFurnaceBlock]: Internal.BlockItem, [key: Internal.TaskScreenBlock]: Internal.ScreenBlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.Block]: Internal.BlockItem, [key: Internal.MillstoneBlock]: Internal.BlockItem, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.ModBlocks$16]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.ReactorRodBlock]: Internal.BlockItem, [key: Internal.SmallIndustrialLampBlock]: Internal.BlockItem, [key: Internal.ImplementedMagnetBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.BuddingCertusQuartzBlock]: Internal.AEBaseBlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.ComposterBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.SharestoneBlock]: Internal.BlockItem, [key: Internal.GutterTall]: Internal.BlockItem, [key: Internal.DecoratedPotBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.WallSignBlock]: Internal.SignItem, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.Bridge_Support]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.MachineBlock]: Internal.TooltipBlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.Bridge_Block_Rope]: Internal.FuelBlockItemWithInfo, [key: Internal.SculkCatalystBlock]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.BlockUniversalCable]: Internal.ItemBlockUniversalCable, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BigDripleafBlock]: Internal.Items$1, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.RedstoneTorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.PlayerWallHeadBlock]: Internal.PlayerHeadItem, [key: Internal.CubeGeneratorBlock]: Internal.AEBaseBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Iron_Bridge]: Internal.BlockItemWithInfo, [key: Internal.BoomboxBlock]: Internal.BoomboxItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TorchflowerCropBlock]: Internal.ItemNameBlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.QuartzGlassBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BeehiveBlock]: Internal.BlockItem, [key: Internal.MolecularAssemblerBlock]: Internal.AEBaseBlockItem, [key: Internal.SmallIndustrialLampBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.TorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.Desk]: Internal.ItemBlock, [key: mekanism.common.block.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.TallFurniture]: Internal.ItemBlock, [key: Internal.MushroomBlock]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.RainGutter]: Internal.BlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.PeculiarBellBlock]: Internal.BlockItem, [key: Internal.CertusQuartzClusterBlock]: Internal.AEBaseBlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.ItemVaultBlock]: Internal.ItemVaultItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.GlassBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.SteepRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.Bamboo_Bridge]: Internal.FuelBlockItemWithInfo, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.MotorExtensionBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.SconceWallBlock]: Internal.StandingAndWallBlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.GearboxBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.SkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: mekanism.common.block.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.CertusQuartzClusterBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.MachineBlock]: Internal.TooltipBlockItem, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.StructureVoidBlock]: Internal.BlockItem, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Bridge_Support]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.IndustrialLampBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.HayBlock]: Internal.BlockItem, [key: Internal.EnergizerBlock]: Internal.EnergizerBlockItem, [key: Internal.DetectorBlock]: Internal.TooltipBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.HugeMushroomBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.ChainGearshiftBlock]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.NetherrackBlock]: Internal.BlockItem, [key: Internal.AnvilBlock]: Internal.BlockItem, [key: Internal.GaugeBlock]: Internal.BlockItem, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.SconceLeverBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.SlidingDoorBlock]: Internal.BlockItem, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.RainGutter]: Internal.BlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.ChunkLoaderBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.LightBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Bridge_Support]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: earth.terrarium.adastra.common.blocks.pipes.PipeBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.GravityNormalizerBlock]: Internal.TooltipRenderedBlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StemBlock]: Internal.ItemNameBlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.GrindstoneBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.RoseQuartzLampBlock]: Internal.BlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.SmartFluidPipeBlock]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.SnowyDirtBlock]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.StoveBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.PowderSnowBlock]: Internal.SolidBucketItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlackstoneStoveBlock]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.TrappedChestBlock]: Internal.BlockItem, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.GutterTall]: Internal.BlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.ClutchBlock]: Internal.BlockItem, [key: Internal.NetherSproutsBlock]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.BrushableBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FlagBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.GobletBlock]: Internal.BlockItem, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.FlagBlock]: Internal.FlagItem, [key: Internal.GutterTall]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.ModBlocks$20]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.RedStoneOreBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BlockScaffold]: Internal.BlockItemDescriptable, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.PoweredRailBlock]: Internal.BlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.RedStoneOreBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SharestoneBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.CeilingBannerBlock]: Internal.BannerItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CampfireBlock]: Internal.BlockItem, [key: Internal.ModBlocks$5]: Internal.BlockItem, [key: Internal.CoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BookPileHorizontalBlock]: Internal.BookItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.DoormatBlock]: Internal.WoodBasedBlockItem, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ModernChair]: Internal.ItemBlock, [key: mekanism.common.block.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ReactorGlassBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.RedstoneLinkBlock]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.AmethystClusterBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.AwningBlock]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.FlagBlock]: Internal.FlagItem, [key: Internal.HugeMushroomBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.CreativeEnergyCellBlock]: Internal.AEBaseBlockItem, [key: Internal.Counter]: Internal.ItemBlock, [key: Internal.LampBlock]: Internal.ChemicalBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DepotBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.Bridge_Block]: Internal.BlockItemWithInfo, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BaseCoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.MushroomBlock]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.AwningBlock]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FluidValveBlock]: Internal.BlockItem, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.Bridge_Support]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.AwningBlock]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.WaterlilyBlock]: Internal.PlaceOnWaterBlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.BlockFluidTank]: Internal.ItemBlockFluidTank, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockPipeFilter]: Internal.BlockItemDescriptable, [key: Internal.HugeMushroomBlock]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.MushroomColonyBlock]: Internal.MushroomColonyItem, [key: Internal.BasinBlock]: Internal.BlockItem, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.IndustrialLampBlock]: Internal.BlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.TaskScreenBlock]: Internal.ScreenBlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.SkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.PoweredLatchBlock]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.Lower]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.TripWireBlock]: Internal.ItemNameBlockItem, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.PloughBlock]: Internal.BlockItem, [key: Internal.JapaneseDoors]: Internal.FuelItemBlock, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ContraptionControlsBlock]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockPressurizedTube]: Internal.ItemBlockPressurizedTube, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.RoofTopNew]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.RopeBlock]: vectorwing.farmersdelight.common.item.RopeItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.BookCabinet]: Internal.ItemBlock, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.StripedChair]: Internal.ItemBlock, [key: Internal.SharestoneBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.Log_Bridge]: Internal.BlockItemWithInfo, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.SnifferEggBlock]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.BlockMechanicalPipe]: Internal.ItemBlockMechanicalPipe, [key: Internal.SugarCaneBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.FaucetBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.BlockLogisticalWire]: Internal.BlockItemWire, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.BlockOre]: Internal.BlockItemDescriptable, [key: Internal.Log_Bridge]: Internal.FuelBlockItemWithInfo, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.ClassicChair]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.PaintSplotchesBlock]: Internal.AEBaseBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.Chair]: Internal.ItemBlock, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.BookCabinetHinge]: Internal.ItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.ModernChair]: Internal.ItemBlock, [key: Internal.StorageCounter]: Internal.ItemBlock, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.BaseRoof]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlockItem, [key: Internal.SmallIndustrialLampBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.CupboardCounter]: Internal.ItemBlock, [key: Internal.NetherBrickSmokerBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.RoofGlass]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.RoofGlass]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.TrainTrapdoorBlock]: Internal.BlockItem, [key: Internal.CraftingMonitorBlock]: Internal.CraftingBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockStructuralGlass<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.SmokerBlock]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.BaseRoof]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ConnectedGlassBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockChemicalTank, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.StableDoor]: Internal.FuelItemBlock, [key: Internal.SculkSensorBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.RespawnAnchorBlock]: Internal.BlockItem, [key: Internal.HugeMushroomBlock]: Internal.BlockItem, [key: Internal.ToggleLatchBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockLogisticalManager]: Internal.BlockItemDescriptable, [key: Internal.Block]: Internal.BlockItem, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: appeng.block.storage.ChestBlock]: Internal.AEBaseBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.CactusBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.BookDrawer]: Internal.ItemBlock, [key: Internal.HandCrankBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.Steep]: Internal.BlockItem, [key: Internal.AzaleaBlock]: Internal.BlockItem, [key: Internal.GutterTall]: Internal.BlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.SmallIndustrialLampBlock]: Internal.BlockItem, [key: Internal.SignalBlock]: Internal.TrackTargetingBlockItem, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.WitherSkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.ModBlocks$3]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Bridge_Stairs]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.AssemblyOperatorBlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.ModBlocks$11]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.RoofTopNew]: Internal.BlockItem, [key: Internal.BlockMachine]: Internal.BlockItemDescriptable, [key: Internal.BaseCoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: com.mcwfurnitures.kikoz.objects.Table]: Internal.ItemBlock, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.ChemicalBlock]: Internal.ChemicalBlockItem, [key: Internal.Block]: Internal.BlockItemDescriptable, [key: Internal.LoomBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.FlagBlock]: Internal.BlockItem, [key: Internal.InfestedBlock]: Internal.BlockItem, [key: Internal.AwningBlock]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.PotBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.SnowLayerBlock]: Internal.BlockItem, [key: Internal.BlockEnergyCube]: Internal.ItemBlockEnergyCube, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.Bridge_Stairs]: com.mcwbridges.kikoz.util.FuelItemBlock, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.SteepRoof]: Internal.BlockItem, [key: Internal.TallFurnitureHinge]: Internal.ItemBlock, [key: Internal.Steep]: com.mcwroofs.kikoz.util.FuelItemBlock, [key: Internal.DoorBlock]: Internal.FuelItemBlock, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FlagBlock]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Lower]: Internal.BlockItem, [key: Internal.BlockWire]: Internal.BlockItemWire, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Desk]: Internal.ItemBlock, [key: Internal.WideFurniture]: Internal.ItemBlock, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.TableHitbox]: Internal.ItemBlock, [key: Internal.AnalogLeverBlock]: Internal.BlockItem};
        static readonly EAT_DURATION: 32;
        static readonly MAX_STACK_SIZE: 64;
        static readonly MAX_BAR_WIDTH: 13;
    }
    type Item_ = Item | Special.Item;
}
