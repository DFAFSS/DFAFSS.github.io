/// <reference path="./internal_*.d.ts" />
declare namespace org.apache.logging.log4j.core.config {
    class Node {
        constructor()
        constructor(parent: org.apache.logging.log4j.core.config.Node_, name: string, type: Internal.PluginType_<any>)
        constructor(node: org.apache.logging.log4j.core.config.Node_)
        isInstanceOf(clazz: typeof any): boolean;
        hasChildren(): boolean;
        getValue(): string;
        setParent(parent: org.apache.logging.log4j.core.config.Node_): void;
        getChildren(): Internal.List<org.apache.logging.log4j.core.config.Node>;
        getObject<T>(clazz: T): T;
        isRoot(): boolean;
        setValue(value: string): void;
        getName(): string;
        setObject(obj: any): void;
        getObject<T>(): T;
        getParent(): this;
        getType(): Internal.PluginType<any>;
        getAttributes(): Internal.Map<string, string>;
        get value(): string
        set parent(parent: org.apache.logging.log4j.core.config.Node_)
        get children(): Internal.List<org.apache.logging.log4j.core.config.Node>
        get root(): boolean
        set value(value: string)
        get name(): string
        set object(obj: any)
        get object(): T
        get parent(): org.apache.logging.log4j.core.config.Node
        get type(): Internal.PluginType<any>
        get attributes(): Internal.Map<string, string>
        static readonly CATEGORY: "Core";
    }
    type Node_ = Node;
}
declare namespace Internal {
    class ForgeMod$2 extends Internal.FluidType {
    }
    type ForgeMod$2_ = ForgeMod$2;
    class BlockOrientation extends Internal.Enum<Internal.BlockOrientation> {
        getRelativeSides(arg0: Internal.Set_<Internal.Direction>): Internal.Set<Internal.RelativeSide>;
        setOn(arg0: Internal.Level_, arg1: BlockPos_): void;
        rotateClockwiseAround(arg0: Internal.Direction_): this;
        setOn(arg0: Internal.BlockEntity_): void;
        rotateClockwiseAround(arg0: Internal.Direction$Axis_, arg1: Internal.Direction$AxisDirection_): this;
        static valueOf(arg0: string): Internal.BlockOrientation;
        isRedundant(): boolean;
        static get(arg0: Internal.BlockEntity_): Internal.BlockOrientation;
        getSide(arg0: Internal.RelativeSide_): Internal.Direction;
        static get(arg0: Internal.Direction_, arg1: number): Internal.BlockOrientation;
        static get(arg0: Internal.IOrientationStrategy_, arg1: Internal.BlockState_): Internal.BlockOrientation;
        static values(): Internal.BlockOrientation[];
        getRelativeSide(arg0: Internal.Direction_): Internal.RelativeSide;
        static get(arg0: Internal.Direction_, arg1: Internal.Direction_): Internal.BlockOrientation;
        getAngleX(): number;
        getAngleY(): number;
        getAngleZ(): number;
        static get(arg0: Internal.BlockState_): Internal.BlockOrientation;
        getQuaternion(): Quaternionf;
        rotate(arg0: Internal.Direction_): Internal.Direction;
        static get(arg0: Internal.Direction_): Internal.BlockOrientation;
        resultingRotate(arg0: Internal.Direction_): Internal.Direction;
        getSpin(): number;
        getSides(arg0: Internal.Set_<Internal.RelativeSide>): Internal.Set<Internal.Direction>;
        getTransformation(): Internal.Transformation;
        set on(arg0: Internal.BlockEntity_)
        get redundant(): boolean
        get angleX(): number
        get angleY(): number
        get angleZ(): number
        get quaternion(): Quaternionf
        get spin(): number
        get transformation(): Internal.Transformation
        static readonly EAST_NORTH: Internal.BlockOrientation;
        static readonly DOWN_SOUTH: Internal.BlockOrientation;
        static readonly NORTH_EAST: Internal.BlockOrientation;
        static readonly WEST_UP: Internal.BlockOrientation;
        static readonly WEST_DOWN: Internal.BlockOrientation;
        static readonly SOUTH_EAST: Internal.BlockOrientation;
        static readonly UP_WEST: Internal.BlockOrientation;
        static readonly DOWN_WEST: Internal.BlockOrientation;
        static readonly SOUTH_UP: Internal.BlockOrientation;
        static readonly NORTH_DOWN: Internal.BlockOrientation;
        static readonly WEST_SOUTH: Internal.BlockOrientation;
        static readonly WEST_NORTH: Internal.BlockOrientation;
        static readonly DOWN_NORTH: Internal.BlockOrientation;
        static readonly SOUTH_WEST: Internal.BlockOrientation;
        static readonly NORTH_WEST: Internal.BlockOrientation;
        static readonly EAST_SOUTH: Internal.BlockOrientation;
        static readonly EAST_DOWN: Internal.BlockOrientation;
        static readonly UP_NORTH: Internal.BlockOrientation;
        static readonly EAST_UP: Internal.BlockOrientation;
        static readonly UP_SOUTH: Internal.BlockOrientation;
        static readonly SOUTH_DOWN: Internal.BlockOrientation;
        static readonly NORTH_UP: Internal.BlockOrientation;
        static readonly DOWN_EAST: Internal.BlockOrientation;
        static readonly UP_EAST: Internal.BlockOrientation;
    }
    type BlockOrientation_ = "up_west" | "west_south" | "down_south" | "up_east" | "down_north" | "west_down" | "west_up" | "north_west" | "south_up" | "north_up" | "south_west" | "down_east" | "south_east" | "north_east" | "east_up" | "east_down" | "north_down" | "down_west" | "west_north" | "east_south" | "south_down" | "up_south" | BlockOrientation | "up_north" | "east_north";
    class SequencedAssemblyItem extends Internal.Item {
        constructor(arg0: Internal.Item$Properties_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getProgress(arg0: Internal.ItemStack_): number;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type SequencedAssemblyItem_ = SequencedAssemblyItem;
    interface IClientFluidTypeExtensions {
        getFlowingTexture(arg0: Internal.FluidStack_): ResourceLocation;
        getTintColor(arg0: Internal.FluidStack_): number;
        getFlowingTexture(arg0: Internal.FluidState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_): ResourceLocation;
        modifyFogColor(arg0: Internal.Camera_, arg1: number, arg2: Internal.ClientLevel_, arg3: number, arg4: number, arg5: Vec3f_): Vec3f;
        modifyFogRender(arg0: Internal.Camera_, arg1: Internal.FogRenderer$FogMode_, arg2: number, arg3: number, arg4: number, arg5: number, arg6: Internal.FogShape_): void;
        getTintColor(): number;
        of(arg0: Internal.FluidState_): this;
        getStillTexture(arg0: Internal.FluidStack_): ResourceLocation;
        getOverlayTexture(arg0: Internal.FluidState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_): ResourceLocation;
        of(arg0: Internal.Fluid_): this;
        of(arg0: Internal.FluidType_): this;
        getOverlayTexture(): ResourceLocation;
        getFlowingTexture(): ResourceLocation;
        renderOverlay(arg0: Internal.Minecraft_, arg1: Internal.PoseStack_): void;
        getOverlayTexture(arg0: Internal.FluidStack_): ResourceLocation;
        getRenderOverlayTexture(arg0: Internal.Minecraft_): ResourceLocation;
        getStillTexture(arg0: Internal.FluidState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_): ResourceLocation;
        getTintColor(arg0: Internal.FluidState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_): number;
        getStillTexture(): ResourceLocation;
        get tintColor(): number
        get overlayTexture(): ResourceLocation
        get flowingTexture(): ResourceLocation
        get stillTexture(): ResourceLocation
        readonly DEFAULT: Internal.IClientFluidTypeExtensions;
    }
    type IClientFluidTypeExtensions_ = IClientFluidTypeExtensions;
    class GrindstoneMenu extends Internal.AbstractContainerMenu {
        constructor(arg0: number, arg1: Internal.Inventory_, arg2: any_)
        constructor(arg0: number, arg1: Internal.Inventory_)
        static readonly INPUT_SLOT: 0;
        static readonly MAX_NAME_LENGTH: 35;
        static readonly RESULT_SLOT: 2;
        static readonly ADDITIONAL_SLOT: 1;
    }
    type GrindstoneMenu_ = GrindstoneMenu;
    abstract class ForwardingObject {
    }
    type ForwardingObject_ = ForwardingObject;
    class BlockValve extends Internal.GenericMachineBlock {
        constructor(arg0: boolean)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type BlockValve_ = BlockValve;
    class AmountFormat extends Internal.Enum<Internal.AmountFormat> {
        static values(): Internal.AmountFormat[];
        static valueOf(arg0: string): Internal.AmountFormat;
        static readonly SLOT: Internal.AmountFormat;
        static readonly FULL: Internal.AmountFormat;
        static readonly SLOT_LARGE_FONT: Internal.AmountFormat;
    }
    type AmountFormat_ = "slot_large_font" | "full" | AmountFormat | "slot";
    class ChemicalType extends Internal.Enum<Internal.ChemicalType> implements Internal.StringRepresentable {
        static fromEnumWithMapping<E extends Internal.Enum<E> & Internal.StringRepresentable>(arg0: Internal.Supplier_<E[]>, arg1: Internal.Function_<string, string>): Internal.StringRepresentable$EnumCodec<E>;
        getSerializedName(): string;
        static fromNBT(arg0: Internal.CompoundTag_): Internal.ChemicalType;
        write(arg0: Internal.CompoundTag_): void;
        static valueOf(arg0: string): Internal.ChemicalType;
        static getTypeFor(arg0: Internal.Chemical_<any>): Internal.ChemicalType;
        static values(): Internal.ChemicalType[];
        isInstance(arg0: Internal.Chemical_<any>): boolean;
        static keys(arg0: Internal.StringRepresentable_[]): Internal.Keyable;
        static fromEnum<E extends Internal.Enum<E> & Internal.StringRepresentable>(arg0: Internal.Supplier_<E[]>): Internal.StringRepresentable$EnumCodec<E>;
        static getTypeFor(arg0: Internal.ChemicalStack_<any>): Internal.ChemicalType;
        static getTypeFor(arg0: Internal.ChemicalStackIngredient_<any, any>): Internal.ChemicalType;
        static fromString(arg0: string): Internal.ChemicalType;
        get serializedName(): string
        static readonly SLURRY: Internal.ChemicalType;
        static readonly PIGMENT: Internal.ChemicalType;
        static readonly GAS: Internal.ChemicalType;
        static readonly INFUSION: Internal.ChemicalType;
    }
    type ChemicalType_ = "pigment" | ChemicalType | "gas" | "slurry" | "infusion";
    interface PlayableResourceWithAudio extends Internal.PlayableResource {
        abstract open(): Internal.InputStream;
        abstract isPaused(): boolean;
        abstract isLoadingCompleted(): boolean;
        abstract isClosed(): boolean;
        abstract isReady(): boolean;
        waitForLoadingCompletedOrFailed(arg0: number): void;
        abstract getVolume(): number;
        abstract play(): void;
        abstract isPlaying(): boolean;
        waitForReady(arg0: number): void;
        abstract close(): void;
        abstract stop(): void;
        abstract setVolume(arg0: number): void;
        abstract pause(): void;
        abstract isLoadingFailed(): boolean;
        get paused(): boolean
        get loadingCompleted(): boolean
        get closed(): boolean
        get ready(): boolean
        get volume(): number
        get playing(): boolean
        set volume(arg0: number)
        get loadingFailed(): boolean
    }
    type PlayableResourceWithAudio_ = PlayableResourceWithAudio;
    class BlockFluidPipe extends Internal.AbstractRefreshingConnectBlock {
        constructor(arg0: Internal.SubtypeFluidPipe_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        readonly pipe: Internal.SubtypeFluidPipe;
        static readonly PIPESET: Internal.HashSet<Internal.Block>;
    }
    type BlockFluidPipe_ = BlockFluidPipe;
    class SuperRenderTypeBuffer implements Internal.MultiBufferSource {
        constructor()
        getEarlyBuffer(arg0: Internal.RenderType_): Internal.VertexConsumer;
        static immediate(arg0: Internal.BufferBuilder_): Internal.MultiBufferSource$BufferSource;
        draw(): void;
        draw(arg0: Internal.RenderType_): void;
        getBuffer(arg0: Internal.RenderType_): Internal.VertexConsumer;
        static getInstance(): Internal.SuperRenderTypeBuffer;
        static immediateWithBuffers(arg0: Internal.Map_<Internal.RenderType, Internal.BufferBuilder>, arg1: Internal.BufferBuilder_): Internal.MultiBufferSource$BufferSource;
        getLateBuffer(arg0: Internal.RenderType_): Internal.VertexConsumer;
        get instance(): Internal.SuperRenderTypeBuffer
    }
    type SuperRenderTypeBuffer_ = SuperRenderTypeBuffer;
    interface LoggerContextShutdownEnabled {
        abstract getListeners(): Internal.List<Internal.LoggerContextShutdownAware>;
        abstract addShutdownListener(listener: Internal.LoggerContextShutdownAware_): void;
        get listeners(): Internal.List<Internal.LoggerContextShutdownAware>
    }
    type LoggerContextShutdownEnabled_ = LoggerContextShutdownEnabled;
    class MinecartContraptionItem extends Internal.Item {
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        static addContraptionToMinecart(arg0: Internal.Level_, arg1: Internal.ItemStack_, arg2: Internal.AbstractMinecart_, arg3: Internal.Direction_): void;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        static chest(arg0: Internal.Item$Properties_): Internal.MinecartContraptionItem;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        static create(arg0: Internal.AbstractMinecart$Type_, arg1: Internal.OrientedContraptionEntity_): Internal.ItemStack;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        static rideable(arg0: Internal.Item$Properties_): Internal.MinecartContraptionItem;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        static furnace(arg0: Internal.Item$Properties_): Internal.MinecartContraptionItem;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        static wrenchCanBeUsedToPickUpMinecartContraptions(arg0: Internal.PlayerInteractEvent$EntityInteract_): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type MinecartContraptionItem_ = MinecartContraptionItem;
    interface RenderBuffersExt {
        abstract endLevelRendering(): void;
        abstract beginLevelRendering(): void;
    }
    type RenderBuffersExt_ = RenderBuffersExt;
    class ClickEvent$Action extends Internal.Enum<Internal.ClickEvent$Action> {
        static values(): Internal.ClickEvent$Action[];
        static getByName(arg0: string): Internal.ClickEvent$Action;
        isAllowedFromServer(): boolean;
        getName(): string;
        static valueOf(arg0: string): Internal.ClickEvent$Action;
        get allowedFromServer(): boolean
        get name(): string
        static readonly COPY_TO_CLIPBOARD: Internal.ClickEvent$Action;
        static readonly CHANGE_PAGE: Internal.ClickEvent$Action;
        static readonly OPEN_FILE: Internal.ClickEvent$Action;
        static readonly RUN_COMMAND: Internal.ClickEvent$Action;
        static readonly SUGGEST_COMMAND: Internal.ClickEvent$Action;
        static readonly OPEN_URL: Internal.ClickEvent$Action;
    }
    type ClickEvent$Action_ = "copy_to_clipboard" | "suggest_command" | "open_file" | "change_page" | ClickEvent$Action | "open_url" | "run_command";
    class BlockLogisticalManager extends Internal.GenericEntityBlockWaterloggable {
        constructor()
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        generateBoundingBoxes(arg0: number): void;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type BlockLogisticalManager_ = BlockLogisticalManager;
    class Parameter implements Internal.AnnotatedElement {
        getDeclaringInvokable(): Internal.Invokable<any, any>;
        getType(): Internal.TypeToken<any>;
        getAnnotations(): Internal.Annotation[];
        getDeclaredAnnotation<A extends Internal.Annotation>(arg0: A): A;
        getAnnotatedType(): Internal.AnnotatedType;
        getAnnotationsByType<A extends Internal.Annotation>(arg0: A): A[];
        getDeclaredAnnotations(): Internal.Annotation[];
        getAnnotation<A extends Internal.Annotation>(arg0: A): A;
        isAnnotationPresent(arg0: typeof Internal.Annotation): boolean;
        getDeclaredAnnotationsByType<A extends Internal.Annotation>(arg0: A): A[];
        get declaringInvokable(): Internal.Invokable<any, any>
        get type(): Internal.TypeToken<any>
        get annotations(): Internal.Annotation[]
        get annotatedType(): Internal.AnnotatedType
        get declaredAnnotations(): Internal.Annotation[]
    }
    type Parameter_ = Parameter;
    class LevelSummary implements Internal.Comparable<Internal.LevelSummary> {
        constructor(arg0: Internal.LevelSettings_, arg1: Internal.LevelVersion_, arg2: string, arg3: boolean, arg4: boolean, arg5: boolean, arg6: Internal.Path_)
        isDisabled(): boolean;
        getLastPlayed(): number;
        getLevelId(): string;
        getSettings(): Internal.LevelSettings;
        compareTo(arg0: Internal.LevelSummary_): number;
        getIcon(): Internal.Path;
        getLevelName(): string;
        backupStatus(): Internal.LevelSummary$BackupStatus;
        isLifecycleExperimental(): boolean;
        hasCheats(): boolean;
        compareTo(arg0: any): number;
        requiresManualConversion(): boolean;
        isLocked(): boolean;
        isExperimental(): boolean;
        isCompatible(): boolean;
        getGameMode(): Internal.GameType;
        markVersionInList(): boolean;
        getWorldVersionName(): Internal.MutableComponent;
        isHardcore(): boolean;
        askToOpenWorld(): boolean;
        getInfo(): net.minecraft.network.chat.Component;
        levelVersion(): Internal.LevelVersion;
        get disabled(): boolean
        get lastPlayed(): number
        get levelId(): string
        get settings(): Internal.LevelSettings
        get icon(): Internal.Path
        get levelName(): string
        get lifecycleExperimental(): boolean
        get locked(): boolean
        get experimental(): boolean
        get compatible(): boolean
        get gameMode(): Internal.GameType
        get worldVersionName(): Internal.MutableComponent
        get hardcore(): boolean
        get info(): net.minecraft.network.chat.Component
    }
    type LevelSummary_ = LevelSummary;
    class CopyNameFunction$NameSource extends Internal.Enum<Internal.CopyNameFunction$NameSource> {
        static valueOf(arg0: string): Internal.CopyNameFunction$NameSource;
        static values(): Internal.CopyNameFunction$NameSource[];
        static getByName(arg0: string): Internal.CopyNameFunction$NameSource;
        readonly name: string;
        static readonly BLOCK_ENTITY: Internal.CopyNameFunction$NameSource;
        readonly param: Internal.LootContextParam<any>;
        static readonly KILLER: Internal.CopyNameFunction$NameSource;
        static readonly KILLER_PLAYER: Internal.CopyNameFunction$NameSource;
        static readonly THIS: Internal.CopyNameFunction$NameSource;
    }
    type CopyNameFunction$NameSource_ = "killer" | CopyNameFunction$NameSource | "killer_player" | "this" | "block_entity";
    interface IMobContainerProvider {
        abstract getMobContainer(): Internal.MobContainer;
        getDirection(): Internal.Direction;
        get mobContainer(): Internal.MobContainer
        get direction(): Internal.Direction
        (): Internal.MobContainer_;
    }
    type IMobContainerProvider_ = IMobContainerProvider;
    interface ContainerSynchronizer {
        abstract sendDataChange(arg0: Internal.AbstractContainerMenu_, arg1: number, arg2: number): void;
        abstract sendSlotChange(arg0: Internal.AbstractContainerMenu_, arg1: number, arg2: Internal.ItemStack_): void;
        abstract sendInitialData(arg0: Internal.AbstractContainerMenu_, arg1: Internal.NonNullList_<Internal.ItemStack>, arg2: Internal.ItemStack_, arg3: number[]): void;
        abstract sendCarriedChange(arg0: Internal.AbstractContainerMenu_, arg1: Internal.ItemStack_): void;
    }
    type ContainerSynchronizer_ = ContainerSynchronizer;
    class MobEffectCategory extends Internal.Enum<Internal.MobEffectCategory> {
        static values(): Internal.MobEffectCategory[];
        getTooltipFormatting(): Internal.ChatFormatting;
        static valueOf(arg0: string): Internal.MobEffectCategory;
        get tooltipFormatting(): Internal.ChatFormatting
        static readonly HARMFUL: Internal.MobEffectCategory;
        static readonly BENEFICIAL: Internal.MobEffectCategory;
        static readonly NEUTRAL: Internal.MobEffectCategory;
    }
    type MobEffectCategory_ = "neutral" | MobEffectCategory | "beneficial" | "harmful";
    interface DirectBeltInputBehaviour$OccupiedPredicate {
        abstract test(arg0: Internal.Direction_): boolean;
        (arg0: Internal.Direction): boolean;
    }
    type DirectBeltInputBehaviour$OccupiedPredicate_ = DirectBeltInputBehaviour$OccupiedPredicate;
    abstract class ConfigValue <T> implements Internal.Comparable<Internal.ConfigValue<T>> {
        constructor()
        setOrder(o: number): this;
        addInfo(list: Internal.TooltipList_): void;
        getStringForGUI(v: T): net.minecraft.network.chat.Component;
        getColor(v: T): Internal.Color4I;
        abstract onClicked(arg0: Internal.Widget_, arg1: Internal.MouseButton_, arg2: Internal.ConfigCallback_): void;
        getTooltip(): string;
        getDefaultValue(): T;
        compareTo(arg0: any): number;
        compareTo(o: Internal.ConfigValue_<T>): number;
        getIcon(): Internal.Icon;
        setIcon(i: Internal.Icon_): this;
        getName(): string;
        getGroup(): Internal.ConfigGroup;
        getStringForGUI(): net.minecraft.network.chat.Component;
        getColor(): Internal.Color4I;
        getPath(): string;
        applyValue(): void;
        setNameKey(key: string): this;
        getIcon(v: T): Internal.Icon;
        init(group: Internal.ConfigGroup_, id: string, value: T, setter: Internal.Consumer_<T>, defaultValue: T): this;
        setCanEdit(e: boolean): this;
        static info(key: string, value: any): net.minecraft.network.chat.Component;
        setValue(value: T): void;
        getValue(): T;
        copy(value: T): T;
        getNameKey(): string;
        isEqual(v1: T, v2: T): boolean;
        getCanEdit(): boolean;
        setCurrentValue(v: T): boolean;
        setDefaultValue(defaultValue: T): void;
        set order(o: number)
        get tooltip(): string
        get defaultValue(): T
        get icon(): Internal.Icon
        set icon(i: Internal.Icon_)
        get name(): string
        get group(): Internal.ConfigGroup
        get stringForGUI(): net.minecraft.network.chat.Component
        get color(): Internal.Color4I
        get path(): string
        set nameKey(key: string)
        set canEdit(e: boolean)
        set value(value: T)
        get value(): T
        get nameKey(): string
        get canEdit(): boolean
        set currentValue(v: T)
        set defaultValue(defaultValue: T)
        static readonly NULL_TEXT: Internal.MutableComponent;
        id: string;
    }
    type ConfigValue_<T> = ConfigValue<T>;
    class ItemMekaTool extends Internal.ItemEnergized implements Internal.IBlastingItem, Internal.IGenericRadialModeItem, Internal.IModuleContainerItem {
        constructor(properties: Internal.Item$Properties_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        addModuleDetails(stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        supportsModule(stack: Internal.ItemStack_, typeProvider: Internal.IModuleDataProvider_<any>): boolean;
        supportsSlotType(stack: Internal.ItemStack_, slotType: Internal.EquipmentSlot_): boolean;
        addModule(stack: Internal.ItemStack_, type: Internal.ModuleData_<any>): void;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        getRadialData(stack: Internal.ItemStack_): Internal.RadialData<any>;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        getScrollTextComponent(stack: Internal.ItemStack_): net.minecraft.network.chat.Component;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        hasModule(stack: Internal.ItemStack_, type: Internal.IModuleDataProvider_<any>): boolean;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        addHUDStrings(list: Internal.List_<net.minecraft.network.chat.Component>, player: Internal.Player_, stack: Internal.ItemStack_, slotType: Internal.EquipmentSlot_): void;
        getModules(stack: Internal.ItemStack_): Internal.List<mekanism.common.content.gear.Module<any>>;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        getCreativeTab(): string;
        getBlastedBlocks(world: Internal.Level_, player: Internal.Player_, stack: Internal.ItemStack_, pos: BlockPos_, state: Internal.BlockState_): Internal.Map<BlockPos, Internal.BlockState>;
        static isModeItem(player: Internal.Player_, slotType: Internal.EquipmentSlot_, allowRadial: boolean): boolean;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getMode<M extends Internal.IRadialMode>(stack: Internal.ItemStack_, radialData: Internal.RadialData_<M>): M;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        static canBlastBlock(world: Internal.Level_, pos: BlockPos_, state: Internal.BlockState_): boolean;
        getDestroyEnergy(itemStack: Internal.ItemStack_, hardness: number, silk: boolean): Internal.FloatingLong;
        static isModeItem(stack: Internal.ItemStack_, slotType: Internal.EquipmentSlot_, allowRadial: boolean): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        static isModeItem(player: Internal.Player_, slotType: Internal.EquipmentSlot_): boolean;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        removeModule(stack: Internal.ItemStack_, type: Internal.ModuleData_<any>): void;
        addDefault(): boolean;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        hasEnergyForDigAction(stack: Internal.ItemStack_): boolean;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        changeMode(player: Internal.Player_, stack: Internal.ItemStack_, shift: number, displayChange: Internal.IModeItem$DisplayChange_): void;
        isModuleEnabled(stack: Internal.ItemStack_, type: Internal.IModuleDataProvider_<any>): boolean;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        static findPositions(world: Internal.Level_, targetPos: BlockPos_, player: Internal.Player_, radius: number): Internal.Map<BlockPos, Internal.BlockState>;
        setAttackDamage(attackDamage: number): void;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        static displayModeChange(player: Internal.Player_): void;
        setArmorProtection(armorProtection: number): void;
        setMode<M extends Internal.IRadialMode>(stack: Internal.ItemStack_, player: Internal.Player_, radialData: Internal.RadialData_<M>, mode: M): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        addCurioHUDStrings(list: Internal.List_<net.minecraft.network.chat.Component>, player: Internal.Player_, stack: Internal.ItemStack_): void;
        getModule<MODULE extends Internal.ICustomModule<MODULE>>(stack: Internal.ItemStack_, typeProvider: Internal.IModuleDataProvider_<MODULE>): Internal.IModule<MODULE>;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        getHUDElements(player: Internal.Player_, stack: Internal.ItemStack_): Internal.List<Internal.IHUDElement>;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        static isModeItem(stack: Internal.ItemStack_, slotType: Internal.EquipmentSlot_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type ItemMekaTool_ = ItemMekaTool;
    class ClampedNormalFloat extends Internal.FloatProvider {
        static of(arg0: number, arg1: number, arg2: number, arg3: number): Internal.ClampedNormalFloat;
        static sample(arg0: Internal.RandomSource_, arg1: number, arg2: number, arg3: number, arg4: number): number;
        static readonly CODEC: Internal.Codec<Internal.ClampedNormalFloat>;
    }
    type ClampedNormalFloat_ = ClampedNormalFloat;
    interface Char2ObjectFunction <V> extends Internal.IntFunction<V>, it.unimi.dsi.fastutil.Function<string, V> {
        andThenReference<T>(arg0: Internal.Object2ReferenceFunction_<V, T>): Internal.Char2ReferenceFunction<T>;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: V): V;
        composeChar(arg0: Internal.Char2CharFunction_): this;
        containsKey(arg0: string): boolean;
        composeLong(arg0: Internal.Long2CharFunction_): Internal.Long2ObjectFunction<V>;
        /**
         * @deprecated
        */
        containsKey(arg0: any): boolean;
        andThen<V>(arg0: Internal.Function_<V, V>): Internal.Function<string, V>;
        remove(arg0: string): V;
        andThenShort(arg0: Internal.Object2ShortFunction_<V>): Internal.Char2ShortFunction;
        /**
         * @deprecated
        */
        get(arg0: any): V;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        /**
         * @deprecated
        */
        apply(arg0: number): V;
        /**
         * @deprecated
        */
        remove(arg0: any): V;
        andThenLong(arg0: Internal.Object2LongFunction_<V>): Internal.Char2LongFunction;
        composeFloat(arg0: Internal.Float2CharFunction_): Internal.Float2ObjectFunction<V>;
        /**
         * @deprecated
        */
        put(arg0: string, arg1: V): V;
        composeDouble(arg0: Internal.Double2CharFunction_): Internal.Double2ObjectFunction<V>;
        /**
         * @deprecated
        */
        compose<T>(arg0: Internal.Function_<T, string>): Internal.Function<T, V>;
        composeReference<T>(arg0: Internal.Reference2CharFunction_<T>): Internal.Reference2ObjectFunction<T, V>;
        composeByte(arg0: Internal.Byte2CharFunction_): Internal.Byte2ObjectFunction<V>;
        abstract get(arg0: string): V;
        composeObject<T>(arg0: Internal.Object2CharFunction_<T>): Internal.Object2ObjectFunction<T, V>;
        andThenObject<T>(arg0: Internal.Object2ObjectFunction_<V, T>): Internal.Char2ObjectFunction<T>;
        andThenFloat(arg0: Internal.Object2FloatFunction_<V>): Internal.Char2FloatFunction;
        getOrDefault(arg0: string, arg1: V): V;
        andThenByte(arg0: Internal.Object2ByteFunction_<V>): Internal.Char2ByteFunction;
        composeShort(arg0: Internal.Short2CharFunction_): Internal.Short2ObjectFunction<V>;
        size(): number;
        apply(arg0: string): V;
        andThenDouble(arg0: Internal.Object2DoubleFunction_<V>): Internal.Char2DoubleFunction;
        andThenInt(arg0: Internal.Object2IntFunction_<V>): Internal.Char2IntFunction;
        clear(): void;
        put(arg0: string, arg1: V): V;
        defaultReturnValue(): V;
        composeInt(arg0: Internal.Int2CharFunction_): Internal.Int2ObjectFunction<V>;
        identity<T>(): Internal.Function<T, T>;
        defaultReturnValue(arg0: V): void;
        andThenChar(arg0: Internal.Object2CharFunction_<V>): Internal.Char2CharFunction;
        (arg0: string): V;
    }
    type Char2ObjectFunction_<V> = Char2ObjectFunction<V>;
    class ItemVaultItem extends Internal.BlockItem {
        constructor(arg0: Internal.Block_, arg1: Internal.Item$Properties_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type ItemVaultItem_ = ItemVaultItem;
    abstract class TransitionPropagation {
        constructor()
        abstract captureValues(arg0: Internal.TransitionValues_): void;
        abstract getStartDelay(arg0: Internal.ViewGroup_, arg1: Internal.Transition_, arg2: Internal.TransitionValues_, arg3: Internal.TransitionValues_): number;
        abstract getPropagationProperties(): string[];
        get propagationProperties(): string[]
    }
    type TransitionPropagation_ = TransitionPropagation;
    interface ThreadContext$ContextStack extends Internal.Collection<string>, Internal.Serializable {
        abstract peek(): string;
        spliterator(): Internal.Spliterator<string>;
        abstract asList(): Internal.List<string>;
        forEach(arg0: Internal.Consumer_<string>): void;
        abstract getImmutableStackOrNull(): this;
        abstract isEmpty(): boolean;
        abstract pop(): string;
        abstract copy(): this;
        abstract retainAll(arg0: Internal.Collection_<any>): boolean;
        abstract containsAll(arg0: Internal.Collection_<any>): boolean;
        parallelStream(): Internal.Stream<string>;
        toArray<T>(arg0: Internal.IntFunction_<T[]>): T[];
        abstract iterator(): Internal.Iterator<string>;
        abstract contains(arg0: any): boolean;
        abstract getDepth(): number;
        abstract toArray<T>(arg0: T[]): T[];
        abstract remove(arg0: any): boolean;
        stream(): Internal.Stream<string>;
        abstract toArray(): any[];
        removeIf(arg0: Internal.Predicate_<string>): boolean;
        abstract push(message: string): void;
        abstract add(arg0: string): boolean;
        abstract size(): number;
        abstract hashCode(): number;
        abstract removeAll(arg0: Internal.Collection_<any>): boolean;
        abstract addAll(arg0: Internal.Collection_<string>): boolean;
        abstract clear(): void;
        abstract trim(depth: number): void;
        abstract equals(arg0: any): boolean;
        get immutableStackOrNull(): Internal.ThreadContext$ContextStack
        get empty(): boolean
        get depth(): number
    }
    type ThreadContext$ContextStack_ = ThreadContext$ContextStack;
    abstract class GuiFlow {
        constructor()
        abstract preferredWidth(arg0: Internal.List_<Internal.GuiChildControl>, arg1: number, arg2: number): number;
        abstract preferredHeight(arg0: Internal.List_<Internal.GuiChildControl>, arg1: number, arg2: number, arg3: number): number;
        abstract flowX(arg0: Internal.List_<Internal.GuiChildControl>, arg1: number, arg2: Internal.Align_, arg3: number, arg4: number, arg5: boolean): void;
        abstract minWidth(arg0: Internal.List_<Internal.GuiChildControl>, arg1: number, arg2: number): number;
        abstract flowY(arg0: Internal.List_<Internal.GuiChildControl>, arg1: number, arg2: Internal.VAlign_, arg3: number, arg4: number, arg5: number, arg6: boolean): void;
        static areChildrenExpandableY(arg0: Internal.List_<Internal.GuiChildControl>): boolean;
        abstract minHeight(arg0: Internal.List_<Internal.GuiChildControl>, arg1: number, arg2: number, arg3: number): number;
        static areChildrenExpandableX(arg0: Internal.List_<Internal.GuiChildControl>): boolean;
        static readonly FIT_X: Internal.GuiFlowFitX;
        static readonly STACK_X: Internal.GuiStackX;
        static readonly STACK_Y: Internal.GuiStackY;
    }
    type GuiFlow_ = GuiFlow;
    class PaintScreenEventJS extends Internal.PaintEventJS implements Internal.UnitVariables {
        constructor(m: Internal.Minecraft_, s: Internal.Screen_, graphics: Internal.GuiGraphics_, painter: Internal.Painter_, mx: number, my: number, d: number)
        constructor(m: Internal.Minecraft_, graphics: Internal.GuiGraphics_, painter: Internal.Painter_, d: number)
        alignY(y: number, h: number, alignY: Internal.AlignMode_): number;
        getVariables(): Internal.VariableSet;
        rotateDeg(angle: number): void;
        alignX(x: number, w: number, alignX: Internal.AlignMode_): number;
        rectangle(x: number, y: number, z: number, w: number, h: number, color: number): void;
        scale(scale: number): void;
        text(text: net.minecraft.network.chat.Component_, x: number, y: number, color: number, shadow: boolean): void;
        getEntity(): Internal.Entity;
        rawText(text: Internal.FormattedCharSequence_, x: number, y: number, color: number, shadow: boolean): void;
        translate(x: number, y: number): void;
        rotateRad(angle: number): void;
        scale(x: number, y: number): void;
        rectangle(x: number, y: number, z: number, w: number, h: number, color: number, u0: number, v0: number, u1: number, v1: number): void;
        get variables(): Internal.VariableSet
        get entity(): Internal.Entity
        readonly width: number;
        readonly mouseY: number;
        readonly inventory: boolean;
        readonly height: number;
        readonly painter: Internal.Painter;
        readonly mouseX: number;
    }
    type PaintScreenEventJS_ = PaintScreenEventJS;
    interface IPlatformFluidHelper <T> {
        abstract bucketVolume(): number;
        abstract getFluidIngredientType(): Internal.IIngredientTypeWithSubtypes<Internal.Fluid, T>;
        abstract create(arg0: Internal.Fluid_, arg1: number): T;
        abstract create(arg0: Internal.Fluid_, arg1: number, arg2: Internal.CompoundTag_): T;
        get fluidIngredientType(): Internal.IIngredientTypeWithSubtypes<Internal.Fluid, T>
    }
    type IPlatformFluidHelper_<T> = IPlatformFluidHelper<T>;
    interface ReputationEventType {
        register(arg0: string): this;
        readonly VILLAGER_KILLED: Internal.ReputationEventType;
        readonly VILLAGER_HURT: Internal.ReputationEventType;
        readonly TRADE: Internal.ReputationEventType;
        readonly GOLEM_KILLED: Internal.ReputationEventType;
        readonly ZOMBIE_VILLAGER_CURED: Internal.ReputationEventType;
    }
    type ReputationEventType_ = ReputationEventType;
    class LightningRodBlock extends Internal.RodBlock implements Internal.SimpleWaterloggedBlock {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onLightningStrike(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_): void;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static readonly RANGE: 128;
        static readonly WATERLOGGED: Internal.BooleanProperty;
        static readonly POWERED: Internal.BooleanProperty;
    }
    type LightningRodBlock_ = LightningRodBlock;
    abstract class LinearActuatorBlockEntity extends Internal.KineticBlockEntity implements Internal.IControlContraption, Internal.IDisplayAssemblyExceptions {
        constructor(arg0: Internal.BlockEntityType_<any>, arg1: BlockPos_, arg2: Internal.BlockState_)
        addExceptionToTooltip(arg0: Internal.List_<net.minecraft.network.chat.Component>): boolean;
        isValid(): boolean;
        getMotionVector(): Vec3d;
        deserializeNBT(arg0: Internal.Tag_): void;
        containedFluidTooltip(arg0: Internal.List_<net.minecraft.network.chat.Component>, arg1: boolean, arg2: Internal.LazyOptional_<Internal.IFluidHandler>): boolean;
        getMovementSpeed(): number;
        getCapability<T>(arg0: Internal.Capability_<T>): Internal.LazyOptional<T>;
        onLengthBroken(): void;
        tdv$isDynamicLightEnabled(): boolean;
        isAttachedTo(arg0: Internal.AbstractContraptionEntity_): boolean;
        attach(arg0: Internal.ControlledContraptionEntity_): void;
        deserializeNBT(arg0: Internal.CompoundTag_): void;
        abstract disassemble(): void;
        onStall(): void;
        getInterpolatedOffset(arg0: number): number;
        getModelData(): Internal.ModelData;
        onLoad(): void;
        serializeNBT(): Internal.Tag;
        getLastAssemblyException(): Internal.AssemblyException;
        tdv$setDynamicLightEnabled(arg0: boolean): void;
        getBlockPosition(): BlockPos;
        hasCustomOutlineRendering(arg0: Internal.Player_): boolean;
        get valid(): boolean
        get motionVector(): Vec3d
        get movementSpeed(): number
        get modelData(): Internal.ModelData
        get lastAssemblyException(): Internal.AssemblyException
        get blockPosition(): BlockPos
        needsContraption: boolean;
        movedContraption: Internal.AbstractContraptionEntity;
        running: boolean;
        assembleNextTick: boolean;
        offset: number;
    }
    type LinearActuatorBlockEntity_ = LinearActuatorBlockEntity;
    class FireworkRocketItem extends Internal.Item {
        constructor(arg0: Internal.Item$Properties_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        static setDuration(arg0: Internal.ItemStack_, arg1: number): void;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        static readonly TAG_EXPLOSION_COLORS: "Colors";
        static readonly TAG_EXPLOSION_TYPE: "Type";
        static readonly TAG_EXPLOSION_FADECOLORS: "FadeColors";
        static readonly TAG_FLIGHT: "Flight";
        static readonly TAG_EXPLOSION_FLICKER: "Flicker";
        static readonly ROCKET_PLACEMENT_OFFSET: 0.15;
        static readonly TAG_EXPLOSIONS: "Explosions";
        static readonly TAG_FIREWORKS: "Fireworks";
        static readonly TAG_EXPLOSION_TRAIL: "Trail";
        static readonly CRAFTABLE_DURATIONS: number[];
        static readonly TAG_EXPLOSION: "Explosion";
    }
    type FireworkRocketItem_ = FireworkRocketItem;
    interface IntUnaryOperator {
        compose(arg0: Internal.IntUnaryOperator_): this;
        identity(): this;
        abstract applyAsInt(arg0: number): number;
        andThen(arg0: Internal.IntUnaryOperator_): this;
        (arg0: number): number;
    }
    type IntUnaryOperator_ = IntUnaryOperator;
    interface ItemColorsExtended {
        abstract sodium$getColorProvider(arg0: Internal.ItemStack_): Internal.ItemColor;
        (arg0: Internal.ItemStack): Internal.ItemColor_;
    }
    type ItemColorsExtended_ = ItemColorsExtended;
    class RecipeSchemaType {
        constructor(namespace: Internal.RecipeNamespace_, id: ResourceLocation_, schema: Internal.RecipeSchema_)
        getSerializer(): Internal.RecipeSerializer<any>;
        get serializer(): Internal.RecipeSerializer<any>
        readonly schema: Internal.RecipeSchema;
        parent: Internal.RecipeSchemaType;
        readonly namespace: Internal.RecipeNamespace;
        readonly id: ResourceLocation;
    }
    type RecipeSchemaType_ = RecipeSchemaType;
    interface AccessorKeyMapping {
        getAllKeyMappings(): Internal.Map<string, Internal.KeyMapping>;
        get allKeyMappings(): Internal.Map<string, Internal.KeyMapping>
    }
    type AccessorKeyMapping_ = AccessorKeyMapping;
    interface NonNullSupplier <T> {
        abstract get(): T;
        (): T;
    }
    type NonNullSupplier_<T> = NonNullSupplier<T>;
    abstract class AbstractSimpleShaftBlock extends Internal.AbstractShaftBlock implements Internal.IWrenchableWithBracket {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getBlockEntity(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.KineticBlockEntity;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        tryRemoveBracket(arg0: Internal.UseOnContext_): boolean;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        withBlockEntityDo(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Consumer_<Internal.KineticBlockEntity>): void;
        fluidState(arg0: Internal.BlockState_): Internal.FluidState;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        playRemoveSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        getMinimumRequiredSpeedLevel(): Internal.IRotate$SpeedLevel;
        getTicker<S extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<S>): Internal.BlockEntityTicker<S>;
        playRotateSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        getBlockEntityOptional(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.Optional<Internal.KineticBlockEntity>;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        newBlockEntity(arg0: BlockPos_, arg1: Internal.BlockState_): Internal.BlockEntity;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        static onRemove(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.BlockState_): void;
        updateWater(arg0: Internal.LevelAccessor_, arg1: Internal.BlockState_, arg2: BlockPos_): void;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockEntityType(): Internal.BlockEntityType<Internal.KineticBlockEntity>;
        hideStressImpact(): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        static withWater(arg0: Internal.LevelAccessor_, arg1: Internal.BlockState_, arg2: BlockPos_): Internal.BlockState;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        onBlockEntityUse(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Function_<Internal.KineticBlockEntity, Internal.InteractionResult>): Internal.InteractionResult;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        onSneakWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        withWater(arg0: Internal.BlockState_, arg1: Internal.BlockPlaceContext_): Internal.BlockState;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        updateAfterWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.BlockState;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getRotatedBlockState(arg0: Internal.BlockState_, arg1: Internal.Direction_): Internal.BlockState;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        showCapacityWithAnnotation(): boolean;
        removeBracket(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: boolean): Internal.Optional<Internal.ItemStack>;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get minimumRequiredSpeedLevel(): Internal.IRotate$SpeedLevel
        get blockEntityType(): Internal.BlockEntityType<Internal.KineticBlockEntity>
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type AbstractSimpleShaftBlock_ = AbstractSimpleShaftBlock;
    class AsyncLoggerConfig extends Internal.LoggerConfig {
        /**
         * @deprecated
        */
        static createLogger(additivity: string, levelName: string, loggerName: string, includeLocation: string, refs: Internal.AppenderRef_[], properties: org.apache.logging.log4j.core.config.Property_[], config: org.apache.logging.log4j.core.config.Configuration_, filter: Internal.Filter_): Internal.LoggerConfig;
        createRingBufferAdmin(contextName: string): Internal.RingBufferAdmin;
        static newAsyncBuilder<B extends Internal.AsyncLoggerConfig$Builder<B>>(): B;
    }
    type AsyncLoggerConfig_ = AsyncLoggerConfig;
    interface IMenuItem {
        abstract getMenuHost(arg0: Internal.Player_, arg1: number, arg2: Internal.ItemStack_, arg3: BlockPos_): Internal.ItemMenuHost;
        (arg0: Internal.Player, arg1: number, arg2: Internal.ItemStack, arg3: BlockPos): Internal.ItemMenuHost_;
    }
    type IMenuItem_ = IMenuItem;
    interface Config$Entry extends Internal.UnmodifiableConfig$Entry {
        getChar(): string;
        getShortOrElse(arg0: number): number;
        abstract setValue<T>(arg0: any): T;
        getByte(): number;
        abstract getKey(): string;
        abstract getRawValue<T>(): T;
        getIntOrElse(arg0: number): number;
        getLongOrElse(arg0: number): number;
        getOptionalLong(): Internal.OptionalLong;
        getLong(): number;
        getByteOrElse(arg0: number): number;
        getShort(): number;
        getValue<T>(): T;
        isNull(): boolean;
        getOrElse<T>(arg0: T): T;
        getOptional<T>(): Internal.Optional<T>;
        getOptionalInt(): Internal.OptionalInt;
        getInt(): number;
        getCharOrElse(arg0: string): string;
        get "char"(): string
        set value(arg0: any)
        get "byte"(): number
        get key(): string
        get rawValue(): T
        get optionalLong(): Internal.OptionalLong
        get "long"(): number
        get "short"(): number
        get value(): T
        get "null"(): boolean
        get optional(): Internal.Optional<T>
        get optionalInt(): Internal.OptionalInt
        get "int"(): number
    }
    type Config$Entry_ = Config$Entry;
    class SignPostBlock extends Internal.FenceMimicBlock implements Internal.EntityBlock, Internal.IRotatable {
        constructor(properties: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        getTicker<T extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        getRotatedState(state: Internal.BlockState_, world: Internal.LevelAccessor_, pos: BlockPos_, rotation: Internal.Rotation_, axis: Internal.Direction_, hit: Vec3d_): Internal.Optional<Internal.BlockState>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        rotateOverAxis(state: Internal.BlockState_, world: Internal.LevelAccessor_, pos: BlockPos_, rot: Internal.Rotation_, axis: Internal.Direction_, hit: Vec3d_): Internal.Optional<Internal.Direction>;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        onRotated(newState: Internal.BlockState_, oldState: Internal.BlockState_, world: Internal.LevelAccessor_, pos: BlockPos_, rotation: Internal.Rotation_, axis: Internal.Direction_, hit: Vec3d_): void;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type SignPostBlock_ = SignPostBlock;
    class Instruction {
        constructor(arg0: Internal.SequencerInstructions_)
        constructor(arg0: Internal.SequencerInstructions_, arg1: any_, arg2: number)
        constructor(arg0: Internal.SequencerInstructions_, arg1: number)
        static deserializeAll(arg0: Internal.ListTag_): Internal.Vector<Internal.Instruction>;
        static createDefault(): Internal.Vector<Internal.Instruction>;
        static serializeAll(arg0: Internal.Vector_<Internal.Instruction>): Internal.ListTag;
    }
    type Instruction_ = Instruction;
    interface SearchRegistry$TreeBuilderSupplier <T> extends Internal.Function<Internal.List<T>, Internal.RefreshableSearchTree<T>> {
        compose<V>(arg0: Internal.Function_<V, Internal.List<T>>): Internal.Function<V, Internal.RefreshableSearchTree<T>>;
        andThen<V>(arg0: Internal.Function_<Internal.RefreshableSearchTree<T>, V>): Internal.Function<Internal.List<T>, V>;
        identity<T>(): Internal.Function<T, T>;
        abstract apply(arg0: Internal.List_<T>): Internal.RefreshableSearchTree<T>;
        (arg0: Internal.List<T>): Internal.RefreshableSearchTree_<T>;
    }
    type SearchRegistry$TreeBuilderSupplier_<T> = SearchRegistry$TreeBuilderSupplier<T>;
    interface Reference2ByteFunction <K> extends Internal.ToIntFunction<K>, it.unimi.dsi.fastutil.Function<K, number> {
        andThenFloat(arg0: Internal.Byte2FloatFunction_): Internal.Reference2FloatFunction<K>;
        getOrDefault(arg0: any, arg1: number): number;
        /**
         * @deprecated
        */
        andThen<T>(arg0: Internal.Function_<number, T>): Internal.Function<K, T>;
        andThenDouble(arg0: Internal.Byte2DoubleFunction_): Internal.Reference2DoubleFunction<K>;
        put(arg0: K, arg1: number): number;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: any): any;
        andThenInt(arg0: Internal.Byte2IntFunction_): Internal.Reference2IntFunction<K>;
        /**
         * @deprecated
        */
        put(arg0: K, arg1: number): number;
        andThenShort(arg0: Internal.Byte2ShortFunction_): Internal.Reference2ShortFunction<K>;
        composeDouble(arg0: Internal.Double2ReferenceFunction_<K>): Internal.Double2ByteFunction;
        composeFloat(arg0: Internal.Float2ReferenceFunction_<K>): Internal.Float2ByteFunction;
        compose<V>(arg0: Internal.Function_<V, K>): Internal.Function<V, number>;
        containsKey(arg0: any): boolean;
        defaultReturnValue(arg0: number): void;
        andThenChar(arg0: Internal.Byte2CharFunction_): Internal.Reference2CharFunction<K>;
        removeByte(arg0: any): number;
        andThenObject<T>(arg0: Internal.Byte2ObjectFunction_<T>): Internal.Reference2ObjectFunction<K, T>;
        apply(arg0: K): number;
        /**
         * @deprecated
        */
        remove(arg0: any): number;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        andThenByte(arg0: Internal.Byte2ByteFunction_): this;
        defaultReturnValue(): number;
        andThenReference<T>(arg0: Internal.Byte2ReferenceFunction_<T>): Internal.Reference2ReferenceFunction<K, T>;
        composeChar(arg0: Internal.Char2ReferenceFunction_<K>): Internal.Char2ByteFunction;
        composeObject<T>(arg0: Internal.Object2ReferenceFunction_<T, K>): Internal.Object2ByteFunction<T>;
        andThenLong(arg0: Internal.Byte2LongFunction_): Internal.Reference2LongFunction<K>;
        composeLong(arg0: Internal.Long2ReferenceFunction_<K>): Internal.Long2ByteFunction;
        applyAsInt(arg0: K): number;
        composeInt(arg0: Internal.Int2ReferenceFunction_<K>): Internal.Int2ByteFunction;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: number): number;
        abstract getByte(arg0: any): number;
        size(): number;
        composeReference<T>(arg0: Internal.Reference2ReferenceFunction_<T, K>): Internal.Reference2ByteFunction<T>;
        composeByte(arg0: Internal.Byte2ReferenceFunction_<K>): Internal.Byte2ByteFunction;
        composeShort(arg0: Internal.Short2ReferenceFunction_<K>): Internal.Short2ByteFunction;
        clear(): void;
        /**
         * @deprecated
        */
        get(arg0: any): any;
        identity<T>(): Internal.Function<T, T>;
        (arg0: any): number;
    }
    type Reference2ByteFunction_<K> = Reference2ByteFunction<K>;
    class FlagItem extends Internal.WoodBasedBlockItem implements Internal.IColored, Internal.ICustomItemRendererProvider {
        constructor(block: Internal.Block_, properties: Internal.Item$Properties_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getColor(): Internal.DyeColor;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        registerFabricRenderer(): void;
        getDamage(arg0: Internal.ItemStack_): number;
        supportsBlankColor(): boolean;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getRendererFactory(): Internal.Supplier<Internal.ItemStackRenderer>;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        changeItemColor(color: Internal.DyeColor_): Internal.Item;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get color(): Internal.DyeColor
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get rendererFactory(): Internal.Supplier<Internal.ItemStackRenderer>
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type FlagItem_ = FlagItem;
    class Target extends Internal.Node {
        constructor(arg0: number, arg1: number, arg2: number)
        constructor(arg0: Internal.Node_)
        updateBest(arg0: number, arg1: Internal.Node_): void;
        isReached(): boolean;
        getBestNode(): Internal.Node;
        static createFromStream(arg0: Internal.FriendlyByteBuf_): Internal.Target;
        setReached(): void;
        get reached(): boolean
        get bestNode(): Internal.Node
    }
    type Target_ = Target;
    class ElectrolysisRecipe$ElectrolysisRecipeOutput extends Internal.Record {
        constructor(left: Internal.GasStack_, right: Internal.GasStack_)
        right(): Internal.GasStack;
        left(): Internal.GasStack;
    }
    type ElectrolysisRecipe$ElectrolysisRecipeOutput_ = ElectrolysisRecipe$ElectrolysisRecipeOutput;
    class MinimapRadarList implements Internal.Comparable<Internal.MinimapRadarList> {
        compareTo(arg0: Internal.MinimapRadarList_): number;
        setCategory(arg0: Internal.EntityRadarCategory_): this;
        getEntities(): Internal.List<Internal.Entity>;
        compareTo(arg0: any): number;
        getCategory(): Internal.EntityRadarCategory;
        set category(arg0: Internal.EntityRadarCategory_)
        get entities(): Internal.List<Internal.Entity>
        get category(): Internal.EntityRadarCategory
    }
    type MinimapRadarList_ = MinimapRadarList;
    class Vector3i implements Internal.Vector3ic, Internal.Cloneable, Internal.Externalizable {
        constructor(arg0: Internal.Vector2dc_, arg1: number, arg2: number)
        constructor()
        constructor(arg0: number, arg1: number, arg2: number, arg3: number)
        constructor(arg0: number, arg1: number, arg2: number)
        constructor(arg0: Internal.Vector2fc_, arg1: number, arg2: number)
        constructor(arg0: Internal.ByteBuffer_)
        constructor(arg0: number)
        constructor(arg0: number[])
        constructor(arg0: number, arg1: Internal.ByteBuffer_)
        constructor(arg0: number, arg1: number, arg2: number, arg3: number)
        constructor(arg0: number, arg1: Internal.IntBuffer_)
        constructor(arg0: Internal.Vector3fc_, arg1: number)
        constructor(arg0: Internal.IntBuffer_)
        constructor(arg0: Internal.Vector3dc_, arg1: number)
        constructor(arg0: Internal.Vector2ic_, arg1: number)
        constructor(arg0: Internal.Vector3ic_)
        z(): number;
        x(): number;
        get(arg0: number, arg1: Internal.ByteBuffer_): Internal.ByteBuffer;
        sub(arg0: number, arg1: number, arg2: number): this;
        add(arg0: Internal.Vector3ic_, arg1: Internal.Vector3i_): this;
        add(arg0: number, arg1: number, arg2: number, arg3: Internal.Vector3i_): this;
        set(arg0: Internal.Vector2ic_, arg1: number): this;
        set(arg0: Internal.Vector3ic_): this;
        add(arg0: Internal.Vector3ic_): this;
        get(arg0: number, arg1: Internal.IntBuffer_): Internal.IntBuffer;
        max(arg0: Internal.Vector3ic_): this;
        mul(arg0: number, arg1: number, arg2: number): this;
        absolute(arg0: Internal.Vector3i_): this;
        distance(arg0: number, arg1: number, arg2: number): number;
        setComponent(arg0: number, arg1: number): this;
        div(arg0: number, arg1: Internal.Vector3i_): this;
        distanceSquared(arg0: number, arg1: number, arg2: number): number;
        set(arg0: number): this;
        readExternal(arg0: Internal.ObjectInput_): void;
        gridDistance(arg0: Internal.Vector3ic_): number;
        set(arg0: Internal.Vector3fc_, arg1: number): this;
        sub(arg0: Internal.Vector3ic_, arg1: Internal.Vector3i_): this;
        div(arg0: number): this;
        absolute(): this;
        toString(arg0: Internal.NumberFormat_): string;
        getToAddress(arg0: number): Internal.Vector3ic;
        static distanceSquared(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): number;
        lengthSquared(): number;
        distance(arg0: Internal.Vector3ic_): number;
        length(): number;
        get(arg0: Internal.ByteBuffer_): Internal.ByteBuffer;
        mul(arg0: number): this;
        min(arg0: Internal.Vector3ic_): this;
        gridDistance(arg0: number, arg1: number, arg2: number): number;
        minComponent(): number;
        clone(): any;
        set(arg0: Internal.Vector3dc_): this;
        writeExternal(arg0: Internal.ObjectOutput_): void;
        maxComponent(): number;
        y(): number;
        min(arg0: Internal.Vector3ic_, arg1: Internal.Vector3i_): this;
        div(arg0: number, arg1: Internal.Vector3i_): this;
        set(arg0: Internal.ByteBuffer_): this;
        mul(arg0: Internal.Vector3ic_): this;
        mul(arg0: number, arg1: Internal.Vector3i_): this;
        sub(arg0: number, arg1: number, arg2: number, arg3: Internal.Vector3i_): this;
        negate(arg0: Internal.Vector3i_): this;
        negate(): this;
        add(arg0: number, arg1: number, arg2: number): this;
        get(arg0: Internal.IntBuffer_): Internal.IntBuffer;
        set(arg0: number, arg1: number, arg2: number): this;
        set(arg0: number, arg1: Internal.ByteBuffer_): this;
        zero(): this;
        mul(arg0: Internal.Vector3ic_, arg1: Internal.Vector3i_): this;
        distanceSquared(arg0: Internal.Vector3ic_): number;
        set(arg0: Internal.Vector3dc_, arg1: number): this;
        static length(arg0: number, arg1: number, arg2: number): number;
        sub(arg0: Internal.Vector3ic_): this;
        max(arg0: Internal.Vector3ic_, arg1: Internal.Vector3i_): this;
        set(arg0: number, arg1: Internal.IntBuffer_): this;
        set(arg0: number[]): this;
        set(arg0: Internal.IntBuffer_): this;
        equals(arg0: number, arg1: number, arg2: number): boolean;
        static distance(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): number;
        get(arg0: number): number;
        div(arg0: number): this;
        setFromAddress(arg0: number): this;
        mul(arg0: number, arg1: number, arg2: number, arg3: Internal.Vector3i_): this;
        static lengthSquared(arg0: number, arg1: number, arg2: number): number;
        set fromAddress(arg0: number)
        z: number;
        x: number;
        y: number;
    }
    type Vector3i_ = Vector3i;
    class NetherForestVegetationFeature extends Internal.Feature<Internal.NetherForestVegetationConfig> {
        constructor(arg0: Internal.Codec_<Internal.NetherForestVegetationConfig>)
    }
    type NetherForestVegetationFeature_ = NetherForestVegetationFeature;
    interface Short2IntFunction extends it.unimi.dsi.fastutil.Function<number, number>, Internal.IntUnaryOperator {
        abstract get(arg0: number): number;
        put(arg0: number, arg1: number): number;
        andThenChar(arg0: Internal.Int2CharFunction_): Internal.Short2CharFunction;
        composeShort(arg0: Internal.Short2ShortFunction_): this;
        apply(arg0: number): number;
        defaultReturnValue(): number;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: any): any;
        andThenFloat(arg0: Internal.Int2FloatFunction_): Internal.Short2FloatFunction;
        composeChar(arg0: Internal.Char2ShortFunction_): Internal.Char2IntFunction;
        composeReference<T>(arg0: Internal.Reference2ShortFunction_<T>): Internal.Reference2IntFunction<T>;
        andThen(arg0: Internal.IntUnaryOperator_): Internal.IntUnaryOperator;
        andThenDouble(arg0: Internal.Int2DoubleFunction_): Internal.Short2DoubleFunction;
        /**
         * @deprecated
        */
        containsKey(arg0: any): boolean;
        andThenInt(arg0: Internal.Int2IntFunction_): this;
        compose(arg0: Internal.IntUnaryOperator_): Internal.IntUnaryOperator;
        /**
         * @deprecated
        */
        applyAsInt(arg0: number): number;
        identity(): Internal.IntUnaryOperator;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        /**
         * @deprecated
        */
        remove(arg0: any): number;
        composeByte(arg0: Internal.Byte2ShortFunction_): Internal.Byte2IntFunction;
        remove(arg0: number): number;
        andThenObject<T>(arg0: Internal.Int2ObjectFunction_<T>): Internal.Short2ObjectFunction<T>;
        andThenShort(arg0: Internal.Int2ShortFunction_): Internal.Short2ShortFunction;
        containsKey(arg0: number): boolean;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: number): number;
        getOrDefault(arg0: number, arg1: number): number;
        /**
         * @deprecated
        */
        put(arg0: number, arg1: number): number;
        andThenReference<T>(arg0: Internal.Int2ReferenceFunction_<T>): Internal.Short2ReferenceFunction<T>;
        andThenByte(arg0: Internal.Int2ByteFunction_): Internal.Short2ByteFunction;
        /**
         * @deprecated
        */
        andThen<T>(arg0: Internal.Function_<number, T>): Internal.Function<number, T>;
        size(): number;
        defaultReturnValue(arg0: number): void;
        composeInt(arg0: Internal.Int2ShortFunction_): Internal.Int2IntFunction;
        clear(): void;
        andThenLong(arg0: Internal.Int2LongFunction_): Internal.Short2LongFunction;
        /**
         * @deprecated
        */
        compose<T>(arg0: Internal.Function_<T, number>): Internal.Function<T, number>;
        composeObject<T>(arg0: Internal.Object2ShortFunction_<T>): Internal.Object2IntFunction<T>;
        composeLong(arg0: Internal.Long2ShortFunction_): Internal.Long2IntFunction;
        composeFloat(arg0: Internal.Float2ShortFunction_): Internal.Float2IntFunction;
        /**
         * @deprecated
        */
        get(arg0: any): any;
        composeDouble(arg0: Internal.Double2ShortFunction_): Internal.Double2IntFunction;
        (arg0: number): number;
    }
    type Short2IntFunction_ = Short2IntFunction;
    class Vector3d implements Internal.Cloneable, Internal.Externalizable, Internal.Vector3dc {
        constructor()
        constructor(arg0: Internal.DoubleBuffer_)
        constructor(arg0: number[])
        constructor(arg0: number, arg1: Internal.DoubleBuffer_)
        constructor(arg0: Internal.ByteBuffer_)
        constructor(arg0: number, arg1: Internal.ByteBuffer_)
        constructor(arg0: Internal.Vector3fc_)
        constructor(arg0: Internal.Vector3dc_)
        constructor(arg0: Internal.Vector2dc_, arg1: number)
        constructor(arg0: number, arg1: number, arg2: number)
        constructor(arg0: Internal.Vector2fc_, arg1: number)
        constructor(arg0: Internal.Vector2ic_, arg1: number)
        constructor(arg0: number)
        constructor(arg0: number[])
        constructor(arg0: Internal.Vector3ic_)
        reflect(arg0: number, arg1: number, arg2: number): this;
        set(arg0: number, arg1: number, arg2: number): this;
        get(arg0: Internal.FloatBuffer_): Internal.FloatBuffer;
        add(arg0: Internal.Vector3dc_, arg1: Internal.Vector3d_): this;
        mulTransposeDirection(arg0: Internal.Matrix4fc_, arg1: Internal.Vector3d_): this;
        round(arg0: Internal.Vector3d_): this;
        rotateX(arg0: number, arg1: Internal.Vector3d_): this;
        fma(arg0: Internal.Vector3dc_, arg1: Internal.Vector3fc_, arg2: Internal.Vector3d_): this;
        mul(arg0: Internal.Vector3dc_): this;
        round(): this;
        x(): number;
        mul(arg0: number, arg1: number, arg2: number, arg3: Internal.Vector3d_): this;
        add(arg0: number, arg1: number, arg2: number, arg3: Internal.Vector3d_): this;
        mulPositionW(arg0: Internal.Matrix4fc_): number;
        static distance(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): number;
        div(arg0: number, arg1: number, arg2: number, arg3: Internal.Vector3d_): this;
        mulDirection(arg0: Internal.Matrix4fc_, arg1: Internal.Vector3d_): this;
        mulAdd(arg0: Internal.Vector3dc_, arg1: Internal.Vector3dc_, arg2: Internal.Vector3d_): this;
        smoothStep(arg0: Internal.Vector3dc_, arg1: number, arg2: Internal.Vector3d_): this;
        mulTranspose(arg0: Internal.Matrix3dc_, arg1: Internal.Vector3d_): this;
        half(arg0: number, arg1: number, arg2: number, arg3: Internal.Vector3d_): this;
        orthogonalize(arg0: Internal.Vector3dc_): this;
        fma(arg0: Internal.Vector3dc_, arg1: Internal.Vector3dc_): this;
        negate(): this;
        add(arg0: Internal.Vector3fc_): this;
        angleSigned(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): number;
        ceil(): this;
        half(arg0: Internal.Vector3dc_): this;
        setComponent(arg0: number, arg1: number): this;
        rotateY(arg0: number, arg1: Internal.Vector3d_): this;
        getToAddress(arg0: number): Internal.Vector3dc;
        mul(arg0: Internal.Matrix3fc_, arg1: Internal.Vector3d_): this;
        set(arg0: number[]): this;
        get(arg0: number): number;
        y(): number;
        sub(arg0: Internal.Vector3fc_, arg1: Internal.Vector3d_): this;
        hermite(arg0: Internal.Vector3dc_, arg1: Internal.Vector3dc_, arg2: Internal.Vector3dc_, arg3: number, arg4: Internal.Vector3d_): this;
        negate(arg0: Internal.Vector3d_): this;
        fma(arg0: number, arg1: Internal.Vector3dc_, arg2: Internal.Vector3d_): this;
        set(arg0: Internal.DoubleBuffer_): this;
        mul(arg0: Internal.Matrix3x2fc_): this;
        mulPositionW(arg0: Internal.Matrix4dc_, arg1: Internal.Vector3d_): number;
        equals(arg0: number, arg1: number, arg2: number): boolean;
        max(arg0: Internal.Vector3dc_): this;
        mul(arg0: Internal.Matrix3fc_): this;
        orthogonalize(arg0: Internal.Vector3dc_, arg1: Internal.Vector3d_): this;
        ceil(arg0: Internal.Vector3d_): this;
        dot(arg0: Internal.Vector3dc_): number;
        distanceSquared(arg0: Internal.Vector3dc_): number;
        cross(arg0: Internal.Vector3dc_, arg1: Internal.Vector3d_): this;
        z(): number;
        isFinite(): boolean;
        mul(arg0: Internal.Vector3fc_): this;
        mul(arg0: Internal.Matrix3dc_, arg1: Internal.Vector3d_): this;
        mulDirection(arg0: Internal.Matrix4dc_): this;
        mul(arg0: Internal.Vector3fc_, arg1: Internal.Vector3d_): this;
        mulAdd(arg0: number, arg1: Internal.Vector3dc_, arg2: Internal.Vector3d_): this;
        half(arg0: Internal.Vector3dc_, arg1: Internal.Vector3d_): this;
        mul(arg0: Internal.Matrix3x2fc_, arg1: Internal.Vector3d_): this;
        absolute(): this;
        fma(arg0: number, arg1: Internal.Vector3dc_): this;
        mulPosition(arg0: Internal.Matrix4fc_, arg1: Internal.Vector3d_): this;
        mulPositionW(arg0: Internal.Matrix4dc_): number;
        distanceSquared(arg0: number, arg1: number, arg2: number): number;
        normalize(): this;
        angleCos(arg0: Internal.Vector3dc_): number;
        mulDirection(arg0: Internal.Matrix4x3fc_, arg1: Internal.Vector3d_): this;
        angle(arg0: Internal.Vector3dc_): number;
        get(arg0: Internal.ByteBuffer_): Internal.ByteBuffer;
        sub(arg0: Internal.Vector3fc_): this;
        minComponent(): number;
        set(arg0: Internal.Vector2dc_, arg1: number): this;
        set(arg0: Internal.Vector3fc_): this;
        add(arg0: Internal.Vector3dc_): this;
        normalize(arg0: Internal.Vector3d_): this;
        set(arg0: Internal.ByteBuffer_): this;
        div(arg0: Internal.Vector3dc_, arg1: Internal.Vector3d_): this;
        cross(arg0: Internal.Vector3dc_): this;
        getf(arg0: Internal.ByteBuffer_): Internal.ByteBuffer;
        min(arg0: Internal.Vector3dc_, arg1: Internal.Vector3d_): this;
        mulTransposePosition(arg0: Internal.Matrix4fc_, arg1: Internal.Vector3d_): this;
        mulPosition(arg0: Internal.Matrix4x3fc_, arg1: Internal.Vector3d_): this;
        mul(arg0: Internal.Matrix3dc_, arg1: Vec3f_): Vec3f;
        mulTranspose(arg0: Internal.Matrix3dc_): this;
        mulProject(arg0: Internal.Matrix4dc_, arg1: Internal.Vector3d_): this;
        mulProject(arg0: Internal.Matrix4dc_): this;
        mulProject(arg0: Internal.Matrix4dc_, arg1: number, arg2: Internal.Vector3d_): this;
        rotationTo(arg0: Internal.Vector3dc_, arg1: Internal.Quaterniond_): Internal.Quaterniond;
        set(arg0: number, arg1: Internal.DoubleBuffer_): this;
        mulAdd(arg0: Internal.Vector3dc_, arg1: Internal.Vector3dc_): this;
        mul(arg0: Internal.Matrix3x2dc_): this;
        mulDirection(arg0: Internal.Matrix4dc_, arg1: Internal.Vector3d_): this;
        sub(arg0: number, arg1: number, arg2: number): this;
        mul(arg0: number, arg1: Internal.Vector3d_): this;
        lerp(arg0: Internal.Vector3dc_, arg1: number, arg2: Internal.Vector3d_): this;
        setFromAddress(arg0: number): this;
        set(arg0: Internal.Vector2ic_, arg1: number): this;
        min(arg0: Internal.Vector3dc_): this;
        sub(arg0: number, arg1: number, arg2: number, arg3: Internal.Vector3d_): this;
        mulTransposeDirection(arg0: Internal.Matrix4fc_): this;
        rotate(arg0: Internal.Quaterniondc_): this;
        get(arg0: number, arg1: Internal.ByteBuffer_): Internal.ByteBuffer;
        cross(arg0: number, arg1: number, arg2: number): this;
        half(arg0: number, arg1: number, arg2: number): this;
        distance(arg0: number, arg1: number, arg2: number): number;
        sub(arg0: Internal.Vector3dc_, arg1: Internal.Vector3d_): this;
        mulDirection(arg0: Internal.Matrix4fc_): this;
        mulPosition(arg0: Internal.Matrix4dc_): this;
        mul(arg0: number, arg1: number, arg2: number): this;
        normalize(arg0: number, arg1: Internal.Vector3d_): this;
        fma(arg0: number, arg1: Internal.Vector3fc_): this;
        toString(arg0: Internal.NumberFormat_): string;
        fma(arg0: Internal.Vector3fc_, arg1: Internal.Vector3fc_, arg2: Internal.Vector3d_): this;
        orthogonalizeUnit(arg0: Internal.Vector3dc_, arg1: Internal.Vector3d_): this;
        normalize(arg0: number): this;
        sub(arg0: Internal.Vector3dc_): this;
        mulPositionW(arg0: Internal.Matrix4fc_, arg1: Internal.Vector3d_): number;
        clone(): any;
        dot(arg0: number, arg1: number, arg2: number): number;
        absolute(arg0: Internal.Vector3d_): this;
        set(arg0: Internal.Vector3dc_): this;
        writeExternal(arg0: Internal.ObjectOutput_): void;
        maxComponent(): number;
        getf(arg0: number, arg1: Internal.ByteBuffer_): Internal.ByteBuffer;
        orthogonalizeUnit(arg0: Internal.Vector3dc_): this;
        div(arg0: number): this;
        set(arg0: number[]): this;
        rotateZ(arg0: number): this;
        add(arg0: Internal.Vector3fc_, arg1: Internal.Vector3d_): this;
        static lengthSquared(arg0: number, arg1: number, arg2: number): number;
        floor(arg0: Internal.Vector3d_): this;
        mul(arg0: number): this;
        mulTranspose(arg0: Internal.Matrix3fc_): this;
        set(arg0: number, arg1: Internal.ByteBuffer_): this;
        floor(): this;
        zero(): this;
        mulProject(arg0: Internal.Matrix4fc_): this;
        mulTransposePosition(arg0: Internal.Matrix4dc_): this;
        reflect(arg0: number, arg1: number, arg2: number, arg3: Internal.Vector3d_): this;
        mulTransposeDirection(arg0: Internal.Matrix4dc_, arg1: Internal.Vector3d_): this;
        lengthSquared(): number;
        mulAdd(arg0: Internal.Vector3fc_, arg1: Internal.Vector3dc_, arg2: Internal.Vector3d_): this;
        mulDirection(arg0: Internal.Matrix4x3dc_): this;
        mulPosition(arg0: Internal.Matrix4dc_, arg1: Internal.Vector3d_): this;
        mulDirection(arg0: Internal.Matrix4x3dc_, arg1: Internal.Vector3d_): this;
        rotateAxis(arg0: number, arg1: number, arg2: number, arg3: number, arg4: Internal.Vector3d_): this;
        mulPosition(arg0: Internal.Matrix4x3fc_): this;
        reflect(arg0: Internal.Vector3dc_, arg1: Internal.Vector3d_): this;
        max(arg0: Internal.Vector3dc_, arg1: Internal.Vector3d_): this;
        mulTranspose(arg0: Internal.Matrix3fc_, arg1: Internal.Vector3d_): this;
        reflect(arg0: Internal.Vector3dc_): this;
        set(arg0: Internal.Vector3ic_): this;
        div(arg0: Internal.Vector3fc_): this;
        rotateAxis(arg0: number, arg1: number, arg2: number, arg3: number): this;
        fma(arg0: Internal.Vector3fc_, arg1: Internal.Vector3fc_): this;
        mulTransposeDirection(arg0: Internal.Matrix4dc_): this;
        div(arg0: Internal.Vector3fc_, arg1: Internal.Vector3d_): this;
        lerp(arg0: Internal.Vector3dc_, arg1: number): this;
        set(arg0: number): this;
        angleSigned(arg0: Internal.Vector3dc_, arg1: Internal.Vector3dc_): number;
        rotateY(arg0: number): this;
        equals(arg0: Internal.Vector3dc_, arg1: number): boolean;
        add(arg0: number, arg1: number, arg2: number): this;
        mulTransposePosition(arg0: Internal.Matrix4dc_, arg1: Internal.Vector3d_): this;
        rotateZ(arg0: number, arg1: Internal.Vector3d_): this;
        static length(arg0: number, arg1: number, arg2: number): number;
        static distanceSquared(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): number;
        mulProject(arg0: Internal.Matrix4fc_, arg1: Internal.Vector3d_): this;
        get(arg0: Internal.DoubleBuffer_): Internal.DoubleBuffer;
        set(arg0: Internal.Vector2fc_, arg1: number): this;
        readExternal(arg0: Internal.ObjectInput_): void;
        mulPosition(arg0: Internal.Matrix4fc_): this;
        get(arg0: Internal.Vector3d_): this;
        get(arg0: number, arg1: Internal.FloatBuffer_): Internal.FloatBuffer;
        length(): number;
        fma(arg0: number, arg1: Internal.Vector3fc_, arg2: Internal.Vector3d_): this;
        rotate(arg0: Internal.Quaterniondc_, arg1: Internal.Vector3d_): this;
        mul(arg0: Internal.Vector3dc_, arg1: Internal.Vector3d_): this;
        div(arg0: number, arg1: number, arg2: number): this;
        rotateX(arg0: number): this;
        fma(arg0: Internal.Vector3dc_, arg1: Internal.Vector3dc_, arg2: Internal.Vector3d_): this;
        mulTransposePosition(arg0: Internal.Matrix4fc_): this;
        get(arg0: number, arg1: Internal.Vector3i_): Internal.Vector3i;
        get(arg0: number, arg1: Internal.DoubleBuffer_): Internal.DoubleBuffer;
        mul(arg0: Internal.Matrix3x2dc_, arg1: Internal.Vector3d_): this;
        mulAdd(arg0: number, arg1: Internal.Vector3dc_): this;
        div(arg0: Internal.Vector3d_): this;
        mulPosition(arg0: Internal.Matrix4x3dc_, arg1: Internal.Vector3d_): this;
        cross(arg0: number, arg1: number, arg2: number, arg3: Internal.Vector3d_): this;
        mulDirection(arg0: Internal.Matrix4x3fc_): this;
        mulPosition(arg0: Internal.Matrix4x3dc_): this;
        get(arg0: Vec3f_): Vec3f;
        distance(arg0: Internal.Vector3dc_): number;
        div(arg0: number, arg1: Internal.Vector3d_): this;
        rotationTo(arg0: number, arg1: number, arg2: number, arg3: Internal.Quaterniond_): Internal.Quaterniond;
        mul(arg0: Internal.Matrix3dc_): this;
        get finite(): boolean
        set fromAddress(arg0: number)
        z: number;
        x: number;
        y: number;
    }
    type Vector3d_ = Vector3d;
    class GuiControlClickEvent extends Internal.GuiControlEvent<any> {
        constructor(arg0: Internal.GuiControl_, arg1: number, arg2: boolean)
        readonly button: number;
        readonly doubleClick: boolean;
    }
    type GuiControlClickEvent_ = GuiControlClickEvent;
    abstract class Panel extends Internal.Widget {
        constructor(panel: Internal.Panel_)
        getScrollStep(): number;
        setScrollStep(s: number): void;
        drawBackground(graphics: Internal.GuiGraphics_, theme: Internal.Theme_, x: number, y: number, w: number, h: number): void;
        closeContextMenu(): void;
        closeGui(openPrevScreen: boolean): void;
        scrollPanel(scroll: number): boolean;
        run(): void;
        add(widget: Internal.Widget_): void;
        setOffset(flag: boolean): void;
        getWidgets(): Internal.List<Internal.Widget>;
        movePanelScroll(dx: number, dy: number): boolean;
        closeGui(): void;
        setOnlyRenderWidgetsInside(value: boolean): void;
        isDefaultScrollVertical(): boolean;
        openGui(): void;
        abstract alignWidgets(): void;
        setScrollY(scroll: number): void;
        clearWidgets(): void;
        setScrollX(scroll: number): void;
        getWidget(index: number): Internal.Widget;
        abstract addWidgets(): void;
        setOnlyInteractWithWidgetsInside(value: boolean): void;
        getContentHeight(): number;
        isOffset(): boolean;
        getScrollY(): number;
        drawOffsetBackground(graphics: Internal.GuiGraphics_, theme: Internal.Theme_, x: number, y: number, w: number, h: number): void;
        isMouseOverAnyWidget(): boolean;
        openGuiLater(): void;
        getScrollX(): number;
        getOnlyInteractWithWidgetsInside(): boolean;
        getOnlyRenderWidgetsInside(): boolean;
        addAll(list: Internal.Iterable_<Internal.Widget>): void;
        drawWidget(graphics: Internal.GuiGraphics_, theme: Internal.Theme_, widget: Internal.Widget_, x: number, y: number, w: number, h: number): void;
        refreshWidgets(): void;
        align(layout: Internal.WidgetLayout_): number;
        openAfter(runnable: Internal.Runnable_): Internal.Runnable;
        getContentWidth(): number;
        get scrollStep(): number
        set scrollStep(s: number)
        set offset(flag: boolean)
        get widgets(): Internal.List<Internal.Widget>
        set onlyRenderWidgetsInside(value: boolean)
        get defaultScrollVertical(): boolean
        set scrollY(scroll: number)
        set scrollX(scroll: number)
        set onlyInteractWithWidgetsInside(value: boolean)
        get contentHeight(): number
        get offset(): boolean
        get scrollY(): number
        get mouseOverAnyWidget(): boolean
        get scrollX(): number
        get onlyInteractWithWidgetsInside(): boolean
        get onlyRenderWidgetsInside(): boolean
        get contentWidth(): number
    }
    type Panel_ = Panel;
    /**
     * @deprecated
    */
    class OutputInt {
        constructor()
        constructor(arg0: number)
        /**
         * @deprecated
        */
        value: number;
    }
    type OutputInt_ = OutputInt;
    interface SequencedMap <K, V> extends Internal.Map<K, V> {
        putLast(arg0: K, arg1: V): V;
        computeIfAbsent(arg0: K, arg1: Internal.Function_<K, V>): V;
        lastEntry(): Internal.Map$Entry<K, V>;
        abstract containsValue(arg0: any): boolean;
        abstract reversed(): this;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V): Internal.Map<K, V>;
        putFirst(arg0: K, arg1: V): V;
        abstract get(arg0: any): V;
        sequencedValues(): Internal.SequencedCollection<V>;
        copyOf<K, V>(arg0: Internal.Map_<K, V>): Internal.Map<K, V>;
        sequencedEntrySet(): Internal.SequencedSet<Internal.Map$Entry<K, V>>;
        putIfAbsent(arg0: K, arg1: V): V;
        abstract values(): Internal.Collection<V>;
        abstract entrySet(): Internal.Set<Internal.Map$Entry<K, V>>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V): Internal.Map<K, V>;
        firstEntry(): Internal.Map$Entry<K, V>;
        pollFirstEntry(): Internal.Map$Entry<K, V>;
        sequencedKeySet(): Internal.SequencedSet<K>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V): Internal.Map<K, V>;
        ofEntries<K, V>(...arg0: Internal.Map$Entry_<K, V>[]): Internal.Map<K, V>;
        replace(arg0: K, arg1: V, arg2: V): boolean;
        of<K, V>(arg0: K, arg1: V): Internal.Map<K, V>;
        pollLastEntry(): Internal.Map$Entry<K, V>;
        replace(arg0: K, arg1: V): V;
        of<K, V>(): Internal.Map<K, V>;
        computeIfPresent(arg0: K, arg1: Internal.BiFunction_<K, V, V>): V;
        getOrDefault(arg0: any, arg1: V): V;
        abstract isEmpty(): boolean;
        entry<K, V>(arg0: K, arg1: V): Internal.Map$Entry<K, V>;
        abstract containsKey(arg0: any): boolean;
        abstract put(arg0: K, arg1: V): V;
        abstract remove(arg0: any): V;
        merge(arg0: K, arg1: V, arg2: Internal.BiFunction_<V, V, V>): V;
        abstract keySet(): Internal.Set<K>;
        forEach(arg0: Internal.BiConsumer_<K, V>): void;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V): Internal.Map<K, V>;
        compute(arg0: K, arg1: Internal.BiFunction_<K, V, V>): V;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V): Internal.Map<K, V>;
        remove(arg0: any, arg1: any): boolean;
        abstract putAll(arg0: Internal.Map_<K, V>): void;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V): Internal.Map<K, V>;
        abstract size(): number;
        abstract hashCode(): number;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V, arg18: K, arg19: V): Internal.Map<K, V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V): Internal.Map<K, V>;
        abstract clear(): void;
        replaceAll(arg0: Internal.BiFunction_<K, V, V>): void;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V): Internal.Map<K, V>;
        abstract equals(arg0: any): boolean;
        get empty(): boolean
    }
    type SequencedMap_<K, V> = SequencedMap<K, V>;
    interface ISecurityTile extends Internal.ISecurityObject {
        getOwnerName(): string;
        getSecurityMode(): Internal.SecurityMode;
        ownerMatches(arg0: Internal.Player_): boolean;
        setOwnerUUID(owner: Internal.UUID_): void;
        abstract getSecurity(): Internal.TileComponentSecurity;
        getOwnerUUID(): Internal.UUID;
        setSecurityMode(mode: Internal.SecurityMode_): void;
        onSecurityChanged(arg0: Internal.SecurityMode_, arg1: Internal.SecurityMode_): void;
        hasSecurity(): boolean;
        get ownerName(): string
        get securityMode(): Internal.SecurityMode
        set ownerUUID(owner: Internal.UUID_)
        get security(): Internal.TileComponentSecurity
        get ownerUUID(): Internal.UUID
        set securityMode(mode: Internal.SecurityMode_)
        (): Internal.TileComponentSecurity_;
    }
    type ISecurityTile_ = ISecurityTile;
    class ClientboundSetEntityMotionPacket implements Internal.Packet<Internal.ClientGamePacketListener> {
        constructor(arg0: number, arg1: Vec3d_)
        constructor(arg0: Internal.FriendlyByteBuf_)
        constructor(arg0: Internal.Entity_)
        handle(arg0: Internal.PacketListener_): void;
        write(arg0: Internal.FriendlyByteBuf_): void;
        getXa(): number;
        getZa(): number;
        getYa(): number;
        handle(arg0: Internal.ClientGamePacketListener_): void;
        isSkippable(): boolean;
        getId(): number;
        get xa(): number
        get za(): number
        get ya(): number
        get skippable(): boolean
        get id(): number
    }
    type ClientboundSetEntityMotionPacket_ = ClientboundSetEntityMotionPacket;
    interface Short2FloatFunction extends Internal.IntToDoubleFunction, it.unimi.dsi.fastutil.Function<number, number> {
        composeInt(arg0: Internal.Int2ShortFunction_): Internal.Int2FloatFunction;
        /**
         * @deprecated
        */
        applyAsDouble(arg0: number): number;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: any): any;
        andThenShort(arg0: Internal.Float2ShortFunction_): Internal.Short2ShortFunction;
        composeLong(arg0: Internal.Long2ShortFunction_): Internal.Long2FloatFunction;
        defaultReturnValue(arg0: number): void;
        /**
         * @deprecated
        */
        compose<T>(arg0: Internal.Function_<T, number>): Internal.Function<T, number>;
        andThenInt(arg0: Internal.Float2IntFunction_): Internal.Short2IntFunction;
        composeDouble(arg0: Internal.Double2ShortFunction_): Internal.Double2FloatFunction;
        remove(arg0: number): number;
        /**
         * @deprecated
        */
        andThen<T>(arg0: Internal.Function_<number, T>): Internal.Function<number, T>;
        /**
         * @deprecated
        */
        containsKey(arg0: any): boolean;
        andThenByte(arg0: Internal.Float2ByteFunction_): Internal.Short2ByteFunction;
        composeReference<T>(arg0: Internal.Reference2ShortFunction_<T>): Internal.Reference2FloatFunction<T>;
        apply(arg0: number): number;
        composeFloat(arg0: Internal.Float2ShortFunction_): Internal.Float2FloatFunction;
        getOrDefault(arg0: number, arg1: number): number;
        andThenFloat(arg0: Internal.Float2FloatFunction_): this;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        abstract get(arg0: number): number;
        defaultReturnValue(): number;
        composeObject<T>(arg0: Internal.Object2ShortFunction_<T>): Internal.Object2FloatFunction<T>;
        /**
         * @deprecated
        */
        remove(arg0: any): number;
        /**
         * @deprecated
        */
        put(arg0: number, arg1: number): number;
        andThenDouble(arg0: Internal.Float2DoubleFunction_): Internal.Short2DoubleFunction;
        containsKey(arg0: number): boolean;
        andThenChar(arg0: Internal.Float2CharFunction_): Internal.Short2CharFunction;
        composeShort(arg0: Internal.Short2ShortFunction_): this;
        andThenObject<T>(arg0: Internal.Float2ObjectFunction_<T>): Internal.Short2ObjectFunction<T>;
        composeChar(arg0: Internal.Char2ShortFunction_): Internal.Char2FloatFunction;
        andThenLong(arg0: Internal.Float2LongFunction_): Internal.Short2LongFunction;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: number): number;
        size(): number;
        put(arg0: number, arg1: number): number;
        andThenReference<T>(arg0: Internal.Float2ReferenceFunction_<T>): Internal.Short2ReferenceFunction<T>;
        clear(): void;
        composeByte(arg0: Internal.Byte2ShortFunction_): Internal.Byte2FloatFunction;
        /**
         * @deprecated
        */
        get(arg0: any): any;
        identity<T>(): Internal.Function<T, T>;
        (arg0: number): number;
    }
    type Short2FloatFunction_ = Short2FloatFunction;
    interface Serializable {
    }
    type Serializable_ = Serializable;
    abstract class FunnelBlock extends Internal.AbstractDirectionalFunnelBlock {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        withBlockEntityDo(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Consumer_<Internal.FunnelBlockEntity>): void;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        fluidState(arg0: Internal.BlockState_): Internal.FluidState;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        getBlockEntity(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.FunnelBlockEntity;
        playRemoveSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        getTicker<S extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<S>): Internal.BlockEntityTicker<S>;
        playRotateSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        newBlockEntity(arg0: BlockPos_, arg1: Internal.BlockState_): Internal.BlockEntity;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        static onRemove(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.BlockState_): void;
        updateWater(arg0: Internal.LevelAccessor_, arg1: Internal.BlockState_, arg2: BlockPos_): void;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onBlockEntityUse(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Function_<Internal.FunnelBlockEntity, Internal.InteractionResult>): Internal.InteractionResult;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        static withWater(arg0: Internal.LevelAccessor_, arg1: Internal.BlockState_, arg2: BlockPos_): Internal.BlockState;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        onSneakWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        withWater(arg0: Internal.BlockState_, arg1: Internal.BlockPlaceContext_): Internal.BlockState;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        updateAfterWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.BlockState;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getRotatedBlockState(arg0: Internal.BlockState_, arg1: Internal.Direction_): Internal.BlockState;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        abstract getEquivalentBeltFunnel(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.BlockState;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        getBlockEntityOptional(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.Optional<Internal.FunnelBlockEntity>;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static readonly EXTRACTING: Internal.BooleanProperty;
    }
    type FunnelBlock_ = FunnelBlock;
    class Vector2i implements Internal.Vector2ic, Internal.Cloneable, Internal.Externalizable {
        constructor()
        constructor(arg0: number, arg1: number, arg2: number)
        constructor(arg0: number, arg1: number, arg2: number)
        constructor(arg0: Internal.ByteBuffer_)
        constructor(arg0: number)
        constructor(arg0: number[])
        constructor(arg0: number, arg1: Internal.ByteBuffer_)
        constructor(arg0: number, arg1: number)
        constructor(arg0: number, arg1: Internal.IntBuffer_)
        constructor(arg0: Internal.Vector2fc_, arg1: number)
        constructor(arg0: Internal.IntBuffer_)
        constructor(arg0: Internal.Vector2dc_, arg1: number)
        constructor(arg0: Internal.Vector2ic_)
        absolute(arg0: Internal.Vector2i_): this;
        mul(arg0: number): this;
        setComponent(arg0: number, arg1: number): this;
        x(): number;
        mul(arg0: number, arg1: number): this;
        get(arg0: number, arg1: Internal.ByteBuffer_): Internal.ByteBuffer;
        set(arg0: number[]): this;
        gridDistance(arg0: Internal.Vector2ic_): number;
        div(arg0: number): this;
        set(arg0: Internal.Vector2dc_, arg1: number): this;
        add(arg0: Internal.Vector2ic_): this;
        set(arg0: Internal.Vector2ic_): this;
        get(arg0: number, arg1: Internal.IntBuffer_): Internal.IntBuffer;
        max(arg0: Internal.Vector2ic_): this;
        distanceSquared(arg0: number, arg1: number): number;
        add(arg0: number, arg1: number, arg2: Internal.Vector2i_): this;
        readExternal(arg0: Internal.ObjectInput_): void;
        div(arg0: number, arg1: Internal.Vector2i_): this;
        mul(arg0: number, arg1: Internal.Vector2i_): this;
        negate(): this;
        negate(arg0: Internal.Vector2i_): this;
        gridDistance(arg0: number, arg1: number): number;
        toString(arg0: Internal.NumberFormat_): string;
        mul(arg0: number, arg1: number, arg2: Internal.Vector2i_): this;
        lengthSquared(): number;
        length(): number;
        static distance(arg0: number, arg1: number, arg2: number, arg3: number): number;
        get(arg0: Internal.ByteBuffer_): Internal.ByteBuffer;
        sub(arg0: Internal.Vector2ic_, arg1: Internal.Vector2i_): this;
        distanceSquared(arg0: Internal.Vector2ic_): number;
        min(arg0: Internal.Vector2ic_): this;
        minComponent(): number;
        clone(): any;
        set(arg0: Internal.Vector2dc_): this;
        set(arg0: number, arg1: Internal.IntBuffer_): this;
        writeExternal(arg0: Internal.ObjectOutput_): void;
        maxComponent(): number;
        div(arg0: number): this;
        y(): number;
        div(arg0: number, arg1: Internal.Vector2i_): this;
        sub(arg0: number, arg1: number, arg2: Internal.Vector2i_): this;
        mul(arg0: Internal.Vector2ic_): this;
        set(arg0: number): this;
        set(arg0: Internal.IntBuffer_): this;
        absolute(): this;
        add(arg0: Internal.Vector2ic_, arg1: Internal.Vector2i_): this;
        distance(arg0: Internal.Vector2ic_): number;
        get(arg0: Internal.IntBuffer_): Internal.IntBuffer;
        equals(arg0: number, arg1: number): boolean;
        set(arg0: number, arg1: number): this;
        add(arg0: number, arg1: number): this;
        set(arg0: Internal.Vector2fc_, arg1: number): this;
        setFromAddress(arg0: number): this;
        sub(arg0: Internal.Vector2ic_): this;
        mul(arg0: Internal.Vector2ic_, arg1: Internal.Vector2i_): this;
        static lengthSquared(arg0: number, arg1: number): number;
        static length(arg0: number, arg1: number): number;
        distance(arg0: number, arg1: number): number;
        set(arg0: Internal.ByteBuffer_): this;
        getToAddress(arg0: number): Internal.Vector2ic;
        static distanceSquared(arg0: number, arg1: number, arg2: number, arg3: number): number;
        max(arg0: Internal.Vector2ic_, arg1: Internal.Vector2i_): this;
        set(arg0: number, arg1: Internal.ByteBuffer_): this;
        get(arg0: number): number;
        min(arg0: Internal.Vector2ic_, arg1: Internal.Vector2i_): this;
        zero(): this;
        sub(arg0: number, arg1: number): this;
        set fromAddress(arg0: number)
        x: number;
        y: number;
    }
    type Vector2i_ = Vector2i;
    interface ITextureAtlasSpriteLoader {
        abstract loadContents(arg0: ResourceLocation_, arg1: Internal.Resource_, arg2: Internal.FrameSize_, arg3: Internal.NativeImage_, arg4: Internal.AnimationMetadataSection_, arg5: Internal.ForgeTextureMetadata_): Internal.SpriteContents;
        abstract makeSprite(arg0: ResourceLocation_, arg1: Internal.SpriteContents_, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number): Internal.TextureAtlasSprite;
    }
    type ITextureAtlasSpriteLoader_ = ITextureAtlasSpriteLoader;
    interface ShortIterator extends Internal.PrimitiveIterator<number, Internal.ShortConsumer> {
        forEachRemaining(arg0: Internal.ShortConsumer_): void;
        forEachRemaining(arg0: any): void;
        /**
         * @deprecated
        */
        forEachRemaining(arg0: Internal.Consumer_<number>): void;
        remove(): void;
        /**
         * @deprecated
        */
        next(): any;
        skip(arg0: number): number;
        forEachRemaining(arg0: Internal.IntConsumer_): void;
        abstract hasNext(): boolean;
        abstract nextShort(): number;
    }
    type ShortIterator_ = ShortIterator;
    class ChassisBlockEntity extends Internal.SmartBlockEntity {
        constructor(arg0: Internal.BlockEntityType_<any>, arg1: BlockPos_, arg2: Internal.BlockState_)
        addAttachedChasses(arg0: Internal.Queue_<BlockPos>, arg1: Internal.Set_<BlockPos>): boolean;
        deserializeNBT(arg0: Internal.Tag_): void;
        requestModelDataUpdate(): void;
        getRange(): number;
        getCapability<T>(arg0: Internal.Capability_<T>): Internal.LazyOptional<T>;
        tdv$isDynamicLightEnabled(): boolean;
        collectChassisGroup(): Internal.List<Internal.ChassisBlockEntity>;
        deserializeNBT(arg0: Internal.CompoundTag_): void;
        getModelData(): Internal.ModelData;
        onLoad(): void;
        serializeNBT(): Internal.Tag;
        tdv$setDynamicLightEnabled(arg0: boolean): void;
        hasCustomOutlineRendering(arg0: Internal.Player_): boolean;
        getIncludedBlockPositions(arg0: Internal.Direction_, arg1: boolean): Internal.List<BlockPos>;
        get range(): number
        get modelData(): Internal.ModelData
        currentlySelectedRange: number;
    }
    type ChassisBlockEntity_ = ChassisBlockEntity;
    class Vector2f implements Internal.Vector2fc, Internal.Cloneable, Internal.Externalizable {
        constructor()
        constructor(arg0: Internal.FloatBuffer_)
        constructor(arg0: Internal.Vector2fc_)
        constructor(arg0: number, arg1: Internal.FloatBuffer_)
        constructor(arg0: number, arg1: number)
        constructor(arg0: number[])
        constructor(arg0: number)
        constructor(arg0: Internal.ByteBuffer_)
        constructor(arg0: Internal.Vector2ic_)
        constructor(arg0: number, arg1: Internal.ByteBuffer_)
        round(): this;
        min(arg0: Internal.Vector2fc_): this;
        div(arg0: Internal.Vector2fc_): this;
        get(arg0: number, arg1: Internal.ByteBuffer_): Internal.ByteBuffer;
        get(arg0: Internal.FloatBuffer_): Internal.FloatBuffer;
        mul(arg0: Internal.Vector2fc_): this;
        set(arg0: Internal.Vector2ic_): this;
        ceil(arg0: Internal.Vector2f_): this;
        negate(): this;
        mul(arg0: number, arg1: number, arg2: Internal.Vector2f_): this;
        add(arg0: number, arg1: number): this;
        toString(arg0: Internal.NumberFormat_): string;
        perpendicular(): this;
        lengthSquared(): number;
        fma(arg0: number, arg1: Internal.Vector2fc_): this;
        div(arg0: number, arg1: number, arg2: Internal.Vector2f_): this;
        lerp(arg0: Internal.Vector2fc_, arg1: number, arg2: Internal.Vector2f_): this;
        get(arg0: number): number;
        set(arg0: number): this;
        mulPosition(arg0: Internal.Matrix3x2fc_): this;
        set(arg0: Internal.FloatBuffer_): this;
        fma(arg0: Internal.Vector2fc_, arg1: Internal.Vector2fc_, arg2: Internal.Vector2f_): this;
        sub(arg0: Internal.Vector2fc_): this;
        normalize(arg0: number, arg1: Internal.Vector2f_): this;
        clone(): any;
        set(arg0: number, arg1: number): this;
        writeExternal(arg0: Internal.ObjectOutput_): void;
        maxComponent(): number;
        set(arg0: Internal.Vector2fc_): this;
        floor(): this;
        absolute(): this;
        mul(arg0: number, arg1: Internal.Vector2f_): this;
        distance(arg0: Internal.Vector2fc_): number;
        mulTranspose(arg0: Internal.Matrix2fc_, arg1: Internal.Vector2f_): this;
        setComponent(arg0: number, arg1: number): this;
        div(arg0: number): this;
        mul(arg0: number): this;
        add(arg0: Internal.Vector2fc_, arg1: Internal.Vector2f_): this;
        div(arg0: number, arg1: number): this;
        length(): number;
        dot(arg0: Internal.Vector2fc_): number;
        max(arg0: Internal.Vector2fc_): this;
        static distanceSquared(arg0: number, arg1: number, arg2: number, arg3: number): number;
        div(arg0: number, arg1: Internal.Vector2f_): this;
        mul(arg0: Internal.Vector2fc_, arg1: Internal.Vector2f_): this;
        distanceSquared(arg0: number, arg1: number): number;
        fma(arg0: number, arg1: Internal.Vector2fc_, arg2: Internal.Vector2f_): this;
        set(arg0: number, arg1: Internal.ByteBuffer_): this;
        set(arg0: number[]): this;
        min(arg0: Internal.Vector2fc_, arg1: Internal.Vector2f_): this;
        div(arg0: Internal.Vector2fc_, arg1: Internal.Vector2f_): this;
        mul(arg0: Internal.Matrix2dc_): this;
        zero(): this;
        sub(arg0: number, arg1: number, arg2: Internal.Vector2f_): this;
        mulPosition(arg0: Internal.Matrix3x2fc_, arg1: Internal.Vector2f_): this;
        mul(arg0: Internal.Matrix2dc_, arg1: Internal.Vector2f_): this;
        negate(arg0: Internal.Vector2f_): this;
        fma(arg0: Internal.Vector2fc_, arg1: Internal.Vector2fc_): this;
        isFinite(): boolean;
        get(arg0: Internal.Vector2d_): Internal.Vector2d;
        mul(arg0: number, arg1: number): this;
        add(arg0: number, arg1: number, arg2: Internal.Vector2f_): this;
        static length(arg0: number, arg1: number): number;
        x(): number;
        set(arg0: number): this;
        ceil(): this;
        normalize(arg0: number): this;
        normalize(arg0: Internal.Vector2f_): this;
        readExternal(arg0: Internal.ObjectInput_): void;
        normalize(): this;
        set(arg0: number, arg1: number): this;
        floor(arg0: Internal.Vector2f_): this;
        sub(arg0: Internal.Vector2fc_, arg1: Internal.Vector2f_): this;
        set(arg0: number, arg1: Internal.FloatBuffer_): this;
        sub(arg0: number, arg1: number): this;
        get(arg0: number, arg1: Internal.FloatBuffer_): Internal.FloatBuffer;
        static lengthSquared(arg0: number, arg1: number): number;
        get(arg0: Internal.ByteBuffer_): Internal.ByteBuffer;
        angle(arg0: Internal.Vector2fc_): number;
        minComponent(): number;
        add(arg0: Internal.Vector2fc_): this;
        lerp(arg0: Internal.Vector2fc_, arg1: number): this;
        get(arg0: number, arg1: Internal.Vector2i_): Internal.Vector2i;
        set(arg0: Internal.Vector2dc_): this;
        equals(arg0: number, arg1: number): boolean;
        mulTranspose(arg0: Internal.Matrix2fc_): this;
        get(arg0: Internal.Vector2f_): this;
        equals(arg0: Internal.Vector2fc_, arg1: number): boolean;
        getToAddress(arg0: number): Internal.Vector2fc;
        mul(arg0: Internal.Matrix2fc_, arg1: Internal.Vector2f_): this;
        setFromAddress(arg0: number): this;
        mulDirection(arg0: Internal.Matrix3x2fc_, arg1: Internal.Vector2f_): this;
        mulDirection(arg0: Internal.Matrix3x2fc_): this;
        y(): number;
        absolute(arg0: Internal.Vector2f_): this;
        set(arg0: Internal.ByteBuffer_): this;
        max(arg0: Internal.Vector2fc_, arg1: Internal.Vector2f_): this;
        round(arg0: Internal.Vector2f_): this;
        static distance(arg0: number, arg1: number, arg2: number, arg3: number): number;
        distanceSquared(arg0: Internal.Vector2fc_): number;
        mul(arg0: Internal.Matrix2fc_): this;
        distance(arg0: number, arg1: number): number;
        get finite(): boolean
        set fromAddress(arg0: number)
        y: number;
        x: number;
    }
    type Vector2f_ = Vector2f;
    class RollerBlockEntity$RollingMode extends Internal.Enum<Internal.RollerBlockEntity$RollingMode> implements Internal.INamedIconOptions {
        getIcon(): PonderIcons;
        getTranslationKey(): string;
        static values(): Internal.RollerBlockEntity$RollingMode[];
        static valueOf(arg0: string): Internal.RollerBlockEntity$RollingMode;
        get icon(): PonderIcons
        get translationKey(): string
        static readonly TUNNEL_PAVE: Internal.RollerBlockEntity$RollingMode;
        static readonly STRAIGHT_FILL: Internal.RollerBlockEntity$RollingMode;
        static readonly WIDE_FILL: Internal.RollerBlockEntity$RollingMode;
    }
    type RollerBlockEntity$RollingMode_ = RollerBlockEntity$RollingMode | "tunnel_pave" | "straight_fill" | "wide_fill";
    class Vector2d implements Internal.Cloneable, Internal.Vector2dc, Internal.Externalizable {
        constructor()
        constructor(arg0: Internal.Vector2fc_)
        constructor(arg0: Internal.DoubleBuffer_)
        constructor(arg0: Internal.Vector2dc_)
        constructor(arg0: number[])
        constructor(arg0: number, arg1: Internal.DoubleBuffer_)
        constructor(arg0: Internal.ByteBuffer_)
        constructor(arg0: number)
        constructor(arg0: number[])
        constructor(arg0: Internal.Vector2ic_)
        constructor(arg0: number, arg1: Internal.ByteBuffer_)
        constructor(arg0: number, arg1: number)
        div(arg0: Internal.Vector2fc_): this;
        equals(arg0: Internal.Vector2dc_, arg1: number): boolean;
        round(): this;
        set(arg0: Internal.Vector2ic_): this;
        get(arg0: number, arg1: Internal.ByteBuffer_): Internal.ByteBuffer;
        add(arg0: number, arg1: number, arg2: Internal.Vector2d_): this;
        set(arg0: Internal.DoubleBuffer_): this;
        fma(arg0: Internal.Vector2dc_, arg1: Internal.Vector2dc_, arg2: Internal.Vector2d_): this;
        distance(arg0: Internal.Vector2fc_): number;
        mul(arg0: Internal.Matrix2fc_, arg1: Internal.Vector2d_): this;
        angle(arg0: Internal.Vector2dc_): number;
        lerp(arg0: Internal.Vector2dc_, arg1: number): this;
        mul(arg0: number, arg1: Internal.Vector2d_): this;
        div(arg0: number, arg1: Internal.Vector2d_): this;
        x(): number;
        negate(): this;
        dot(arg0: Internal.Vector2dc_): number;
        fma(arg0: number, arg1: Internal.Vector2dc_): this;
        toString(arg0: Internal.NumberFormat_): string;
        lerp(arg0: Internal.Vector2dc_, arg1: number, arg2: Internal.Vector2d_): this;
        setComponent(arg0: number, arg1: number): this;
        perpendicular(): this;
        round(arg0: Internal.Vector2d_): this;
        static distanceSquared(arg0: number, arg1: number, arg2: number, arg3: number): number;
        floor(): this;
        sub(arg0: Internal.Vector2fc_): this;
        sub(arg0: number, arg1: number, arg2: Internal.Vector2d_): this;
        div(arg0: Internal.Vector2fc_, arg1: Internal.Vector2d_): this;
        clone(): any;
        set(arg0: number, arg1: number): this;
        add(arg0: Internal.Vector2dc_): this;
        writeExternal(arg0: Internal.ObjectOutput_): void;
        maxComponent(): number;
        set(arg0: Internal.Vector2fc_): this;
        absolute(): this;
        negate(arg0: Internal.Vector2d_): this;
        mulTranspose(arg0: Internal.Matrix2dc_, arg1: Internal.Vector2d_): this;
        static length(arg0: number, arg1: number): number;
        normalize(): this;
        mulDirection(arg0: Internal.Matrix3x2dc_): this;
        mulTranspose(arg0: Internal.Matrix2dc_): this;
        add(arg0: Internal.Vector2dc_, arg1: Internal.Vector2d_): this;
        get(arg0: number): number;
        ceil(arg0: Internal.Vector2d_): this;
        y(): number;
        lengthSquared(): number;
        set(arg0: number[]): this;
        distanceSquared(arg0: Internal.Vector2fc_): number;
        mul(arg0: Internal.Vector2dc_, arg1: Internal.Vector2d_): this;
        floor(arg0: Internal.Vector2d_): this;
        fma(arg0: Internal.Vector2dc_, arg1: Internal.Vector2dc_): this;
        distance(arg0: number, arg1: number): number;
        set(arg0: number, arg1: Internal.ByteBuffer_): this;
        zero(): this;
        set(arg0: number[]): this;
        min(arg0: Internal.Vector2dc_, arg1: Internal.Vector2d_): this;
        mul(arg0: Internal.Matrix2dc_): this;
        div(arg0: Internal.Vector2dc_, arg1: Internal.Vector2d_): this;
        mulPosition(arg0: Internal.Matrix3x2dc_, arg1: Internal.Vector2d_): this;
        set(arg0: number, arg1: Internal.DoubleBuffer_): this;
        div(arg0: number, arg1: number): this;
        min(arg0: Internal.Vector2dc_): this;
        static distance(arg0: number, arg1: number, arg2: number, arg3: number): number;
        mulTranspose(arg0: Internal.Matrix2fc_, arg1: Internal.Vector2d_): this;
        isFinite(): boolean;
        mul(arg0: Internal.Vector2dc_): this;
        get(arg0: Internal.Vector2d_): this;
        distance(arg0: Internal.Vector2dc_): number;
        getToAddress(arg0: number): Internal.Vector2dc;
        add(arg0: Internal.Vector2fc_, arg1: Internal.Vector2d_): this;
        get(arg0: Internal.DoubleBuffer_): Internal.DoubleBuffer;
        equals(arg0: number, arg1: number): boolean;
        absolute(arg0: Internal.Vector2d_): this;
        ceil(): this;
        readExternal(arg0: Internal.ObjectInput_): void;
        set(arg0: number): this;
        div(arg0: number): this;
        sub(arg0: Internal.Vector2dc_, arg1: Internal.Vector2d_): this;
        mul(arg0: number, arg1: number): this;
        mul(arg0: number): this;
        length(): number;
        get(arg0: Internal.ByteBuffer_): Internal.ByteBuffer;
        sub(arg0: Internal.Vector2dc_): this;
        mulPosition(arg0: Internal.Matrix3x2dc_): this;
        static lengthSquared(arg0: number, arg1: number): number;
        minComponent(): number;
        set(arg0: Internal.Vector2dc_): this;
        get(arg0: number, arg1: Internal.Vector2i_): Internal.Vector2i;
        add(arg0: Internal.Vector2fc_): this;
        add(arg0: number, arg1: number): this;
        mul(arg0: Internal.Matrix2dc_, arg1: Internal.Vector2d_): this;
        div(arg0: Internal.Vector2d_): this;
        normalize(arg0: number, arg1: Internal.Vector2d_): this;
        div(arg0: number, arg1: number, arg2: Internal.Vector2d_): this;
        mulTranspose(arg0: Internal.Matrix2fc_): this;
        get(arg0: Internal.Vector2f_): Internal.Vector2f;
        normalize(arg0: number): this;
        mulDirection(arg0: Internal.Matrix3x2dc_, arg1: Internal.Vector2d_): this;
        setFromAddress(arg0: number): this;
        fma(arg0: number, arg1: Internal.Vector2dc_, arg2: Internal.Vector2d_): this;
        get(arg0: number, arg1: Internal.DoubleBuffer_): Internal.DoubleBuffer;
        mul(arg0: number, arg1: number, arg2: Internal.Vector2d_): this;
        distanceSquared(arg0: number, arg1: number): number;
        distanceSquared(arg0: Internal.Vector2dc_): number;
        normalize(arg0: Internal.Vector2d_): this;
        sub(arg0: number, arg1: number): this;
        set(arg0: Internal.ByteBuffer_): this;
        max(arg0: Internal.Vector2dc_, arg1: Internal.Vector2d_): this;
        sub(arg0: Internal.Vector2fc_, arg1: Internal.Vector2d_): this;
        max(arg0: Internal.Vector2dc_): this;
        mul(arg0: Internal.Matrix2fc_): this;
        get finite(): boolean
        set fromAddress(arg0: number)
        x: number;
        y: number;
    }
    type Vector2d_ = Vector2d;
    interface DropTargetListener extends Internal.EventListener {
        abstract dragExit(arg0: Internal.DropTargetEvent_): void;
        abstract drop(arg0: Internal.DropTargetDropEvent_): void;
        abstract dragEnter(arg0: Internal.DropTargetDragEvent_): void;
        abstract dragOver(arg0: Internal.DropTargetDragEvent_): void;
        abstract dropActionChanged(arg0: Internal.DropTargetDragEvent_): void;
    }
    type DropTargetListener_ = DropTargetListener;
    class LootParams$Builder {
        constructor(arg0: Internal.ServerLevel_)
        getOptionalParameter<T>(arg0: Internal.LootContextParam_<T>): T;
        getLevel(): Internal.ServerLevel;
        getParameter<T>(arg0: Internal.LootContextParam_<T>): T;
        withParameter<T>(arg0: Internal.LootContextParam_<T>, arg1: T): this;
        withDynamicDrop(arg0: ResourceLocation_, arg1: Internal.LootParams$DynamicDrop_): this;
        withOptionalParameter<T>(arg0: Internal.LootContextParam_<T>, arg1: T): this;
        withLuck(arg0: number): this;
        create(arg0: Internal.LootContextParamSet_): Internal.LootParams;
        get level(): Internal.ServerLevel
        luck: number;
    }
    type LootParams$Builder_ = LootParams$Builder;
    class TransferablePipe$Type extends Internal.Enum<Internal.TransferablePipe$Type> {
        static values(): Internal.TransferablePipe$Type[];
        static valueOf(name: string): Internal.TransferablePipe$Type;
        static readonly ENERGY: Internal.TransferablePipe$Type;
        static readonly FLUID: Internal.TransferablePipe$Type;
    }
    type TransferablePipe$Type_ = "fluid" | TransferablePipe$Type | "energy";
    class ConfigurationSource {
        constructor(stream: Internal.InputStream_, file: Internal.File_)
        constructor(stream: Internal.InputStream_, url: Internal.URL_)
        constructor(source: Internal.Source_, data: number[], lastModified: number)
        constructor(stream: Internal.InputStream_, url: Internal.URL_, lastModified: number)
        constructor(stream: Internal.InputStream_)
        constructor(stream: Internal.InputStream_, path: Internal.Path_)
        getInputStream(): Internal.InputStream;
        resetInputStream(): this;
        getFile(): Internal.File;
        getURL(): Internal.URL;
        getLastModified(): number;
        static fromUri(configLocation: Internal.URI_): Internal.ConfigurationSource;
        getLocation(): string;
        setData(data: number[]): void;
        static fromResource(resource: string, loader: Internal.ClassLoader_): Internal.ConfigurationSource;
        setModifiedMillis(modifiedMillis: number): void;
        /**
         * @deprecated
        */
        setSource(source: Internal.Source_): void;
        getURI(): Internal.URI;
        get inputStream(): Internal.InputStream
        get file(): Internal.File
        get URL(): Internal.URL
        get lastModified(): number
        get location(): string
        set data(data: number[])
        set modifiedMillis(modifiedMillis: number)
        /**
         * @deprecated
        */
        set source(source: Internal.Source_)
        get URI(): Internal.URI
        static readonly NULL_SOURCE: Internal.ConfigurationSource;
        static readonly COMPOSITE_SOURCE: Internal.ConfigurationSource;
    }
    type ConfigurationSource_ = ConfigurationSource;
    class JarBoatBlock extends Internal.HorizontalDirectionalBlock implements Internal.EntityBlock {
        constructor(builder: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        getTicker<T extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        newBlockEntity(pPos: BlockPos_, pState: Internal.BlockState_): Internal.BlockEntity;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type JarBoatBlock_ = JarBoatBlock;
    abstract class AbstractContainerMenu {
        findSlot(arg0: net.minecraft.world.Container_, arg1: number): Internal.OptionalInt;
        static isValidQuickcraftType(arg0: number, arg1: Internal.Player_): boolean;
        static getRedstoneSignalFromBlockEntity(arg0: Internal.BlockEntity_): number;
        canTakeItemForPickAll(arg0: Internal.ItemStack_, arg1: Internal.Slot_): boolean;
        getItems(): Internal.NonNullList<Internal.ItemStack>;
        addSlot(arg0: Internal.Slot_): Internal.Slot;
        setItem(arg0: number, arg1: number, arg2: Internal.ItemStack_): void;
        createCarriedSlotAccess(): Internal.SlotAccess;
        abstract quickMoveStack(arg0: Internal.Player_, arg1: number): Internal.ItemStack;
        static getRedstoneSignalFromContainer(arg0: net.minecraft.world.Container_): number;
        setCarried(arg0: Internal.ItemStack_): void;
        broadcastFullState(): void;
        setRemoteCarried(arg0: Internal.ItemStack_): void;
        sendAllDataToRemote(): void;
        static getQuickCraftPlaceCount(arg0: Internal.Set_<Internal.Slot>, arg1: number, arg2: Internal.ItemStack_): number;
        incrementStateId(): number;
        resumeRemoteUpdates(): void;
        synchronizeCarriedToRemote(): void;
        isValidSlotIndex(arg0: number): boolean;
        broadcastChanges(): void;
        static getQuickcraftHeader(arg0: number): number;
        static canItemQuickReplace(arg0: Internal.Slot_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        setData(arg0: number, arg1: number): void;
        addSlotListener(arg0: net.minecraft.world.inventory.ContainerListener_): void;
        getSlot(arg0: number): Internal.Slot;
        slotsChanged(arg0: net.minecraft.world.Container_): void;
        clickMenuButton(arg0: Internal.Player_, arg1: number): boolean;
        static getQuickcraftMask(arg0: number, arg1: number): number;
        static getQuickcraftType(arg0: number): number;
        removeSlotListener(arg0: net.minecraft.world.inventory.ContainerListener_): void;
        setRemoteSlotNoCopy(arg0: number, arg1: Internal.ItemStack_): void;
        clicked(arg0: number, arg1: number, arg2: Internal.ClickType_, arg3: Internal.Player_): void;
        abstract stillValid(arg0: Internal.Player_): boolean;
        setRemoteSlot(arg0: number, arg1: Internal.ItemStack_): void;
        suppressRemoteUpdates(): void;
        initializeContents(arg0: number, arg1: Internal.List_<Internal.ItemStack>, arg2: Internal.ItemStack_): void;
        getStateId(): number;
        getCarried(): Internal.ItemStack;
        getType(): Internal.MenuType<any>;
        setSynchronizer(arg0: Internal.ContainerSynchronizer_): void;
        transferState(arg0: Internal.AbstractContainerMenu_): void;
        canDragTo(arg0: Internal.Slot_): boolean;
        removed(arg0: Internal.Player_): void;
        get items(): Internal.NonNullList<Internal.ItemStack>
        set carried(arg0: Internal.ItemStack_)
        set remoteCarried(arg0: Internal.ItemStack_)
        get stateId(): number
        get carried(): Internal.ItemStack
        get type(): Internal.MenuType<any>
        set synchronizer(arg0: Internal.ContainerSynchronizer_)
        stateId: number;
        static readonly QUICKCRAFT_HEADER_CONTINUE: 1;
        static readonly QUICKCRAFT_TYPE_CLONE: 2;
        static readonly QUICKCRAFT_HEADER_START: 0;
        static readonly QUICKCRAFT_HEADER_END: 2;
        static readonly SLOT_CLICKED_OUTSIDE: -999;
        readonly slots: Internal.NonNullList<Internal.Slot>;
        static readonly QUICKCRAFT_TYPE_CHARITABLE: 0;
        static readonly CARRIED_SLOT_SIZE: 2147483647;
        readonly containerId: number;
        static readonly QUICKCRAFT_TYPE_GREEDY: 1;
    }
    type AbstractContainerMenu_ = AbstractContainerMenu;
    abstract class NumberConfig <T extends number> extends Internal.ConfigFromString<T> {
        constructor(mn: T, mx: T)
        withScrollIncrement(increment: T): this;
        fader(v: boolean): this;
        getStringForGUI(v: T): net.minecraft.network.chat.Component;
        getColor(v: T): Internal.Color4I;
        static readonly COLOR: Internal.Color4I;
        readonly min: T;
        readonly max: T;
        fader: boolean;
    }
    type NumberConfig_<T extends number> = NumberConfig<T>;
    class Behavior$Status extends Internal.Enum<Internal.Behavior$Status> {
        static values(): Internal.Behavior$Status[];
        static valueOf(arg0: string): Internal.Behavior$Status;
        static readonly RUNNING: Internal.Behavior$Status;
        static readonly STOPPED: Internal.Behavior$Status;
    }
    type Behavior$Status_ = "stopped" | Behavior$Status | "running";
    class LocalDateTime implements Internal.ChronoLocalDateTime<Internal.LocalDate>, Internal.Temporal, Internal.TemporalAdjuster, Internal.Serializable {
        getHour(): number;
        getMonth(): Internal.Month;
        toLocalTime(): Internal.LocalTime;
        atZone(arg0: Internal.ZoneId_): Internal.ChronoZonedDateTime<any>;
        plus(arg0: number, arg1: Internal.TemporalUnit_): Internal.Temporal;
        minusMonths(arg0: number): this;
        withSecond(arg0: number): this;
        getDayOfWeek(): Internal.DayOfWeek;
        withHour(arg0: number): this;
        compareTo(arg0: any): number;
        getMinute(): number;
        static of(arg0: number, arg1: Internal.Month_, arg2: number, arg3: number, arg4: number, arg5: number): Internal.LocalDateTime;
        getDayOfMonth(): number;
        static of(arg0: Internal.LocalDate_, arg1: Internal.LocalTime_): Internal.LocalDateTime;
        "with"(arg0: Internal.TemporalAdjuster_): Internal.Temporal;
        static now(): Internal.LocalDateTime;
        plusMonths(arg0: number): this;
        static ofInstant(arg0: Internal.Instant_, arg1: Internal.ZoneId_): Internal.LocalDateTime;
        minusNanos(arg0: number): this;
        isSupported(arg0: Internal.TemporalField_): boolean;
        format(arg0: Internal.DateTimeFormatter_): string;
        getChronology(): Internal.Chronology;
        plusHours(arg0: number): this;
        plusSeconds(arg0: number): this;
        isBefore(arg0: Internal.ChronoLocalDateTime_<any>): boolean;
        static now(arg0: Internal.Clock_): Internal.LocalDateTime;
        atOffset(arg0: Internal.ZoneOffset_): Internal.OffsetDateTime;
        truncatedTo(arg0: Internal.TemporalUnit_): this;
        getYear(): number;
        range(arg0: Internal.TemporalField_): Internal.ValueRange;
        withDayOfMonth(arg0: number): this;
        get(arg0: Internal.TemporalField_): number;
        isAfter(arg0: Internal.ChronoLocalDateTime_<any>): boolean;
        "with"(arg0: Internal.TemporalField_, arg1: number): this;
        static of(arg0: number, arg1: Internal.Month_, arg2: number, arg3: number, arg4: number): Internal.LocalDateTime;
        static of(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number): Internal.LocalDateTime;
        minusMinutes(arg0: number): this;
        withMonth(arg0: number): this;
        compareTo(arg0: Internal.ChronoLocalDateTime_<any>): number;
        plus(arg0: Internal.TemporalAmount_): Internal.ChronoLocalDateTime<any>;
        static timeLineOrder(): Internal.Comparator<Internal.ChronoLocalDateTime<any>>;
        getMonthValue(): number;
        withDayOfYear(arg0: number): this;
        minusYears(arg0: number): this;
        minusWeeks(arg0: number): this;
        static ofEpochSecond(arg0: number, arg1: number, arg2: Internal.ZoneOffset_): Internal.LocalDateTime;
        static parse(arg0: Internal.CharSequence_, arg1: Internal.DateTimeFormatter_): Internal.LocalDateTime;
        plusDays(arg0: number): this;
        toLocalDate(): Internal.LocalDate;
        plusWeeks(arg0: number): this;
        withYear(arg0: number): this;
        static parse(arg0: Internal.CharSequence_): Internal.LocalDateTime;
        static of(arg0: number, arg1: Internal.Month_, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number): Internal.LocalDateTime;
        getLong(arg0: Internal.TemporalField_): number;
        plusYears(arg0: number): this;
        minus(arg0: number, arg1: Internal.TemporalUnit_): Internal.Temporal;
        static now(arg0: Internal.ZoneId_): Internal.LocalDateTime;
        static of(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): Internal.LocalDateTime;
        isEqual(arg0: Internal.ChronoLocalDateTime_<any>): boolean;
        plusMinutes(arg0: number): this;
        adjustInto(arg0: Internal.Temporal_): Internal.Temporal;
        minusHours(arg0: number): this;
        withNano(arg0: number): this;
        getDayOfYear(): number;
        query<R>(arg0: Internal.TemporalQuery_<R>): R;
        until(arg0: Internal.Temporal_, arg1: Internal.TemporalUnit_): number;
        minusDays(arg0: number): this;
        toInstant(arg0: Internal.ZoneOffset_): Internal.Instant;
        isSupported(arg0: Internal.TemporalUnit_): boolean;
        getNano(): number;
        getSecond(): number;
        static from(arg0: Internal.TemporalAccessor_): Internal.LocalDateTime;
        withMinute(arg0: number): this;
        toEpochSecond(arg0: Internal.ZoneOffset_): number;
        minus(arg0: Internal.TemporalAmount_): Internal.Temporal;
        plusNanos(arg0: number): this;
        static of(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number): Internal.LocalDateTime;
        minusSeconds(arg0: number): this;
        get hour(): number
        get month(): Internal.Month
        get dayOfWeek(): Internal.DayOfWeek
        get minute(): number
        get dayOfMonth(): number
        get chronology(): Internal.Chronology
        get year(): number
        get monthValue(): number
        get dayOfYear(): number
        get nano(): number
        get second(): number
        static readonly MAX: Internal.LocalDateTime;
        static readonly MIN: Internal.LocalDateTime;
    }
    type LocalDateTime_ = LocalDateTime;
    abstract class GuiCategoryUIEditorCategoryData$Builder <C extends Internal.ObjectCategory<any, C>, ED extends Internal.GuiCategoryUIEditorCategoryData<C, SD, ED>, SD extends Internal.GuiCategoryUIEditorSettingsData<any>, SDB extends Internal.GuiCategoryUIEditorSettingsData$Builder<SD, SDB>, EDB extends Internal.GuiCategoryUIEditorCategoryData$Builder<C, ED, SD, SDB, EDB>> extends Internal.GuiCategoryUIEditorExpandableData$Builder<Internal.GuiCategoryUIEditorExpandableData<any>, EDB> {
        constructor(arg0: Internal.ListFactory_, arg1: SDB)
        setNewCategorySupplier(arg0: Internal.Function_<Internal.GuiCategoryUIEditorAdderData, ED>): EDB;
        setSubIndex(arg0: number): EDB;
        setDefault(): Internal.GuiCategoryUIEditorExpandableData$Builder<any, any>;
        setName(arg0: string): EDB;
        addSubCategoryBuilder(arg0: EDB): EDB;
        getSettingDataBuilder(): SDB;
        build(): ED;
        set newCategorySupplier(arg0: Internal.Function_<Internal.GuiCategoryUIEditorAdderData, ED>)
        set subIndex(arg0: number)
        set name(arg0: string)
        get settingDataBuilder(): SDB
    }
    type GuiCategoryUIEditorCategoryData$Builder_<C extends Internal.ObjectCategory<any, C>, ED extends Internal.GuiCategoryUIEditorCategoryData<C, SD, ED>, SD extends Internal.GuiCategoryUIEditorSettingsData<any>, SDB extends Internal.GuiCategoryUIEditorSettingsData$Builder<SD, SDB>, EDB extends Internal.GuiCategoryUIEditorCategoryData$Builder<C, ED, SD, SDB, EDB>> = GuiCategoryUIEditorCategoryData$Builder<C, ED, SD, SDB, EDB>;
    class FluidProperties extends Internal.Record implements Internal.FluidInformation {
        constructor(id: ResourceLocation_, motionScale: number, canPushEntity: boolean, canSwim: boolean, canDrown: boolean, fallDistanceModifier: number, canExtinguish: boolean, canConvertToSource: boolean, supportsBloating: boolean, pathType: Internal.BlockPathTypes_, adjacentPathType: Internal.BlockPathTypes_, canHydrate: boolean, lightLevel: number, density: number, temperature: number, viscosity: number, rarity: Internal.Rarity_, sounds: Internal.FluidSounds_, still: ResourceLocation_, flowing: ResourceLocation_, overlay: ResourceLocation_, screenOverlay: ResourceLocation_, tintColor: number, tickDelay: number, slopeFindDistance: number, dropOff: number, explosionResistance: number, canPlace: boolean)
        fallDistanceModifier(): number;
        density(): number;
        explosionResistance(): number;
        tickDelay(): number;
        toProperties(): this;
        canSwim(): boolean;
        rarity(): Internal.Rarity;
        temperature(): number;
        static create(): Internal.FluidProperties$Builder;
        still(): ResourceLocation;
        canConvertToSource(): boolean;
        overlay(): ResourceLocation;
        id(): ResourceLocation;
        slopeFindDistance(): number;
        supportsBloating(): boolean;
        viscosity(): number;
        lightLevel(): number;
        canHydrate(): boolean;
        adjacentPathType(): Internal.BlockPathTypes;
        pathType(): Internal.BlockPathTypes;
        canPlace(): boolean;
        screenOverlay(): ResourceLocation;
        flowing(): ResourceLocation;
        dropOff(): number;
        motionScale(): number;
        tintColor(): number;
        canDrown(): boolean;
        canPushEntity(): boolean;
        sounds(): Internal.FluidSounds;
        canExtinguish(): boolean;
    }
    type FluidProperties_ = FluidProperties;
    class PlayerInteractEvent$LeftClickBlock extends Internal.PlayerInteractEvent {
        constructor()
        constructor(arg0: Internal.Player_, arg1: BlockPos_, arg2: Internal.Direction_, arg3: Internal.PlayerInteractEvent$LeftClickBlock$Action_)
        constructor(arg0: Internal.Player_, arg1: BlockPos_, arg2: Internal.Direction_)
        setUseItem(arg0: Internal.Event$Result_): void;
        getEntity(): Internal.Entity;
        getUseBlock(): Internal.Event$Result;
        getAction(): Internal.PlayerInteractEvent$LeftClickBlock$Action;
        setUseBlock(arg0: Internal.Event$Result_): void;
        getUseItem(): Internal.Event$Result;
        set useItem(arg0: Internal.Event$Result_)
        get entity(): Internal.Entity
        get useBlock(): Internal.Event$Result
        get action(): Internal.PlayerInteractEvent$LeftClickBlock$Action
        set useBlock(arg0: Internal.Event$Result_)
        get useItem(): Internal.Event$Result
    }
    type PlayerInteractEvent$LeftClickBlock_ = PlayerInteractEvent$LeftClickBlock;
    class ClientboundSetSubtitleTextPacket implements Internal.Packet<Internal.ClientGamePacketListener> {
        constructor(arg0: net.minecraft.network.chat.Component_)
        constructor(arg0: Internal.FriendlyByteBuf_)
        handle(arg0: Internal.PacketListener_): void;
        write(arg0: Internal.FriendlyByteBuf_): void;
        handle(arg0: Internal.ClientGamePacketListener_): void;
        getText(): net.minecraft.network.chat.Component;
        isSkippable(): boolean;
        get text(): net.minecraft.network.chat.Component
        get skippable(): boolean
    }
    type ClientboundSetSubtitleTextPacket_ = ClientboundSetSubtitleTextPacket;
    class SmartChuteBlock extends Internal.AbstractChuteBlock {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        getBlockEntity(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.ChuteBlockEntity;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockEntityUse(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Function_<Internal.ChuteBlockEntity, Internal.InteractionResult>): Internal.InteractionResult;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        onWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        withBlockEntityDo(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Consumer_<Internal.ChuteBlockEntity>): void;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        playRemoveSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        getBlockEntityOptional(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.Optional<Internal.ChuteBlockEntity>;
        getTicker<S extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<S>): Internal.BlockEntityTicker<S>;
        playRotateSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        newBlockEntity(arg0: BlockPos_, arg1: Internal.BlockState_): Internal.BlockEntity;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        static onRemove(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.BlockState_): void;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        onSneakWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        updateAfterWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.BlockState;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getRotatedBlockState(arg0: Internal.BlockState_, arg1: Internal.Direction_): Internal.BlockState;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getBlockEntityType(): Internal.BlockEntityType<Internal.ChuteBlockEntity>;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        get blockEntityType(): Internal.BlockEntityType<Internal.ChuteBlockEntity>
        static readonly POWERED: Internal.BooleanProperty;
    }
    type SmartChuteBlock_ = SmartChuteBlock;
    class RegistryAccess$1FrozenAccess extends Internal.RegistryAccess$ImmutableRegistryAccess implements Internal.RegistryAccess$Frozen {
        lookup<T>(arg0: Internal.ResourceKey_<Internal.Registry<T>>): Internal.Optional<Internal.HolderLookup$RegistryLookup<T>>;
        allRegistriesLifecycle(): Internal.Lifecycle;
        static create(arg0: Internal.Stream_<Internal.HolderLookup$RegistryLookup<any>>): Internal.HolderLookup$Provider;
        lookupOrThrow<T>(arg0: Internal.ResourceKey_<Internal.Registry<T>>): Internal.HolderLookup$RegistryLookup<T>;
        registryOrThrow<E>(arg0: Internal.ResourceKey_<Internal.Registry<E>>): Internal.Registry<E>;
        freeze(): Internal.RegistryAccess$Frozen;
        asGetterLookup(): Internal.HolderGetter$Provider;
        static fromRegistryOfRegistries(arg0: Internal.Registry_<Internal.Registry<any>>): Internal.RegistryAccess$Frozen;
    }
    type RegistryAccess$1FrozenAccess_ = RegistryAccess$1FrozenAccess;
    interface Supplier <T> {
        abstract get(): T;
        (): T;
    }
    type Supplier_<T> = Supplier<T>;
    class BlockTypeTile <TILE extends Internal.TileEntityMekanism> extends mekanism.common.content.blocktype.BlockType {
        constructor(tileEntityRegistrar: Internal.Supplier_<Internal.TileEntityTypeRegistryObject<TILE>>, description: Internal.ILangEntry_)
        getTileType(): Internal.TileEntityTypeRegistryObject<TILE>;
        get tileType(): Internal.TileEntityTypeRegistryObject<TILE>
    }
    type BlockTypeTile_<TILE extends Internal.TileEntityMekanism> = BlockTypeTile<TILE>;
    class ScrollController {
        constructor(listener: Internal.ScrollController$IListener_)
        update(time: number): void;
        scrollBy(delta: number, duration: number): void;
        isScrolling(): boolean;
        scrollTo(target: number): boolean;
        setStartValue(start: number): void;
        scrollTo(target: number, duration: number): void;
        setMaxScroll(max: number): void;
        scrollBy(delta: number): boolean;
        getCurrValue(): number;
        abortAnimation(): void;
        getDuration(): number;
        get scrolling(): boolean
        set startValue(start: number)
        set maxScroll(max: number)
        get currValue(): number
        get duration(): number
    }
    type ScrollController_ = ScrollController;
    class ServerPlayer extends Internal.Player implements Internal.IServerPlayer, Internal.ServerPlayerKJS, Internal.ServerPlayerEntityMixin {
        constructor(arg0: Internal.MinecraftServer_, arg1: Internal.ServerLevel_, arg2: Internal.GameProfile_)
        getDistance(pos: BlockPos_): number;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number): void;
        getStats(): Internal.PlayerStatsJS;
        removeAttribute(attribute: Internal.Attribute_, identifier: string): void;
        playSound(id: Internal.SoundEvent_, volume: number, pitch: number): void;
        setDefaultMovementSpeedMultiplier(speed: number): void;
        getSpawnLocation(): Internal.BlockContainerJS;
        getOffHandItem(): Internal.ItemStack;
        setServerLevel(arg0: Internal.ServerLevel_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        getEquipment(slot: Internal.EquipmentSlot_): Internal.ItemStack;
        setSpawnLocation(c: Internal.BlockContainerJS_): void;
        captureInventory(autoRestore: boolean): net.minecraft.world.Container;
        getPickedResult(arg0: Internal.HitResult_): Internal.ItemStack;
        loadGameTypes(arg0: Internal.CompoundTag_): void;
        getTabListFooter(): net.minecraft.network.chat.Component;
        getEntityReach(): number;
        runCommandSilent(command: string): number;
        setPosition(x: number, y: number, z: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        setY(y: number): void;
        disconnect(): void;
        allowsListing(): boolean;
        setSelectedSlot(index: number): void;
        jumpInFluid(arg0: Internal.FluidType_): void;
        kick(): void;
        rayTrace(): Internal.RayTraceResultJS;
        getTotalMovementSpeed(): number;
        alwaysAccepts(): boolean;
        moveInFluid(arg0: Internal.FluidState_, arg1: Vec3d_, arg2: number): boolean;
        isInFluidType(arg0: Internal.FluidState_): boolean;
        damageHeldItem(): void;
        shouldUpdateFluidWhileBoating(arg0: Internal.FluidState_, arg1: Internal.Boat_): boolean;
        initInventoryMenu(): void;
        setMotionZ(z: number): void;
        attack(hp: number): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        getAnimation(): Internal.AnimationApplier;
        canSwimInFluidType(arg0: Internal.FluidType_): boolean;
        getFoodLevel(): number;
        openChestGUI(title: net.minecraft.network.chat.Component_, rows: number, gui: Internal.Consumer_<Internal.ChestMenuData>): void;
        setMaxHealth(hp: number): void;
        getFacing(): Internal.Direction;
        setSaturation(saturation: number): void;
        setMainHandItem(item: Internal.ItemStack_): void;
        serverLevel(): Internal.ServerLevel;
        getItem(): Internal.ItemStack;
        setX(x: number): void;
        getXp(): number;
        setCreativeMode(mode: boolean): void;
        sendServerStatus(arg0: Internal.ServerStatus_): void;
        getHeldItem(hand: Internal.InteractionHand_): Internal.ItemStack;
        swing(hand: Internal.InteractionHand_): void;
        isMiningBlock(): boolean;
        isUndead(): boolean;
        isAmbientCreature(): boolean;
        getStepHeight(): number;
        getSoundFromFluidType(arg0: Internal.FluidType_, arg1: Internal.SoundAction_): Internal.SoundEvent;
        setExperiencePoints(arg0: number): void;
        restoreFrom(arg0: Internal.ServerPlayer_, arg1: boolean): void;
        getXaeroMinimapPlayerData(): Internal.ServerPlayerData;
        getBlock(): Internal.BlockContainerJS;
        getNbt(): Internal.CompoundTag;
        setEquipment(slot: Internal.EquipmentSlot_, item: Internal.ItemStack_): void;
        isCloseEnough(arg0: Internal.Entity_, arg1: number): boolean;
        getName(): net.minecraft.network.chat.Component;
        boostElytraFlight(): void;
        setMouseItem(item: Internal.ItemStack_): void;
        setTotalMovementSpeedMultiplier(speed: number): void;
        getTabListHeader(): net.minecraft.network.chat.Component;
        getLanguage(): string;
        sendData(channel: string, data: Internal.CompoundTag_): void;
        isInFluidType(arg0: Internal.BiPredicate_<Internal.FluidType, number>): boolean;
        initMenu(arg0: Internal.AbstractContainerMenu_): void;
        canFluidExtinguish(arg0: Internal.FluidType_): boolean;
        setRespawnPosition(arg0: Internal.ResourceKey_<Internal.Level>, arg1: BlockPos_, arg2: number, arg3: boolean, arg4: boolean): void;
        give(item: Internal.ItemStack_): void;
        revokeAdvancement(id: ResourceLocation_): void;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        isPushedByFluid(arg0: Internal.FluidType_): boolean;
        hasChangedDimension(): void;
        setOffHandItem(item: Internal.ItemStack_): void;
        setDefaultMovementSpeed(speed: number): void;
        shouldFilterMessageTo(arg0: Internal.ServerPlayer_): boolean;
        spawn(): void;
        getMainHandItem(): Internal.ItemStack;
        sinkInFluid(arg0: Internal.FluidType_): void;
        getTabListDisplayName(): net.minecraft.network.chat.Component;
        refreshTabListName(): void;
        getRespawnDimension(): Internal.ResourceKey<Internal.Level>;
        canEntityBeSeen(entity: Internal.LivingEntity_): boolean;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        getRecipeBook(): Internal.ServerRecipeBook;
        getRespawnPosition(): BlockPos;
        getScriptType(): Internal.ScriptType;
        isMultipartEntity(): boolean;
        getHeadArmorItem(): Internal.ItemStack;
        setFeetArmorItem(item: Internal.ItemStack_): void;
        getParts(): Internal.PartEntity<any>[];
        hasCustomOutlineRendering(arg0: Internal.Player_): boolean;
        setGameMode(arg0: Internal.GameType_): boolean;
        canReach(arg0: Vec3d_, arg1: number): boolean;
        setTabListHeaderFooter(arg0: net.minecraft.network.chat.Component_, arg1: net.minecraft.network.chat.Component_): void;
        nextContainerCounter(): void;
        isAdvancementDone(id: ResourceLocation_): boolean;
        deserializeNBT(arg0: Internal.Tag_): void;
        setCamera(arg0: Internal.Entity_): void;
        unlockAdvancement(id: ResourceLocation_): void;
        serializeNBT(): Internal.CompoundTag;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        isEyeInFluidType(arg0: Internal.FluidType_): boolean;
        openInventoryGUI(inventory: Internal.InventoryKJS_, title: net.minecraft.network.chat.Component_): void;
        getSaturation(): number;
        setPlayerInput(arg0: number, arg1: number, arg2: boolean, arg3: boolean): void;
        getAttributeBaseValue(attribute: Internal.Attribute_): number;
        canDrownInFluidType(arg0: Internal.FluidType_): boolean;
        isFake(): boolean;
        getChatSession(): Internal.RemoteChatSession;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        setExperienceLevels(arg0: number): void;
        getAdvancements(): Internal.PlayerAdvancements;
        addFood(f: number, m: number): void;
        swing(): void;
        teleportTo(arg0: Internal.ServerLevel_, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): void;
        canStartSwimming(): boolean;
        doCheckFallDamage(arg0: number, arg1: number, arg2: number, arg3: boolean): void;
        getXpLevel(): number;
        canReach(arg0: BlockPos_, arg1: number): boolean;
        getCapability<T>(arg0: Internal.Capability_<T>): Internal.LazyOptional<T>;
        openGUI(gui: Internal.Consumer_<Internal.KubeJSGUI>): void;
        isLiving(): boolean;
        damageEquipment(slot: Internal.EquipmentSlot_): void;
        isOp(): boolean;
        isRespawnForced(): boolean;
        canChatInColor(): boolean;
        paint(renderer: Internal.CompoundTag_): void;
        setChatSession(arg0: Internal.RemoteChatSession_): void;
        getBlockReach(): number;
        getDisplayName(): net.minecraft.network.chat.Component;
        isChangingDimension(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        notify(title: net.minecraft.network.chat.Component_, text: net.minecraft.network.chat.Component_): void;
        getTeamId(): string;
        canBeRiddenUnderFluidType(arg0: Internal.FluidType_, arg1: Internal.Entity_): boolean;
        setXpLevel(l: number): void;
        setFoodLevel(foodLevel: number): void;
        addXPLevels(l: number): void;
        setTabListFooter(arg0: net.minecraft.network.chat.Component_): void;
        shouldRiderSit(): boolean;
        getLegsArmorItem(): Internal.ItemStack;
        getChatVisibility(): Internal.ChatVisiblity;
        isHoldingInAnyHand(i: Internal.Ingredient_): boolean;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        isInFluidType(arg0: Internal.FluidType_): boolean;
        canReach(arg0: Internal.Entity_, arg1: number): boolean;
        getReachDistance(): number;
        getMotionX(): number;
        getFluidMotionScale(arg0: Internal.FluidType_): number;
        isWaterCreature(): boolean;
        sendData(channel: string): void;
        getStatsCounter(): Internal.ServerStatsCounter;
        updateOptions(arg0: Internal.ServerboundClientInformationPacket_): void;
        getSelectedSlot(): number;
        setAttributeBaseValue(attribute: Internal.Attribute_, value: number): void;
        sendTexturePack(arg0: string, arg1: string, arg2: boolean, arg3: net.minecraft.network.chat.Component_): void;
        getPotionEffects(): Internal.EntityPotionEffectsJS;
        getOpenInventory(): Internal.AbstractContainerMenu;
        resetSentInfo(): void;
        isFrame(): boolean;
        setLegsArmorItem(item: Internal.ItemStack_): void;
        playSound(id: Internal.SoundEvent_): void;
        foodEaten(is: Internal.ItemStack_): void;
        doCloseContainer(): void;
        setXp(xp: number): void;
        self(): Internal.LivingEntity;
        drop(arg0: boolean): boolean;
        getDefaultMovementSpeed(): number;
        setXaeroMinimapPlayerData(arg0: Internal.ServerPlayerData_): void;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        getAttributeTotalValue(attribute: Internal.Attribute_): number;
        isPeacefulCreature(): boolean;
        setRotation(yaw: number, pitch: number): void;
        hasDisconnected(): boolean;
        trackStartFallingPosition(): void;
        notify(builder: Notification_): void;
        isMonster(): boolean;
        getLastSectionPos(): Internal.SectionPos;
        canHydrateInFluidType(arg0: Internal.FluidType_): boolean;
        getType(): string;
        sendChatMessage(arg0: Internal.OutgoingChatMessage_, arg1: boolean, arg2: Internal.ChatType$Bound_): void;
        getCamera(): Internal.Entity;
        self(): Internal.Entity;
        setChestArmorItem(item: Internal.ItemStack_): void;
        getRespawnAngle(): number;
        setLastSectionPos(arg0: Internal.SectionPos_): void;
        getMotionY(): number;
        addExhaustion(exhaustion: number): void;
        getPassengers(): Internal.EntityArrayList;
        getTextFilter(): Internal.TextFilter;
        giveInHand(item: Internal.ItemStack_): void;
        ban(banner: string, reason: string, expiresInMillis: number): void;
        addXP(xp: number): void;
        getFluidFallDistanceModifier(arg0: Internal.FluidType_): number;
        setHeldItem(hand: Internal.InteractionHand_, item: Internal.ItemStack_): void;
        trackChunk(arg0: Internal.ChunkPos_, arg1: Internal.Packet_<any>): void;
        doTick(): void;
        trackEnteredOrExitedLavaOnVehicle(): void;
        getFeetArmorItem(): Internal.ItemStack;
        sendSystemMessage(arg0: net.minecraft.network.chat.Component_, arg1: boolean): void;
        getContainerSynchronizer(): Internal.ContainerSynchronizer;
        lookAt(arg0: Internal.EntityAnchorArgument$Anchor_, arg1: Internal.Entity_, arg2: Internal.EntityAnchorArgument$Anchor_): void;
        getServer(): Internal.MinecraftServer;
        setMotionX(x: number): void;
        tdv$isDynamicLightEnabled(): boolean;
        resetLastActionTime(): void;
        getIpAddress(): string;
        setNbt(nbt: Internal.CompoundTag_): void;
        getLevel(): Internal.Level;
        setMovementSpeedAddition(speed: number): void;
        getLastActionTime(): number;
        modifyAttribute(attribute: Internal.Attribute_, identifier: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        tdv$setDynamicLightEnabled(arg0: boolean): void;
        setPositionAndRotation(x: number, y: number, z: number, yaw: number, pitch: number): void;
        kick(reason: net.minecraft.network.chat.Component_): void;
        sendInventoryUpdate(): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        getEyeHeightForge(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        getChestArmorItem(): Internal.ItemStack;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number): void;
        getMotionZ(): number;
        untrackChunk(arg0: Internal.ChunkPos_): void;
        setTabListHeader(arg0: net.minecraft.network.chat.Component_): void;
        tell(message: net.minecraft.network.chat.Component_): void;
        getMouseItem(): Internal.ItemStack;
        setZ(z: number): void;
        getDistanceSq(pos: BlockPos_): number;
        deserializeNBT(arg0: Internal.CompoundTag_): void;
        getProfile(): Internal.GameProfile;
        setHeadArmorItem(item: Internal.ItemStack_): void;
        getClassification(arg0: boolean): Internal.MobCategory;
        runCommand(command: string): number;
        addItemCooldown(item: Internal.Item_, ticks: number): void;
        get stats(): Internal.PlayerStatsJS
        set defaultMovementSpeedMultiplier(speed: number)
        get spawnLocation(): Internal.BlockContainerJS
        get offHandItem(): Internal.ItemStack
        set serverLevel(arg0: Internal.ServerLevel_)
        set spawnLocation(c: Internal.BlockContainerJS_)
        get tabListFooter(): net.minecraft.network.chat.Component
        get entityReach(): number
        get player(): boolean
        get animal(): boolean
        set y(y: number)
        set selectedSlot(index: number)
        get totalMovementSpeed(): number
        set motionZ(z: number)
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        get animation(): Internal.AnimationApplier
        get foodLevel(): number
        set maxHealth(hp: number)
        get facing(): Internal.Direction
        set saturation(saturation: number)
        set mainHandItem(item: Internal.ItemStack_)
        get item(): Internal.ItemStack
        set x(x: number)
        get xp(): number
        set creativeMode(mode: boolean)
        get miningBlock(): boolean
        get undead(): boolean
        get ambientCreature(): boolean
        get stepHeight(): number
        set experiencePoints(arg0: number)
        get xaeroMinimapPlayerData(): Internal.ServerPlayerData
        get block(): Internal.BlockContainerJS
        get nbt(): Internal.CompoundTag
        get name(): net.minecraft.network.chat.Component
        set mouseItem(item: Internal.ItemStack_)
        set totalMovementSpeedMultiplier(speed: number)
        get tabListHeader(): net.minecraft.network.chat.Component
        get language(): string
        set offHandItem(item: Internal.ItemStack_)
        set defaultMovementSpeed(speed: number)
        get mainHandItem(): Internal.ItemStack
        get tabListDisplayName(): net.minecraft.network.chat.Component
        get respawnDimension(): Internal.ResourceKey<Internal.Level>
        get recipeBook(): Internal.ServerRecipeBook
        get respawnPosition(): BlockPos
        get scriptType(): Internal.ScriptType
        get multipartEntity(): boolean
        get headArmorItem(): Internal.ItemStack
        set feetArmorItem(item: Internal.ItemStack_)
        get parts(): Internal.PartEntity<any>[]
        set gameMode(arg0: Internal.GameType_)
        set camera(arg0: Internal.Entity_)
        set statusMessage(message: net.minecraft.network.chat.Component_)
        get saturation(): number
        get fake(): boolean
        get chatSession(): Internal.RemoteChatSession
        set experienceLevels(arg0: number)
        get advancements(): Internal.PlayerAdvancements
        get xpLevel(): number
        get living(): boolean
        get op(): boolean
        get respawnForced(): boolean
        set chatSession(arg0: Internal.RemoteChatSession_)
        get blockReach(): number
        get displayName(): net.minecraft.network.chat.Component
        get changingDimension(): boolean
        set position(block: Internal.BlockContainerJS_)
        get teamId(): string
        set xpLevel(l: number)
        set foodLevel(foodLevel: number)
        set tabListFooter(arg0: net.minecraft.network.chat.Component_)
        get legsArmorItem(): Internal.ItemStack
        get chatVisibility(): Internal.ChatVisiblity
        get reachDistance(): number
        get motionX(): number
        get waterCreature(): boolean
        get statsCounter(): Internal.ServerStatsCounter
        get selectedSlot(): number
        get potionEffects(): Internal.EntityPotionEffectsJS
        get openInventory(): Internal.AbstractContainerMenu
        get frame(): boolean
        set legsArmorItem(item: Internal.ItemStack_)
        set xp(xp: number)
        get defaultMovementSpeed(): number
        set xaeroMinimapPlayerData(arg0: Internal.ServerPlayerData_)
        set motionY(y: number)
        get peacefulCreature(): boolean
        get monster(): boolean
        get lastSectionPos(): Internal.SectionPos
        get type(): string
        get camera(): Internal.Entity
        set chestArmorItem(item: Internal.ItemStack_)
        get respawnAngle(): number
        set lastSectionPos(arg0: Internal.SectionPos_)
        get motionY(): number
        get passengers(): Internal.EntityArrayList
        get textFilter(): Internal.TextFilter
        get feetArmorItem(): Internal.ItemStack
        get containerSynchronizer(): Internal.ContainerSynchronizer
        get server(): Internal.MinecraftServer
        set motionX(x: number)
        get ipAddress(): string
        set nbt(nbt: Internal.CompoundTag_)
        get level(): Internal.Level
        set movementSpeedAddition(speed: number)
        get lastActionTime(): number
        get chestArmorItem(): Internal.ItemStack
        get motionZ(): number
        set tabListHeader(arg0: net.minecraft.network.chat.Component_)
        get mouseItem(): Internal.ItemStack
        set z(z: number)
        get profile(): Internal.GameProfile
        set headArmorItem(item: Internal.ItemStack_)
        latency: number;
        containerCounter: number;
        wonGame: boolean;
        readonly gameMode: Internal.ServerPlayerGameMode;
        readonly server: Internal.MinecraftServer;
        connection: Internal.ServerGamePacketListenerImpl;
    }
    type ServerPlayer_ = ServerPlayer;
    class TrackNodeLocation extends Vec3i {
        constructor(arg0: Vec3d_)
        constructor(arg0: number, arg1: number, arg2: number)
        write(arg0: Internal.DimensionPalette_): Internal.CompoundTag;
        "in"(arg0: Internal.ResourceKey_<Internal.Level>): this;
        allAdjacent(): Internal.Collection<BlockPos>;
        getDimension(): Internal.ResourceKey<Internal.Level>;
        send(arg0: Internal.FriendlyByteBuf_, arg1: Internal.DimensionPalette_): void;
        equalsIgnoreDim(arg0: any): boolean;
        "in"(arg0: Internal.Level_): this;
        static receive(arg0: Internal.FriendlyByteBuf_, arg1: Internal.DimensionPalette_): Internal.TrackNodeLocation;
        getLocation(): Vec3d;
        static read(arg0: Internal.CompoundTag_, arg1: Internal.DimensionPalette_): Internal.TrackNodeLocation;
        get dimension(): Internal.ResourceKey<Internal.Level>
        get location(): Vec3d
        dimension: Internal.ResourceKey<Internal.Level>;
        yOffsetPixels: number;
    }
    type TrackNodeLocation_ = TrackNodeLocation;
    interface Object2LongMap <K> extends Internal.Object2LongFunction<K>, Internal.Map<K, number> {
        andThenFloat(arg0: Internal.Long2FloatFunction_): Internal.Object2FloatFunction<K>;
        /**
         * @deprecated
        */
        containsValue(arg0: any): boolean;
        andThenByte(arg0: Internal.Long2ByteFunction_): Internal.Object2ByteFunction<K>;
        /**
         * @deprecated
        */
        computeLongIfAbsent(arg0: K, arg1: Internal.ToLongFunction_<K>): number;
        /**
         * @deprecated
        */
        andThen<T>(arg0: Internal.Function_<number, T>): Internal.Function<K, T>;
        keySet(): Internal.Set<any>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V): Internal.Map<K, V>;
        composeDouble(arg0: Internal.Double2ObjectFunction_<K>): Internal.Double2LongFunction;
        /**
         * @deprecated
        */
        replace(arg0: K, arg1: number, arg2: number): boolean;
        compose<V>(arg0: Internal.Function_<V, K>): Internal.Function<V, number>;
        /**
         * @deprecated
        */
        remove(arg0: any): number;
        composeObject<T>(arg0: Internal.Object2ObjectFunction_<T, K>): Internal.Object2LongFunction<T>;
        /**
         * @deprecated
        */
        replace(arg0: any, arg1: any, arg2: any): boolean;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        /**
         * @deprecated
        */
        putIfAbsent(arg0: K, arg1: number): number;
        copyOf<K, V>(arg0: Internal.Map_<K, V>): Internal.Map<K, V>;
        values(): Internal.Collection<any>;
        /**
         * @deprecated
        */
        entrySet(): Internal.Set<any>;
        composeShort(arg0: Internal.Short2ObjectFunction_<K>): Internal.Short2LongFunction;
        applyAsLong(arg0: K): number;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V): Internal.Map<K, V>;
        computeIfAbsent(arg0: K, arg1: Internal.ToLongFunction_<K>): number;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: number): number;
        /**
         * @deprecated
        */
        merge(arg0: K, arg1: number, arg2: Internal.BiFunction_<number, number, number>): number;
        composeChar(arg0: Internal.Char2ObjectFunction_<K>): Internal.Char2LongFunction;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V): Internal.Map<K, V>;
        computeIfAbsent(arg0: K, arg1: Internal.Function_<K, number>): number;
        ofEntries<K, V>(...arg0: Internal.Map$Entry_<K, V>[]): Internal.Map<K, V>;
        composeReference<T>(arg0: Internal.Reference2ObjectFunction_<T, K>): Internal.Reference2LongFunction<T>;
        replace(arg0: K, arg1: number, arg2: number): boolean;
        andThenShort(arg0: Internal.Long2ShortFunction_): Internal.Object2ShortFunction<K>;
        identity<T>(): Internal.Function<T, T>;
        /**
         * @deprecated
        */
        putIfAbsent(arg0: any, arg1: any): any;
        of<K, V>(arg0: K, arg1: V): Internal.Map<K, V>;
        composeLong(arg0: Internal.Long2ObjectFunction_<K>): Internal.Long2LongFunction;
        remove(arg0: any, arg1: number): boolean;
        andThenLong(arg0: Internal.Long2LongFunction_): Internal.Object2LongFunction<K>;
        computeIfAbsent(arg0: K, arg1: Internal.Object2LongFunction_<K>): number;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: any): any;
        of<K, V>(): Internal.Map<K, V>;
        putIfAbsent(arg0: K, arg1: number): number;
        computeLongIfPresent(arg0: K, arg1: Internal.BiFunction_<K, number, number>): number;
        removeLong(arg0: any): number;
        put(arg0: K, arg1: number): number;
        abstract isEmpty(): boolean;
        compute(arg0: K, arg1: Internal.BiFunction_<K, number, number>): number;
        entry<K, V>(arg0: K, arg1: V): Internal.Map$Entry<K, V>;
        mergeLong(arg0: K, arg1: number, arg2: Internal.LongBinaryOperator_): number;
        composeInt(arg0: Internal.Int2ObjectFunction_<K>): Internal.Int2LongFunction;
        abstract containsValue(arg0: number): boolean;
        replaceAll(arg0: Internal.BiFunction_<K, number, number>): void;
        abstract containsKey(arg0: any): boolean;
        composeByte(arg0: Internal.Byte2ObjectFunction_<K>): Internal.Byte2LongFunction;
        abstract getLong(arg0: any): number;
        andThenDouble(arg0: Internal.Long2DoubleFunction_): Internal.Object2DoubleFunction<K>;
        andThenChar(arg0: Internal.Long2CharFunction_): Internal.Object2CharFunction<K>;
        /**
         * @deprecated
        */
        replace(arg0: K, arg1: number): number;
        composeFloat(arg0: Internal.Float2ObjectFunction_<K>): Internal.Float2LongFunction;
        abstract object2LongEntrySet(): Internal.ObjectSet<Internal.Object2LongMap$Entry<K>>;
        computeLong(arg0: K, arg1: Internal.BiFunction_<K, number, number>): number;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V): Internal.Map<K, V>;
        abstract defaultReturnValue(): number;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V): Internal.Map<K, V>;
        forEach(arg0: Internal.BiConsumer_<K, number>): void;
        andThenInt(arg0: Internal.Long2IntFunction_): Internal.Object2IntFunction<K>;
        /**
         * @deprecated
        */
        remove(arg0: any, arg1: any): boolean;
        replace(arg0: K, arg1: number): number;
        apply(arg0: K): number;
        computeIfPresent(arg0: K, arg1: Internal.BiFunction_<K, number, number>): number;
        /**
         * @deprecated
        */
        computeLongIfAbsentPartial(arg0: K, arg1: Internal.Object2LongFunction_<K>): number;
        /**
         * @deprecated
        */
        mergeLong(arg0: K, arg1: number, arg2: Internal.BiFunction_<number, number, number>): number;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V): Internal.Map<K, V>;
        abstract putAll(arg0: Internal.Map_<K, number>): void;
        getOrDefault(arg0: any, arg1: number): number;
        andThenReference<T>(arg0: Internal.Long2ReferenceFunction_<T>): Internal.Object2ReferenceFunction<K, T>;
        abstract size(): number;
        merge(arg0: K, arg1: number, arg2: Internal.BiFunction_<number, number, number>): number;
        abstract hashCode(): number;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V, arg18: K, arg19: V): Internal.Map<K, V>;
        mergeLong(arg0: K, arg1: number, arg2: it.unimi.dsi.fastutil.longs.LongBinaryOperator_): number;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V): Internal.Map<K, V>;
        clear(): void;
        /**
         * @deprecated
        */
        replace(arg0: any, arg1: any): any;
        /**
         * @deprecated
        */
        merge(arg0: any, arg1: any, arg2: Internal.BiFunction_<any, any, any>): any;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V): Internal.Map<K, V>;
        abstract equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        get(arg0: any): any;
        andThenObject<T>(arg0: Internal.Long2ObjectFunction_<T>): Internal.Object2ObjectFunction<K, T>;
        abstract defaultReturnValue(arg0: number): void;
        /**
         * @deprecated
        */
        put(arg0: K, arg1: number): number;
        get empty(): boolean
    }
    type Object2LongMap_<K> = Object2LongMap<K>;
    interface IForgeFluidState {
        getAdjacentBlockPathType(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Mob_, arg3: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canExtinguish(arg0: Internal.BlockGetter_, arg1: BlockPos_): boolean;
        canHydrate(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: BlockPos_): boolean;
        move(arg0: Internal.LivingEntity_, arg1: Vec3d_, arg2: number): boolean;
        supportsBoating(arg0: Internal.Boat_): boolean;
        shouldUpdateWhileBoating(arg0: Internal.Boat_, arg1: Internal.Entity_): boolean;
        canConvertToSource(arg0: Internal.Level_, arg1: BlockPos_): boolean;
        getBlockPathType(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Mob_, arg3: boolean): Internal.BlockPathTypes;
        getFluidType(): Internal.FluidType;
        getExplosionResistance(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Explosion_): number;
        get fluidType(): Internal.FluidType
    }
    type IForgeFluidState_ = IForgeFluidState;
    class LargeCarvedTopNoBeardAdaptation extends Internal.EnhancedTerrainAdaptation {
        constructor()
        static readonly CODEC: Internal.Codec<Internal.LargeCarvedTopNoBeardAdaptation>;
    }
    type LargeCarvedTopNoBeardAdaptation_ = LargeCarvedTopNoBeardAdaptation;
    class Structure$StructureSettings extends Internal.Record {
        constructor(biomes: Internal.HolderSet_<Internal.Biome>, spawnOverrides: Internal.Map_<Internal.MobCategory, Internal.StructureSpawnOverride>, step: Internal.GenerationStep$Decoration_, terrainAdaptation: Internal.TerrainAdjustment_)
        biomes(): Internal.HolderSet<Internal.Biome>;
        spawnOverrides(): Internal.Map<Internal.MobCategory, Internal.StructureSpawnOverride>;
        step(): Internal.GenerationStep$Decoration;
        terrainAdaptation(): Internal.TerrainAdjustment;
        static readonly CODEC: Internal.MapCodec<Internal.Structure$StructureSettings>;
    }
    type Structure$StructureSettings_ = Structure$StructureSettings;
    class StateDefinition$Builder <O, S extends Internal.StateHolder<O, S>> {
        constructor(arg0: O)
        create(arg0: Internal.Function_<O, S>, arg1: Internal.StateDefinition$Factory_<O, S>): Internal.StateDefinition<O, S>;
        add(...arg0: Internal.Property_<any>[]): this;
        readonly properties: Internal.Map<string, Internal.Property<any>>;
    }
    type StateDefinition$Builder_<O, S extends Internal.StateHolder<O, S>> = StateDefinition$Builder<O, S>;
    class BookCloningRecipe extends Internal.CustomRecipe {
        constructor(arg0: ResourceLocation_, arg1: Internal.CraftingBookCategory_)
        getIngredients(): Internal.NonNullList<Internal.Ingredient>;
        getGroup(): string;
        getToastSymbol(): Internal.ItemStack;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        matches(arg0: Internal.CraftingContainer_, arg1: Internal.Level_): boolean;
        getSchema(): Internal.RecipeSchema;
        getRemainingItems(arg0: net.minecraft.world.Container_): Internal.NonNullList<any>;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        getRemainingItems(arg0: Internal.CraftingContainer_): Internal.NonNullList<Internal.ItemStack>;
        getType(): ResourceLocation;
        assemble(arg0: Internal.CraftingContainer_, arg1: Internal.RegistryAccess_): Internal.ItemStack;
        setGroup(group: string): void;
        getOrCreateId(): ResourceLocation;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        isIncomplete(): boolean;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        getMod(): string;
        get ingredients(): Internal.NonNullList<Internal.Ingredient>
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get schema(): Internal.RecipeSchema
        get type(): ResourceLocation
        set group(group: string)
        get orCreateId(): ResourceLocation
        get incomplete(): boolean
        get mod(): string
    }
    type BookCloningRecipe_ = BookCloningRecipe;
    class InterModEnqueueEvent extends Internal.ParallelDispatchEvent {
        constructor()
        constructor(arg0: Internal.ModContainer_, arg1: Internal.ModLoadingStage_)
    }
    type InterModEnqueueEvent_ = InterModEnqueueEvent;
    interface MixinItemRenderer {
        abstract getColors(): Internal.ItemColors;
        get colors(): Internal.ItemColors
        (): Internal.ItemColors_;
    }
    type MixinItemRenderer_ = MixinItemRenderer;
    class RingBufferAdmin implements Internal.RingBufferAdminMBean {
        abstract getBufferSize(): number;
        abstract getRemainingCapacity(): number;
        get bufferSize(): number
        get remainingCapacity(): number
    }
    type RingBufferAdmin_ = RingBufferAdmin;
    class AbuseReport {
        constructor(arg0: string, arg1: string, arg2: Internal.ReportEvidence_, arg3: Internal.ReportedEntity_, arg4: Internal.Instant_)
        createdTime: Internal.Instant;
        reportedEntity: Internal.ReportedEntity;
        opinionComments: string;
        evidence: Internal.ReportEvidence;
        reason: string;
    }
    type AbuseReport_ = AbuseReport;
    class EntityPotionEffectsJS {
        constructor(e: Internal.LivingEntity_)
        getActive(mobEffect: Internal.MobEffect_): Internal.MobEffectInstance;
        add(mobEffect: Internal.MobEffect_, duration: number, amplifier: number, ambient: boolean, showParticles: boolean): void;
        add(mobEffect: Internal.MobEffect_, duration: number): void;
        clear(): void;
        getActive(): Internal.Collection<Internal.MobEffectInstance>;
        isActive(mobEffect: Internal.MobEffect_): boolean;
        add(mobEffect: Internal.MobEffect_, duration: number, amplifier: number): void;
        getMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>;
        isApplicable(effect: Internal.MobEffectInstance_): boolean;
        add(mobEffect: Internal.MobEffect_): void;
        getDuration(mobEffect: Internal.MobEffect_): number;
        get active(): Internal.Collection<Internal.MobEffectInstance>
        get map(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>
    }
    type EntityPotionEffectsJS_ = EntityPotionEffectsJS;
    class MappingRecipeComponent <T> implements Internal.RecipeComponentWithParent<T> {
        constructor(parent: Internal.RecipeComponent_<T>, mappingTo: Internal.UnaryOperator_<any>, mappingFrom: Internal.UnaryOperator_<Internal.JsonElement>)
        and<O>(other: Internal.RecipeComponent_<O>): Internal.AndRecipeComponent<T, O>;
        /**
         * Returns a new RecipeComponent that applies the mappingTo function to the input before it is passed to this component to be read
        */
        mapIn(mappingTo: Internal.UnaryOperator_<any>): this;
        parentComponent(): Internal.RecipeComponent<T>;
        isOutput(recipe: Internal.RecipeJS_, value: T, match: Internal.ReplacementMatch_): boolean;
        key(name: string): Internal.RecipeKey<T>;
        read(recipe: Internal.RecipeJS_, from: any): T;
        orSelf(): Internal.RecipeComponent<T>;
        checkEmpty(key: Internal.RecipeKey_<T>, value: T): string;
        role(): Internal.ComponentRole;
        componentClass(): typeof any;
        /**
         * Returns a new RecipeComponent that applies the mappingTo function to the input before it is passed to this component to be read, and the mappingFrom function after the component writes to json, before that json is saved
        */
        map(mappingTo: Internal.UnaryOperator_<any>, mappingFrom: Internal.UnaryOperator_<Internal.JsonElement>): this;
        replaceInput(recipe: Internal.RecipeJS_, original: T, match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): T;
        readFromJson(recipe: Internal.RecipeJS_, cv: Internal.RecipeComponentValue_<T>, json: Internal.JsonObject_): void;
        checkValueHasChanged(oldValue: T, newValue: T): boolean;
        constructorDescription(ctx: Internal.DescriptionContext_): Internal.TypeDescJS;
        componentType(): string;
        static builder(): Internal.RecipeComponentBuilder;
        hasPriority(recipe: Internal.RecipeJS_, from: any): boolean;
        replaceOutput(recipe: Internal.RecipeJS_, original: T, match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): T;
        /**
         * Returns a new RecipeComponent that maps the keys in a JsonObject according to the provided map, both before the json gets passed to the component and after the component returns a written json object.
         * The mappings should be provided in the format `{recipe: "component"}` where recipe is the key as in the recipe, and component is the key as how the RecipeComponent expects it.
         * Any keys not included in the provided map will be ignored, and any keys in the provided map that are not in either the input object or output object will be ignored.
         * Note that if the input or output is not a JsonObject (ie its an ItemStack, or it is a JsonPrimitive) then that will pass through this without being modified.
         * If you wish to handle those situations use the actual map function
        */
        simpleMap(mappings: any): Internal.SimpleMappingRecipeComponent<T>;
        asArrayOrSelf(): Internal.ArrayRecipeComponent<T>;
        isInput(recipe: Internal.RecipeJS_, value: T, match: Internal.ReplacementMatch_): boolean;
        static builder(...key: Internal.RecipeKey_<any>[]): Internal.RecipeComponentBuilder;
        /**
         * Returns a new RecipeComponent that applies the mappingFrom function after the component writes to json, before that json is saved
        */
        mapOut(mappingFrom: Internal.UnaryOperator_<Internal.JsonElement>): this;
        asMap<K>(key: Internal.RecipeComponent_<K>): Internal.RecipeComponent<Internal.TinyMap<K, T>>;
        asArray(): Internal.ArrayRecipeComponent<T>;
        asPatternKey(): Internal.RecipeComponent<Internal.TinyMap<string, T>>;
        write(recipe: Internal.RecipeJS_, value: T): Internal.JsonElement;
        writeToJson(recipe: Internal.RecipeJS_, cv: Internal.RecipeComponentValue_<T>, json: Internal.JsonObject_): void;
        readFromMap(recipe: Internal.RecipeJS_, cv: Internal.RecipeComponentValue_<T>, map: Internal.Map_<any, any>): void;
        or<O>(other: Internal.RecipeComponent_<O>): Internal.OrRecipeComponent<T, O>;
    }
    type MappingRecipeComponent_<T> = MappingRecipeComponent<T>;
    class ScreenEvent$Init$Post extends Internal.ScreenEvent$Init {
        constructor()
        constructor(arg0: Internal.Screen_, arg1: Internal.List_<Internal.GuiEventListener>, arg2: Internal.Consumer_<Internal.GuiEventListener>, arg3: Internal.Consumer_<Internal.GuiEventListener>)
    }
    type ScreenEvent$Init$Post_ = ScreenEvent$Init$Post;
    class MaterialChecklist {
        constructor()
        require(arg0: Internal.ItemRequirement_): void;
        warnBlockNotLoaded(): void;
        collect(arg0: Internal.ItemStack_): void;
        createWrittenBook(): Internal.ItemStack;
        createWrittenClipboard(): Internal.ItemStack;
        getRequiredAmount(arg0: Internal.Item_): number;
        damageRequired: Internal.Object2IntMap<Internal.Item>;
        blocksNotLoaded: boolean;
        static readonly MAX_ENTRIES_PER_PAGE: 5;
        static readonly MAX_ENTRIES_PER_CLIPBOARD_PAGE: 7;
        required: Internal.Object2IntMap<Internal.Item>;
        gathered: Internal.Object2IntMap<Internal.Item>;
    }
    type MaterialChecklist_ = MaterialChecklist;
    class ScriptType extends Internal.Enum<Internal.ScriptType> implements Internal.ScriptTypePredicate, Internal.ScriptTypeHolder {
        getValidTypes(): Internal.List<Internal.ScriptType>;
        and(arg0: Internal.Predicate_<Internal.ScriptType>): Internal.Predicate<Internal.ScriptType>;
        static not<T>(arg0: Internal.Predicate_<T>): Internal.Predicate<T>;
        test(type: Internal.ScriptType_): boolean;
        isClient(): boolean;
        static valueOf(name: string): Internal.ScriptType;
        isStartup(): boolean;
        or(arg0: Internal.Predicate_<Internal.ScriptType>): Internal.Predicate<Internal.ScriptType>;
        negate(): Internal.ScriptTypePredicate;
        static isEqual<T>(arg0: any): Internal.Predicate<T>;
        kjs$getScriptType(): this;
        test(arg0: any): boolean;
        getLogFile(): Internal.Path;
        isServer(): boolean;
        static getCurrent(cx: Internal.Context_): Internal.ScriptType;
        static values(): Internal.ScriptType[];
        get validTypes(): Internal.List<Internal.ScriptType>
        get client(): boolean
        get startup(): boolean
        get logFile(): Internal.Path
        get server(): boolean
        readonly name: string;
        static readonly VALUES: Internal.ScriptType[];
        readonly nameStrip: string;
        static readonly STARTUP: Internal.ScriptType;
        readonly console: Internal.ConsoleJS;
        readonly path: Internal.Path;
        static readonly SERVER: Internal.ScriptType;
        static readonly CLIENT: Internal.ScriptType;
    }
    type ScriptType_ = ScriptType | "startup" | "server" | "client";
    class PermissionType <T> {
        typeToken(): T;
        typeName(): string;
    }
    type PermissionType_<T> = PermissionType<T>;
    class StickerBlock extends Internal.WrenchableDirectionalBlock implements Internal.IBE<Internal.StickerBlockEntity> {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        getBlockEntityClass(): typeof Internal.StickerBlockEntity;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        onWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        playRemoveSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getBlockEntity(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.StickerBlockEntity;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        getTicker<S extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<S>): Internal.BlockEntityTicker<S>;
        playRotateSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        newBlockEntity(arg0: BlockPos_, arg1: Internal.BlockState_): Internal.BlockEntity;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getBlockEntityOptional(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.Optional<Internal.StickerBlockEntity>;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        static onRemove(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.BlockState_): void;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        onSneakWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        onBlockEntityUse(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Function_<Internal.StickerBlockEntity, Internal.InteractionResult>): Internal.InteractionResult;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        updateAfterWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.BlockState;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        withBlockEntityDo(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Consumer_<Internal.StickerBlockEntity>): void;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getBlockEntityType(): Internal.BlockEntityType<Internal.StickerBlockEntity>;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get blockEntityClass(): typeof Internal.StickerBlockEntity
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        get blockEntityType(): Internal.BlockEntityType<Internal.StickerBlockEntity>
        static readonly EXTENDED: Internal.BooleanProperty;
        static readonly POWERED: Internal.BooleanProperty;
    }
    type StickerBlock_ = StickerBlock;
    class Vector4i implements Internal.Cloneable, Internal.Vector4ic, Internal.Externalizable {
        constructor()
        constructor(arg0: Internal.Vector4dc_, arg1: number)
        constructor(arg0: number, arg1: number, arg2: number, arg3: number)
        constructor(arg0: Internal.ByteBuffer_)
        constructor(arg0: number)
        constructor(arg0: number[])
        constructor(arg0: number, arg1: Internal.ByteBuffer_)
        constructor(arg0: Internal.Vector3fc_, arg1: number, arg2: number)
        constructor(arg0: number, arg1: Internal.IntBuffer_)
        constructor(arg0: Internal.IntBuffer_)
        constructor(arg0: Internal.Vector2ic_, arg1: number, arg2: number)
        constructor(arg0: Internal.Vector4fc_, arg1: number)
        constructor(arg0: Internal.Vector3ic_, arg1: number)
        constructor(arg0: Internal.Vector4ic_)
        add(arg0: Internal.Vector4ic_): this;
        add(arg0: number, arg1: number, arg2: number, arg3: number): this;
        z(): number;
        set(arg0: number, arg1: Internal.IntBuffer_): this;
        x(): number;
        set(arg0: number, arg1: number, arg2: number, arg3: number): this;
        div(arg0: number, arg1: Internal.Vector4i_): this;
        set(arg0: number): this;
        get(arg0: number, arg1: Internal.ByteBuffer_): Internal.ByteBuffer;
        mul(arg0: Internal.Vector4ic_, arg1: Internal.Vector4i_): this;
        set(arg0: Internal.IntBuffer_): this;
        distance(arg0: Internal.Vector4ic_): number;
        absolute(): this;
        static lengthSquared(arg0: number, arg1: number, arg2: number, arg3: number): number;
        div(arg0: Internal.Vector4ic_, arg1: Internal.Vector4i_): this;
        setFromAddress(arg0: number): this;
        div(arg0: number): this;
        set(arg0: Internal.Vector4ic_): this;
        get(arg0: number, arg1: Internal.IntBuffer_): Internal.IntBuffer;
        max(arg0: Internal.Vector4ic_): this;
        min(arg0: Internal.Vector4ic_, arg1: Internal.Vector4i_): this;
        set(arg0: Internal.ByteBuffer_): this;
        readExternal(arg0: Internal.ObjectInput_): void;
        toString(arg0: Internal.NumberFormat_): string;
        set(arg0: Internal.Vector4dc_, arg1: number): this;
        distanceSquared(arg0: number, arg1: number, arg2: number, arg3: number): number;
        lengthSquared(): number;
        length(): number;
        distance(arg0: number, arg1: number, arg2: number, arg3: number): number;
        get(arg0: Internal.ByteBuffer_): Internal.ByteBuffer;
        min(arg0: Internal.Vector4ic_): this;
        set(arg0: number, arg1: Internal.ByteBuffer_): this;
        add(arg0: Internal.Vector4ic_, arg1: Internal.Vector4i_): this;
        distanceSquared(arg0: Internal.Vector4ic_): number;
        minComponent(): number;
        zero(): this;
        clone(): any;
        w(): number;
        static distance(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number, arg7: number): number;
        absolute(arg0: Internal.Vector4i_): this;
        writeExternal(arg0: Internal.ObjectOutput_): void;
        div(arg0: Internal.Vector4ic_): this;
        setComponent(arg0: number, arg1: number): this;
        maxComponent(): number;
        y(): number;
        set(arg0: Internal.Vector4dc_): this;
        static distanceSquared(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number, arg7: number): number;
        gridDistance(arg0: Internal.Vector4ic_): number;
        set(arg0: number[]): this;
        div(arg0: number): this;
        mul(arg0: Internal.Vector4ic_): this;
        max(arg0: Internal.Vector4ic_, arg1: Internal.Vector4i_): this;
        add(arg0: number, arg1: number, arg2: number, arg3: number, arg4: Internal.Vector4i_): this;
        sub(arg0: Internal.Vector4ic_, arg1: Internal.Vector4i_): this;
        get(arg0: Internal.IntBuffer_): Internal.IntBuffer;
        static length(arg0: number, arg1: number, arg2: number, arg3: number): number;
        mul(arg0: number): this;
        gridDistance(arg0: number, arg1: number, arg2: number, arg3: number): number;
        dot(arg0: Internal.Vector4ic_): number;
        sub(arg0: number, arg1: number, arg2: number, arg3: number): this;
        negate(): this;
        set(arg0: Internal.Vector2ic_, arg1: number, arg2: number): this;
        equals(arg0: number, arg1: number, arg2: number, arg3: number): boolean;
        div(arg0: number, arg1: Internal.Vector4i_): this;
        mul(arg0: number, arg1: Internal.Vector4i_): this;
        negate(arg0: Internal.Vector4i_): this;
        set(arg0: Internal.Vector3ic_, arg1: number): this;
        getToAddress(arg0: number): Internal.Vector4ic;
        sub(arg0: number, arg1: number, arg2: number, arg3: number, arg4: Internal.Vector4i_): this;
        get(arg0: number): number;
        sub(arg0: Internal.Vector4ic_): this;
        set(arg0: Internal.Vector4fc_, arg1: number): this;
        set fromAddress(arg0: number)
        z: number;
        x: number;
        y: number;
        w: number;
    }
    type Vector4i_ = Vector4i;
    class ServerFunctionLibrary implements Internal.PreparableReloadListener {
        constructor(arg0: number, arg1: Internal.CommandDispatcher_<Internal.CommandSourceStack>)
        getTag(arg0: ResourceLocation_): Internal.Collection<Internal.CommandFunction>;
        getAvailableTags(): Internal.Iterable<ResourceLocation>;
        getName(): string;
        getFunction(arg0: ResourceLocation_): Internal.Optional<Internal.CommandFunction>;
        getFunctions(): Internal.Map<ResourceLocation, Internal.CommandFunction>;
        reload(arg0: Internal.PreparableReloadListener$PreparationBarrier_, arg1: Internal.ResourceManager_, arg2: Internal.ProfilerFiller_, arg3: Internal.ProfilerFiller_, arg4: Internal.Executor_, arg5: Internal.Executor_): Internal.CompletableFuture<void>;
        get availableTags(): Internal.Iterable<ResourceLocation>
        get name(): string
        get functions(): Internal.Map<ResourceLocation, Internal.CommandFunction>
    }
    type ServerFunctionLibrary_ = ServerFunctionLibrary;
    class BlockComponent extends Internal.Record implements Internal.RecipeComponent<Internal.Block> {
        constructor(crole: Internal.ComponentRole_)
        asArray(): Internal.ArrayRecipeComponent<Internal.Block>;
        readFromJson(recipe: Internal.RecipeJS_, cv: Internal.RecipeComponentValue_<Internal.Block>, json: Internal.JsonObject_): void;
        asMap<K>(key: Internal.RecipeComponent_<K>): Internal.RecipeComponent<Internal.TinyMap<K, Internal.Block>>;
        write(arg0: Internal.RecipeJS_, arg1: any): Internal.JsonElement;
        isInput(recipe: Internal.RecipeJS_, value: Internal.Block_, match: Internal.ReplacementMatch_): boolean;
        or<O>(other: Internal.RecipeComponent_<O>): Internal.OrRecipeComponent<Internal.Block, O>;
        role(): Internal.ComponentRole;
        componentClass(): typeof any;
        replaceInput(recipe: Internal.RecipeJS_, original: Internal.Block_, match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): Internal.Block;
        /**
         * Returns a new RecipeComponent that applies the mappingTo function to the input before it is passed to this component to be read
        */
        mapIn(mappingTo: Internal.UnaryOperator_<any>): Internal.MappingRecipeComponent<Internal.Block>;
        key(name: string): Internal.RecipeKey<Internal.Block>;
        constructorDescription(ctx: Internal.DescriptionContext_): Internal.TypeDescJS;
        orSelf(): Internal.RecipeComponent<Internal.Block>;
        componentType(): string;
        /**
         * Returns a new RecipeComponent that applies the mappingFrom function after the component writes to json, before that json is saved
        */
        mapOut(mappingFrom: Internal.UnaryOperator_<Internal.JsonElement>): Internal.MappingRecipeComponent<Internal.Block>;
        checkEmpty(arg0: Internal.RecipeKey_<any>, arg1: any): string;
        checkEmpty(key: Internal.RecipeKey_<Internal.Block>, value: Internal.Block_): string;
        static builder(): Internal.RecipeComponentBuilder;
        writeToJson(recipe: Internal.RecipeJS_, cv: Internal.RecipeComponentValue_<Internal.Block>, json: Internal.JsonObject_): void;
        readFromMap(recipe: Internal.RecipeJS_, cv: Internal.RecipeComponentValue_<Internal.Block>, map: Internal.Map_<any, any>): void;
        hasPriority(recipe: Internal.RecipeJS_, from: any): boolean;
        crole(): Internal.ComponentRole;
        asArrayOrSelf(): Internal.ArrayRecipeComponent<Internal.Block>;
        checkValueHasChanged(oldValue: Internal.Block_, newValue: Internal.Block_): boolean;
        /**
         * Returns a new RecipeComponent that applies the mappingTo function to the input before it is passed to this component to be read, and the mappingFrom function after the component writes to json, before that json is saved
        */
        map(mappingTo: Internal.UnaryOperator_<any>, mappingFrom: Internal.UnaryOperator_<Internal.JsonElement>): Internal.MappingRecipeComponent<Internal.Block>;
        /**
         * Returns a new RecipeComponent that maps the keys in a JsonObject according to the provided map, both before the json gets passed to the component and after the component returns a written json object.
         * The mappings should be provided in the format `{recipe: "component"}` where recipe is the key as in the recipe, and component is the key as how the RecipeComponent expects it.
         * Any keys not included in the provided map will be ignored, and any keys in the provided map that are not in either the input object or output object will be ignored.
         * Note that if the input or output is not a JsonObject (ie its an ItemStack, or it is a JsonPrimitive) then that will pass through this without being modified.
         * If you wish to handle those situations use the actual map function
        */
        simpleMap(mappings: any): Internal.SimpleMappingRecipeComponent<Internal.Block>;
        static builder(...key: Internal.RecipeKey_<any>[]): Internal.RecipeComponentBuilder;
        asPatternKey(): Internal.RecipeComponent<Internal.TinyMap<string, Internal.Block>>;
        isOutput(arg0: Internal.RecipeJS_, arg1: any, arg2: Internal.ReplacementMatch_): boolean;
        write(recipe: Internal.RecipeJS_, value: Internal.Block_): Internal.JsonPrimitive;
        isOutput(recipe: Internal.RecipeJS_, value: Internal.Block_, match: Internal.ReplacementMatch_): boolean;
        and<O>(other: Internal.RecipeComponent_<O>): Internal.AndRecipeComponent<Internal.Block, O>;
        read(recipe: Internal.RecipeJS_, from: any): Internal.Block;
        replaceOutput(recipe: Internal.RecipeJS_, original: Internal.Block_, match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): Internal.Block;
        isInput(arg0: Internal.RecipeJS_, arg1: any, arg2: Internal.ReplacementMatch_): boolean;
        static readonly OUTPUT: Internal.BlockComponent;
        static readonly INPUT: Internal.BlockComponent;
        static readonly BLOCK: Internal.BlockComponent;
    }
    type BlockComponent_ = BlockComponent;
    interface IntSet extends Internal.Set<number>, Internal.IntCollection {
        /**
         * @deprecated
        */
        stream(): Internal.Stream<number>;
        abstract addAll(arg0: Internal.Collection_<number>): boolean;
        of(arg0: number, arg1: number): this;
        of(): this;
        abstract contains(arg0: number): boolean;
        abstract retainAll(arg0: Internal.Collection_<any>): boolean;
        intStream(): Internal.IntStream;
        toArray<T>(arg0: Internal.IntFunction_<T[]>): T[];
        of<E>(arg0: E, arg1: E): Internal.Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E): Internal.Set<E>;
        intParallelStream(): Internal.IntStream;
        of<E>(arg0: E, arg1: E, arg2: E): Internal.Set<E>;
        abstract removeAll(arg0: Internal.IntCollection_): boolean;
        spliterator(): Internal.IntSpliterator;
        intIterator(): Internal.IntIterator;
        removeIf(arg0: Internal.IntPredicate_): boolean;
        abstract remove(arg0: number): boolean;
        abstract addAll(arg0: Internal.IntCollection_): boolean;
        abstract retainAll(arg0: Internal.IntCollection_): boolean;
        abstract add(arg0: number): boolean;
        abstract toArray<T>(arg0: T[]): T[];
        abstract containsAll(arg0: Internal.IntCollection_): boolean;
        /**
         * @deprecated
        */
        toIntArray(arg0: number[]): number[];
        /**
         * @deprecated
        */
        remove(arg0: any): boolean;
        of(arg0: number): this;
        /**
         * @deprecated
        */
        add(arg0: any): boolean;
        of<E>(arg0: E): Internal.Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E, arg8: E): Internal.Set<E>;
        abstract removeAll(arg0: Internal.Collection_<any>): boolean;
        copyOf<E>(arg0: Internal.Collection_<E>): Internal.Set<E>;
        /**
         * @deprecated
        */
        add(arg0: number): boolean;
        abstract isEmpty(): boolean;
        abstract toIntArray(): number[];
        forEach(arg0: Internal.IntConsumer_): void;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E, arg8: E, arg9: E): Internal.Set<E>;
        abstract containsAll(arg0: Internal.Collection_<any>): boolean;
        abstract toArray(arg0: number[]): number[];
        of(arg0: number, arg1: number, arg2: number): this;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E): Internal.Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E): Internal.Set<E>;
        /**
         * @deprecated
        */
        contains(arg0: any): boolean;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E): Internal.Set<E>;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E): Internal.Set<E>;
        iterator(): Internal.Iterator<any>;
        forEach(arg0: it.unimi.dsi.fastutil.ints.IntConsumer_): void;
        /**
         * @deprecated
        */
        forEach(arg0: Internal.Consumer_<number>): void;
        /**
         * @deprecated
        */
        parallelStream(): Internal.Stream<number>;
        /**
         * @deprecated
        */
        removeIf(arg0: Internal.Predicate_<number>): boolean;
        removeIf(arg0: it.unimi.dsi.fastutil.ints.IntPredicate_): boolean;
        abstract toArray(): any[];
        intSpliterator(): Internal.IntSpliterator;
        of(...arg0: number[]): this;
        abstract size(): number;
        abstract hashCode(): number;
        of<E>(...arg0: E[]): Internal.Set<E>;
        /**
         * @deprecated
        */
        rem(arg0: number): boolean;
        abstract clear(): void;
        abstract equals(arg0: any): boolean;
        get empty(): boolean
    }
    type IntSet_ = IntSet;
    class Vector4d implements Internal.Cloneable, Internal.Externalizable, Internal.Vector4dc {
        constructor()
        constructor(arg0: Internal.DoubleBuffer_)
        constructor(arg0: number[])
        constructor(arg0: number, arg1: Internal.DoubleBuffer_)
        constructor(arg0: Internal.ByteBuffer_)
        constructor(arg0: number, arg1: Internal.ByteBuffer_)
        constructor(arg0: Internal.Vector3dc_, arg1: number)
        constructor(arg0: Internal.Vector4fc_)
        constructor(arg0: number, arg1: number, arg2: number, arg3: number)
        constructor(arg0: Internal.Vector3fc_, arg1: number)
        constructor(arg0: Internal.Vector4dc_)
        constructor(arg0: Internal.Vector3ic_, arg1: number)
        constructor(arg0: number)
        constructor(arg0: number[])
        constructor(arg0: Internal.Vector2ic_, arg1: number, arg2: number)
        constructor(arg0: Internal.Vector2dc_, arg1: number, arg2: number)
        constructor(arg0: Internal.Vector4ic_)
        constructor(arg0: Internal.Vector2fc_, arg1: number, arg2: number)
        static distance(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number, arg7: number): number;
        set(arg0: Internal.Vector4ic_): this;
        get(arg0: number, arg1: Internal.ByteBuffer_): Internal.ByteBuffer;
        normalize(arg0: number, arg1: Internal.Vector4d_): this;
        get(arg0: Internal.FloatBuffer_): Internal.FloatBuffer;
        negate(arg0: Internal.Vector4d_): this;
        set(arg0: Internal.Vector3fc_, arg1: number): this;
        sub(arg0: Internal.Vector4fc_, arg1: Internal.Vector4d_): this;
        mul(arg0: Internal.Vector4dc_, arg1: Internal.Vector4d_): this;
        angleCos(arg0: Internal.Vector4dc_): number;
        normalize(arg0: number): this;
        mul(arg0: Internal.Vector4fc_): this;
        getToAddress(arg0: number): Internal.Vector4dc;
        equals(arg0: Internal.Vector4dc_, arg1: number): boolean;
        x(): number;
        div(arg0: Internal.Vector4dc_, arg1: Internal.Vector4d_): this;
        min(arg0: Internal.Vector4dc_, arg1: Internal.Vector4d_): this;
        add(arg0: number, arg1: number, arg2: number, arg3: number, arg4: Internal.Vector4d_): this;
        fma(arg0: number, arg1: Internal.Vector4dc_): this;
        set(arg0: Internal.Vector3ic_, arg1: number): this;
        normalize(arg0: Internal.Vector4d_): this;
        dot(arg0: number, arg1: number, arg2: number, arg3: number): number;
        set(arg0: number, arg1: number, arg2: number): this;
        distanceSquared(arg0: Internal.Vector4dc_): number;
        rotateX(arg0: number): this;
        mulAffine(arg0: Internal.Matrix4dc_, arg1: Internal.Vector4d_): this;
        toString(arg0: Internal.NumberFormat_): string;
        set(arg0: number, arg1: Internal.ByteBuffer_): this;
        floor(arg0: Internal.Vector4d_): this;
        mulAdd(arg0: number, arg1: Internal.Vector4dc_, arg2: Internal.Vector4d_): this;
        mul(arg0: Internal.Matrix4x3fc_, arg1: Internal.Vector4d_): this;
        mul(arg0: Internal.Matrix4x3fc_): this;
        add(arg0: number, arg1: number, arg2: number, arg3: number): this;
        sub(arg0: Internal.Vector4fc_): this;
        mulProject(arg0: Internal.Matrix4dc_): this;
        distanceSquared(arg0: number, arg1: number, arg2: number, arg3: number): number;
        set(arg0: number[]): this;
        lerp(arg0: Internal.Vector4dc_, arg1: number): this;
        normalize3(): this;
        round(): this;
        clone(): any;
        set(arg0: Internal.Vector4fc_): this;
        writeExternal(arg0: Internal.ObjectOutput_): void;
        maxComponent(): number;
        getf(arg0: number, arg1: Internal.ByteBuffer_): Internal.ByteBuffer;
        static length(arg0: number, arg1: number, arg2: number, arg3: number): number;
        distance(arg0: Internal.Vector4dc_): number;
        set(arg0: Internal.Vector2ic_, arg1: number, arg2: number): this;
        sub(arg0: number, arg1: number, arg2: number, arg3: number, arg4: Internal.Vector4d_): this;
        add(arg0: Internal.Vector4dc_): this;
        get(arg0: Internal.Vector4d_): this;
        angle(arg0: Internal.Vector4dc_): number;
        fma(arg0: Internal.Vector4dc_, arg1: Internal.Vector4dc_): this;
        mulTranspose(arg0: Internal.Matrix4dc_): this;
        get(arg0: number): number;
        y(): number;
        lengthSquared(): number;
        absolute(arg0: Internal.Vector4d_): this;
        mulAffineTranspose(arg0: Internal.Matrix4dc_, arg1: Internal.Vector4d_): this;
        negate(): this;
        ceil(): this;
        dot(arg0: Internal.Vector4dc_): number;
        div(arg0: number): this;
        set(arg0: Internal.DoubleBuffer_): this;
        mul(arg0: Internal.Matrix4dc_): this;
        round(arg0: Internal.Vector4d_): this;
        mul(arg0: Internal.Matrix4x3dc_, arg1: Internal.Vector4d_): this;
        rotateX(arg0: number, arg1: Internal.Vector4d_): this;
        setComponent(arg0: number, arg1: number): this;
        equals(arg0: number, arg1: number, arg2: number, arg3: number): boolean;
        mulAdd(arg0: number, arg1: Internal.Vector4dc_): this;
        floor(): this;
        mul(arg0: number): this;
        hermite(arg0: Internal.Vector4dc_, arg1: Internal.Vector4dc_, arg2: Internal.Vector4dc_, arg3: number, arg4: Internal.Vector4d_): this;
        get(arg0: number, arg1: Internal.Vector4i_): Internal.Vector4i;
        distance(arg0: number, arg1: number, arg2: number, arg3: number): number;
        absolute(): this;
        rotateAxis(arg0: number, arg1: number, arg2: number, arg3: number, arg4: Internal.Vector4d_): this;
        div(arg0: Internal.Vector4dc_): this;
        min(arg0: Internal.Vector4dc_): this;
        static lengthSquared(arg0: number, arg1: number, arg2: number, arg3: number): number;
        normalize(): this;
        z(): number;
        isFinite(): boolean;
        set(arg0: Internal.Vector2fc_, arg1: number, arg2: number): this;
        get(arg0: Vec4f_): Vec4f;
        fma(arg0: Internal.Vector4dc_, arg1: Internal.Vector4dc_, arg2: Internal.Vector4d_): this;
        mul(arg0: Internal.Vector4dc_): this;
        setFromAddress(arg0: number): this;
        get(arg0: Internal.DoubleBuffer_): Internal.DoubleBuffer;
        ceil(arg0: Internal.Vector4d_): this;
        mul(arg0: Internal.Matrix4fc_, arg1: Internal.Vector4d_): this;
        readExternal(arg0: Internal.ObjectInput_): void;
        set(arg0: number[]): this;
        set(arg0: Internal.ByteBuffer_): this;
        rotateZ(arg0: number): this;
        mulTranspose(arg0: Internal.Matrix4dc_, arg1: Internal.Vector4d_): this;
        set(arg0: number, arg1: number, arg2: number, arg3: number): this;
        mul(arg0: Internal.Matrix4x3dc_): this;
        rotateY(arg0: number, arg1: Internal.Vector4d_): this;
        get(arg0: number, arg1: Internal.FloatBuffer_): Internal.FloatBuffer;
        set(arg0: Internal.Vector2dc_, arg1: number, arg2: number): this;
        static distanceSquared(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number, arg7: number): number;
        length(): number;
        sub(arg0: Internal.Vector4dc_): this;
        get(arg0: Internal.ByteBuffer_): Internal.ByteBuffer;
        mulProject(arg0: Internal.Matrix4dc_, arg1: Internal.Vector4d_): this;
        zero(): this;
        minComponent(): number;
        add(arg0: Internal.Vector4dc_, arg1: Internal.Vector4d_): this;
        normalize3(arg0: Internal.Vector4d_): this;
        set(arg0: number, arg1: Internal.DoubleBuffer_): this;
        smoothStep(arg0: Internal.Vector4dc_, arg1: number, arg2: Internal.Vector4d_): this;
        max(arg0: Internal.Vector4dc_, arg1: Internal.Vector4d_): this;
        add(arg0: Internal.Vector4fc_): this;
        set(arg0: Internal.Vector4dc_): this;
        mul(arg0: Internal.Vector4fc_, arg1: Internal.Vector4d_): this;
        lerp(arg0: Internal.Vector4dc_, arg1: number, arg2: Internal.Vector4d_): this;
        fma(arg0: number, arg1: Internal.Vector4dc_, arg2: Internal.Vector4d_): this;
        getf(arg0: Internal.ByteBuffer_): Internal.ByteBuffer;
        set(arg0: Internal.Vector3dc_, arg1: number): this;
        mulProject(arg0: Internal.Matrix4dc_, arg1: Internal.Vector3d_): Internal.Vector3d;
        sub(arg0: number, arg1: number, arg2: number, arg3: number): this;
        sub(arg0: Internal.Vector4dc_, arg1: Internal.Vector4d_): this;
        mul(arg0: number, arg1: Internal.Vector4d_): this;
        div(arg0: number, arg1: Internal.Vector4d_): this;
        w(): number;
        mul(arg0: Internal.Matrix4dc_, arg1: Internal.Vector4d_): this;
        rotateAxis(arg0: number, arg1: number, arg2: number, arg3: number): this;
        get(arg0: number, arg1: Internal.DoubleBuffer_): Internal.DoubleBuffer;
        rotate(arg0: Internal.Quaterniondc_, arg1: Internal.Vector4d_): this;
        rotate(arg0: Internal.Quaterniondc_): this;
        rotateY(arg0: number): this;
        set(arg0: number): this;
        rotateZ(arg0: number, arg1: Internal.Vector4d_): this;
        mulAdd(arg0: Internal.Vector4dc_, arg1: Internal.Vector4dc_, arg2: Internal.Vector4d_): this;
        max(arg0: Internal.Vector4dc_): this;
        add(arg0: Internal.Vector4fc_, arg1: Internal.Vector4d_): this;
        mulAdd(arg0: Internal.Vector4dc_, arg1: Internal.Vector4dc_): this;
        mul(arg0: Internal.Matrix4fc_): this;
        get finite(): boolean
        set fromAddress(arg0: number)
        z: number;
        w: number;
        x: number;
        y: number;
    }
    type Vector4d_ = Vector4d;
    class MutableInt extends number implements Internal.Mutable<number>, Internal.Comparable<Internal.MutableInt> {
        constructor()
        constructor(arg0: number)
        constructor(arg0: number)
        constructor(arg0: string)
        setValue(arg0: number): void;
        decrementAndGet(): number;
        getAndAdd(arg0: number): number;
        toInteger(): number;
        add(arg0: number): void;
        subtract(arg0: number): void;
        increment(): void;
        compareTo(arg0: Internal.MutableInt_): number;
        incrementAndGet(): number;
        add(arg0: number): void;
        compareTo(arg0: any): number;
        getValue(): any;
        addAndGet(arg0: number): number;
        getAndAdd(arg0: number): number;
        getAndIncrement(): number;
        decrement(): void;
        setValue(arg0: any): void;
        subtract(arg0: number): void;
        addAndGet(arg0: number): number;
        getAndDecrement(): number;
        setValue(arg0: number): void;
        set value(arg0: number)
        get value(): any
        get andIncrement(): number
        set value(arg0: any)
        get andDecrement(): number
        set value(arg0: number)
    }
    type MutableInt_ = MutableInt;
    class BakedGlyph {
        constructor(arg0: any_, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: number, arg7: number, arg8: number)
        renderType(arg0: Internal.Font$DisplayMode_): Internal.RenderType;
        renderEffect(arg0: Internal.BakedGlyph$Effect_, arg1: Matrix4f_, arg2: Internal.VertexConsumer_, arg3: number): void;
        handler$bcm000$render(italic: boolean, x: number, y: number, matrix: Matrix4f_, vertexConsumer: Internal.VertexConsumer_, red: number, green: number, blue: number, alpha: number, light: number, ci: Internal.CallbackInfo_): void;
        render(arg0: boolean, arg1: number, arg2: number, arg3: Matrix4f_, arg4: Internal.VertexConsumer_, arg5: number, arg6: number, arg7: number, arg8: number, arg9: number): void;
    }
    type BakedGlyph_ = BakedGlyph;
    class Key$StorageKey implements icyllis.arc3d.engine.Key {
        constructor(b: Internal.KeyBuilder_)
    }
    type Key$StorageKey_ = Key$StorageKey;
    interface VertexBufferHelper {
        abstract restoreBinding(): void;
        abstract saveBinding(): void;
    }
    type VertexBufferHelper_ = VertexBufferHelper;
    class ChemicalHandlerManager$GasHandlerManager extends Internal.ChemicalHandlerManager<mekanism.api.chemical.gas.Gas, Internal.GasStack, mekanism.api.chemical.gas.IGasTank, mekanism.api.chemical.gas.IGasHandler, any> {
        constructor(holder: Internal.IChemicalTankHolder_<mekanism.api.chemical.gas.Gas, Internal.GasStack, mekanism.api.chemical.gas.IGasTank>, baseHandler: any_)
    }
    type ChemicalHandlerManager$GasHandlerManager_ = ChemicalHandlerManager$GasHandlerManager;
    class FusionRecipe extends Internal.AbstractProcessingRecipe {
        constructor(arg0: ResourceLocation_, arg1: string, arg2: Internal.ItemStack_, arg3: Internal.ItemStack_, arg4: Internal.ItemStack_)
        getOutput(): Internal.ItemStack;
        isSpecial(): boolean;
        getGroup(): string;
        getToastSymbol(): Internal.ItemStack;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        getSchema(): Internal.RecipeSchema;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        getType(): ResourceLocation;
        setGroup(group: string): void;
        getOrCreateId(): ResourceLocation;
        compareTo(arg0: Internal.AbstractProcessingRecipe_): number;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        isIncomplete(): boolean;
        getRemainingItems(arg0: Internal.Inventory_): Internal.NonNullList<Internal.ItemStack>;
        getInput2(): Internal.ItemStack;
        getInput1(): Internal.ItemStack;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        getMod(): string;
        get output(): Internal.ItemStack
        get special(): boolean
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get schema(): Internal.RecipeSchema
        get type(): ResourceLocation
        set group(group: string)
        get orCreateId(): ResourceLocation
        get incomplete(): boolean
        get input2(): Internal.ItemStack
        get input1(): Internal.ItemStack
        get mod(): string
    }
    type FusionRecipe_ = FusionRecipe;
    abstract class BaseScreen extends Internal.Panel {
        constructor()
        shouldCloseOnEsc(): boolean;
        updateGui(mx: number, my: number, pt: number): void;
        run(): void;
        getTheme(): Internal.Theme;
        closeGui(): void;
        drawDefaultBackground(graphics: Internal.GuiGraphics_): boolean;
        popModalPanel(): Internal.ModalPanel;
        openContextMenu(menuItems: Internal.List_<Internal.ContextMenuItem>): dev.ftb.mods.ftblibrary.ui.ContextMenu;
        openYesNoFull(title: net.minecraft.network.chat.Component_, desc: net.minecraft.network.chat.Component_, callback: Internal.BooleanConsumer_): void;
        anyModalPanelOpen(): boolean;
        setFocusedWidget(widget: Internal.Widget_): void;
        onInit(): boolean;
        getContextMenu(): Internal.Optional<Internal.ModalPanel>;
        closeModalPanel(panel: Internal.ModalPanel_): void;
        onPostInit(): void;
        openGuiLater(): void;
        pushModalPanel(modalPanel: Internal.ModalPanel_): void;
        onClosedByKey(key: dev.ftb.mods.ftblibrary.ui.input.Key_): boolean;
        getPrevScreen(): Internal.Screen;
        isMouseOver(widget: Internal.Widget_): boolean;
        isMouseOver(x: number, y: number, w: number, h: number): boolean;
        doesGuiPauseGame(): boolean;
        drawForeground(graphics: Internal.GuiGraphics_, theme: Internal.Theme_, x: number, y: number, w: number, h: number): void;
        openYesNo(title: net.minecraft.network.chat.Component_, desc: net.minecraft.network.chat.Component_, callback: Internal.Runnable_): void;
        initGui(): void;
        openContextMenu(newContextMenu: dev.ftb.mods.ftblibrary.ui.ContextMenu_): void;
        onBack(): void;
        openAfter(runnable: Internal.Runnable_): Internal.Runnable;
        get theme(): Internal.Theme
        set focusedWidget(widget: Internal.Widget_)
        get contextMenu(): Internal.Optional<Internal.ModalPanel>
        get prevScreen(): Internal.Screen
    }
    type BaseScreen_ = BaseScreen;
}
declare namespace com.mojang.math {
    interface Axis {
        rotationDegrees(arg0: number): Quaternionf;
        of(arg0: Vec3f_): this;
        abstract rotation(arg0: number): Quaternionf;
        (arg0: number): Quaternionf_;
        readonly ZN: com.mojang.math.Axis;
        readonly YN: com.mojang.math.Axis;
        readonly XN: com.mojang.math.Axis;
        readonly ZP: com.mojang.math.Axis;
        readonly YP: com.mojang.math.Axis;
        readonly XP: com.mojang.math.Axis;
    }
    type Axis_ = Axis;
}
declare namespace earth.terrarium.adastra.common.blocks.pipes {
    class PipeBlock extends Internal.BasicEntityBlock implements Internal.TransferablePipe, Internal.Wrenchable, Internal.SimpleWaterloggedBlock {
        constructor(transferRate: number, type: Internal.TransferablePipe$Type_, size: number, properties: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        static makeShape(state: Internal.BlockState_, size: number): Internal.VoxelShape;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        static getConnectedDirections(state: Internal.BlockState_): Internal.Direction[];
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        type(): Internal.TransferablePipe$Type;
        onWrench(level: Internal.Level_, pos: BlockPos_, state: Internal.BlockState_, side: Internal.Direction_, user: Internal.Player_, hitPos: Vec3d_): void;
        static getDirectionByVec(hit: Vec3d_, pos: BlockPos_): Internal.Optional<Internal.Direction>;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        transferRate(): number;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static readonly CONNECTED_WEST: Internal.EnumProperty<Internal.PipeProperty>;
        static readonly CONNECTED_EAST: Internal.EnumProperty<Internal.PipeProperty>;
        static readonly CONNECTED_NORTH: Internal.EnumProperty<Internal.PipeProperty>;
        static readonly CONNECTED_SOUTH: Internal.EnumProperty<Internal.PipeProperty>;
        static readonly WATERLOGGED: Internal.BooleanProperty;
        static readonly CONNECTED_DOWN: Internal.EnumProperty<Internal.PipeProperty>;
        static readonly DIRECTION_TO_CONNECTION: {[key: Internal.Direction]: Internal.EnumProperty<any>, [key: Internal.Direction]: Internal.EnumProperty<any>, [key: Internal.Direction]: Internal.EnumProperty<any>, [key: Internal.Direction]: Internal.EnumProperty<any>, [key: Internal.Direction]: Internal.EnumProperty<any>, [key: Internal.Direction]: Internal.EnumProperty<any>};
        static readonly CONNECTED_UP: Internal.EnumProperty<Internal.PipeProperty>;
    }
    type PipeBlock_ = PipeBlock;
}
declare namespace icyllis.arc3d.compiler {
    class SymbolTable {
        getArrayType(type: icyllis.arc3d.compiler.tree.Type_, size: number): icyllis.arc3d.compiler.tree.Type;
        isBuiltinType(name: string): boolean;
        findBuiltinSymbol(name: string): icyllis.arc3d.compiler.tree.Symbol;
        isType(name: string): boolean;
        find(name: string): icyllis.arc3d.compiler.tree.Symbol;
        getParent(): this;
        insert<T extends icyllis.arc3d.compiler.tree.Symbol>(context: icyllis.arc3d.compiler.Context_, symbol: T): T;
        isBuiltin(): boolean;
        get parent(): icyllis.arc3d.compiler.SymbolTable
        get builtin(): boolean
    }
    type SymbolTable_ = SymbolTable;
}
