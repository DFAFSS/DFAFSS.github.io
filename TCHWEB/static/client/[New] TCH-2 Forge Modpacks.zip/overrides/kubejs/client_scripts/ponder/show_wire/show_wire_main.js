Ponder.registry(event => {
    event
    .create([
        '#forge:wires/insulated_tin',
        '#forge:wires/insulated_copper',
        '#forge:wires/insulated_gold',
        '#forge:wires/insulated_iron',
        '#forge:wires/insulated_silver',
        '#forge:wires/insulated_superconductive',
        '#forge:wires/insulated_tin'
    ]).scene(
        "kubejs:show_wire",
        "导线",
        "kubejs:default_5_5",
        (scene,utils) =>{
            scene.showBasePlate()
            scene.idleSeconds(1)
            //Step1
            scene.world.showSection([2,1,2],Direction.DOWN)
            scene.world.setBlocks([2,1,2],'electrodynamics:wireinsulatedtinblack',false)
            scene.idle(15)
            scene.text(40,'导线可以传输电能',[2.5,1.5,2.5])
            //Step
            scene.idleSeconds(2)
            scene.world.showSection([1,1,2],Direction.DOWN)
            scene.world.setBlocks([1,1,2],'electrodynamics:wireinsulatedtinblack',false)
            scene.world.modifyBlockEntityNBT([2,1,2], nbt => {
                nbt.putInt("connections",65536)
            })
            scene.world.modifyBlockEntityNBT([1,1,2], nbt => {
                nbt.putInt("connections",1048576)
            })
            scene.idle(15)
            scene.text(40,'相邻的导线可以连接到一起',[1.5,1.5,2.5]).attachKeyFrame()
            scene.idleSeconds(3)
            scene.text(40,'请注意，不同的导线所能承受的\n耐压值不同',[1.5,1.5,2.5])
            scene.idleSeconds(3)
            scene.text(40,'电压值过高可能会爆炸',[1.5,1.5,2.5])
        }
    );
});