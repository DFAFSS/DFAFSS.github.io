Ponder.registry((event) => {
    event.create([
        'electrodynamics:hydroelectricgenerator'
    ]).scene(
        "kubejs:show_hydroelectricgenerator",
        "水力发电机",
        "kubejs:default_5_5",
        (scene,utils) =>{
            scene.showBasePlate()

            //Step1
            scene.world.setBlocks([4,1,1],'minecraft:oak_planks',false)
            scene.world.showSection([4,1,1],Direction.down)
            scene.idle(2)
            scene.world.setBlocks([3,1,2],'minecraft:oak_planks',false)
            scene.world.showSection([3,1,2],Direction.down)
            scene.idle(2)
            scene.world.setBlocks([2,1,2],'minecraft:oak_planks',false)
            scene.world.showSection([2,1,2],Direction.down)
            scene.idle(2)
            scene.world.setBlocks([1,1,2],'minecraft:oak_planks',false)
            scene.world.showSection([1,1,2],Direction.down)
            scene.idle(2)
            scene.world.setBlocks([0,1,1],'minecraft:oak_planks',false)
            scene.world.showSection([0,1,1],Direction.down)
            scene.idle(2)
            scene.world.setBlocks([1,1,0],'minecraft:oak_planks',false)
            scene.world.showSection([1,1,0],Direction.down)
            scene.idle(2)
            scene.world.setBlocks([2,1,0],'minecraft:oak_planks',false)
            scene.world.showSection([2,1,0],Direction.down)
            scene.idle(2)
            scene.world.setBlocks([3,1,0],'minecraft:oak_planks',false)
            scene.world.showSection([3,1,0],Direction.down)
            scene.idle(2)
            scene.world.setBlocks([1,2,2],'minecraft:oak_planks',false)
            scene.world.showSection([1,2,2],Direction.down)
            scene.idle(2)
            scene.world.setBlocks([0,2,1],'minecraft:oak_planks',false)
            scene.world.showSection([0,2,1],Direction.down)
            scene.idle(10)
            scene.world.setBlocks([2,2,2],'electrodynamics:hydroelectricgenerator',false)
            scene.world.modifyBlocks([2,2,2], state => state.with("waterlogged", 'false'), false)
            scene.world.showSection([2,2,2],Direction.down)

            scene.rotateCameraY(60)
            scene.text(90,'水力发电机可以通过水流来进行发电',[2.5,2.5,2.5]).attachKeyFrame()
            scene.idleSeconds(3)
            //Step2
            scene.world.setBlocks([1,2,1],'minecraft:water',false)
            //scene.world.modifyBlocks([1,2,1], state => state.with("level", '0'), false)
            scene.world.showSection([1,2,1],Direction.down)
            scene.idle(15)
            scene.world.setBlock([2,2,1],'minecraft:water',false)
            scene.world.modifyBlocks([2,2,1], state => state.with("level", '7').with('falling','true'), false)
            scene.world.showSection([2,2,1],null)
            scene.world.setBlock([2,1,1],'minecraft:water',false)

            scene.world.showSection([2,1,1],null)
            scene.world.setBlock([3,1,1],'minecraft:water',false)
            scene.world.modifyBlocks([3,1,1], state => state.with("level", '7'), false)
            scene.world.showSection([3,1,1],null)
            scene.idle(10)
            scene.world.modifyBlockEntityNBT([2,2,2], nbt => {
                nbt.putInt("isGenerating",1)
            })
        }
    );
});