Ponder.registry((event) => {
    event.create([
        'electrodynamics:relay',
        'electrodynamics:circuitbreaker'
    ]).scene(
        "kubejs:show_relay",
        "继电器与断路器",
        "kubejs:default_5_5",
        (scene,utils) =>{
            scene.showBasePlate()
            scene.idleSeconds(1)
            //Step1
            scene.world.setBlocks([2,1,2],'electrodynamics:relay',false)
            scene.world.modifyBlocks([2,1,2], state => state.with("waterlogged", 'false').with('lit','false').with("facing",'west'), false)
            scene.world.showSection([2,1,2],Direction.DOWN)
            scene.idle(15)
            scene.text(60, '继电器可以控制电路的通断', [2.5, 1.5, 2.5]).attachKeyFrame()
            scene.idleSeconds(3)
            scene.text(90, '当旁边有红石信号时，继电器断开，电路断开，反之则闭合，电路导通', [2.5, 1.5, 2.5])
            scene.idle(100)
            //Step2
            scene.world.setBlocks([3,1,2],'electrodynamics:wireinsulatedtinblack',false)
            scene.world.modifyBlockEntityNBT([3,1,2], nbt => {
                nbt.putInt("connections",65536)
            })
            scene.world.showSection([3,1,2],Direction.DOWN)
            scene.world.setBlocks([1,1,2],'electrodynamics:wireinsulatedtinblack',false)
            scene.world.modifyBlockEntityNBT([1,1,2], nbt => {
                nbt.putInt("connections",1048576)
            })
            scene.world.showSection([1,1,2],Direction.DOWN)
            scene.idle(15)
            scene.world.setBlocks([2,1,1],'minecraft:lever',false)
            scene.world.modifyBlocks([2,1,1], state => state.with("face","floor"),false)
            scene.world.showSection([2,1,1],Direction.DOWN)
            scene.idle(15)
            scene
                .showControls(30,[2,1.5,1],"left")
                .rightClick()
            scene.world.modifyBlocks([2,1,1], state => state.with("powered","true").with("face","floor"),false)
            scene.world.modifyBlocks([2,1,2], state => state.with("lit","true"),false)
            scene.idleSeconds(2)
            //Step3
            scene.addKeyframe()
            scene.world.setBlocks([2,1,2],'electrodynamics:circuitbreaker',true)
            scene.world.modifyBlocks([2,1,2], state => state.with("waterlogged", 'false').with('lit','false').with("facing",'west'))
            scene.world.setBlocks([2,1,1],'minecraft:lever',true)
            scene.world.modifyBlocks([2,1,1], state => state.with("face","floor"))
            scene.text(90, '断路器与继电器一样，也有控制电路断开闭合的功能', [2.5, 1.5, 2.5])
            scene.idle(100)
            scene
            .showControls(30,[2,1.5,1],"left")
            .rightClick()
            scene.world.modifyBlocks([2,1,1], state => state.with("powered","true").with("face","floor"),false)
            scene.world.modifyBlocks([2,1,2], state => state.with("lit","true"),false)
            scene.idle(40)
            scene.text(140, '不过不一样的一点是，断路器可以自动检测线路是否会因为过压或其他原因爆炸，会自动断开电路', [2.5, 1.5, 2.5])
            scene.idle(150)
        }
    );
});