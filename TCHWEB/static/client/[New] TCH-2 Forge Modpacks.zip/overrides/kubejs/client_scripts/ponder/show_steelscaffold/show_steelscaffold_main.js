Ponder.registry((event) => {
    event.create([
        'electrodynamics:steelscaffold'
    ]).scene(
        "kubejs:show_steelscaffold",
        "钢脚手架",
        "kubejs:default_5_5",
        (scene,utils) =>{
            scene.showBasePlate()
            //Step1
            scene.world.setBlocks([3,1,2],'electrodynamics:wireinsulatedtinblack',false)
            scene.world.modifyBlockEntityNBT([3,1,2], nbt => {
                nbt.putInt('connections',65536)
            })
            scene.world.showSection([3,1,2],Direction.down)
            scene.idle(2)
            scene.world.setBlocks([2,1,2],'electrodynamics:wireinsulatedtinblack',false)
            scene.world.modifyBlockEntityNBT([2,1,2], nbt => {
                nbt.putInt('connections',1114112)
            })
            scene.world.showSection([2,1,2],Direction.down)
            scene.idle(2)
            scene.world.setBlocks([1,1,2],'electrodynamics:wireinsulatedtinblack',false)
            scene.world.modifyBlockEntityNBT([1,1,2], nbt => {
                nbt.putInt('connections',1048576)
            })
            scene.world.showSection([1,1,2],Direction.down)
            scene.idle(2)
            scene.text(60,'钢脚手架可以把线缆包起来').attachKeyFrame()
            scene.idle(65)
            scene
            .showControls(30,[2,1.5,2],'left')
            .rightClick()
            .withItem('electrodynamics:steelscaffold')
            scene.world.modifyBlockEntityNBT([2,1,2], nbt => {
                nbt.putInt('scaffoldblock',118864)
            })
            scene.idle(35)
            scene.text(60,'还可以伪装成任意方块',[2,1.5,2]).attachKeyFrame()
            scene.idle(65)
            scene
            .showControls(30,[2,1.5,2],'left')
            .rightClick()
            .withItem('electrodynamics:resourceblocksilver')
            scene.world.modifyBlockEntityNBT([2,1,2], nbt => {
                nbt.putInt('camoflaugedblock',118591)
            })
            scene.idle(30)
        }
    );
});
